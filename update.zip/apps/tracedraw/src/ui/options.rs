//! Tools > Options (the application options and the Customization, Tools,
//! Global and Workspaces dialogs) and Page > Document Setup: one
//! window with a tab for each of them along the top (#633), a white page
//! list on the left, the page on
//! the right, the help button at the bottom left, OK and Cancel at the
//! bottom right. Cancel puts back what the dialog changed.

use crate::app::{App, Units};
use crate::i18n::{tr, trf};
use crate::settings::{AutoCenter, HandleSize, NodeShape, NodeSize, Startup};
use crate::theme::Tokens;
use crate::ui::chrome;
use crate::ui::tips::RichTip;
use egui::{Context, Ui};
use tracedraw_core::{geometry::Size, Color, Command, Fill};

/// Which dialog a page belongs to.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OptionsSet {
    App,
    Customization,
    Tools,
    Global,
    Workspaces,
    Ai,
    Document,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum OptionsPage {
    // Tools > Options > TraceDraw.
    #[default]
    General,
    Display,
    Edit,
    NodesAndHandles,
    ClipFrame,
    Snapping,
    AlignmentGuides,
    DynamicGuides,
    Save,
    Text,
    // Tools > Options > Customization.
    Appearance,
    Commands,
    CommandBars,
    ColorPalette,
    // Tools > Options > Tools.
    Pick,
    ZoomPan,
    Curves,
    Rectangle,
    Ellipse,
    Polygon,
    Spiral,
    GraphPaper,
    Table,
    Eraser,
    ShapeRecognition,
    Dimension,
    AngularDimension,
    Connector,
    MeshFill,
    // Tools > Options > Global.
    GlobalGeneral,
    Printing,
    FileFormats,
    BitmapTracing,
    Warnings,
    FileLocations,
    // Tools > Options > Workspaces.
    Workspace,
    // Tools > Options > AI.
    AiGeneral,
    AiService,
    // Page > Document Setup.
    DocumentGeneral,
    PageSize,
    Layout,
    Background,
    Bleed,
    Rulers,
    Grid,
    Guidelines,
}

impl OptionsSet {
    /// Every set, in the order of the dialog's tabs.
    pub const ALL: [OptionsSet; 7] = [
        OptionsSet::App,
        OptionsSet::Customization,
        OptionsSet::Tools,
        OptionsSet::Global,
        OptionsSet::Workspaces,
        OptionsSet::Ai,
        OptionsSet::Document,
    ];

    /// The set's tab: the name of the menu item that opens it.
    fn tab_label(self) -> String {
        let key = match self {
            OptionsSet::App => "menu.tools.options_app",
            OptionsSet::Customization => "menu.tools.options_customization",
            OptionsSet::Tools => "menu.tools.options_tools",
            OptionsSet::Global => "menu.tools.options_global",
            OptionsSet::Workspaces => "menu.tools.options_workspaces",
            OptionsSet::Ai => "menu.tools.options_ai",
            OptionsSet::Document => "dialog.document_options",
        };
        tr(key)
            .trim_end_matches("...")
            .trim_end_matches('\u{2026}')
            .to_string()
    }

    pub fn pages(self) -> &'static [OptionsPage] {
        use OptionsPage::*;
        match self {
            OptionsSet::App => &[
                General,
                Display,
                Edit,
                NodesAndHandles,
                ClipFrame,
                Snapping,
                AlignmentGuides,
                DynamicGuides,
                Save,
                Text,
            ],
            OptionsSet::Customization => &[Appearance, CommandBars, Commands, ColorPalette],
            OptionsSet::Tools => &[
                Pick,
                Eraser,
                ZoomPan,
                Curves,
                ShapeRecognition,
                Rectangle,
                Ellipse,
                Polygon,
                GraphPaper,
                Spiral,
                Table,
                Dimension,
                AngularDimension,
                Connector,
                MeshFill,
            ],
            OptionsSet::Global => &[
                GlobalGeneral,
                Printing,
                FileFormats,
                BitmapTracing,
                Warnings,
                FileLocations,
            ],
            OptionsSet::Workspaces => &[Workspace],
            OptionsSet::Ai => &[AiGeneral, AiService],
            OptionsSet::Document => &[
                DocumentGeneral,
                PageSize,
                Layout,
                Background,
                Bleed,
                Rulers,
                Grid,
                Guidelines,
            ],
        }
    }

    fn title(self) -> String {
        match self {
            OptionsSet::App => trf("options.title_app", &[("app", "TraceDraw")]),
            OptionsSet::Customization => tr("options.title_customization"),
            OptionsSet::Tools => tr("options.title_tools"),
            OptionsSet::Global => tr("options.title_global"),
            OptionsSet::Workspaces => tr("options.title_workspaces"),
            OptionsSet::Ai => tr("options.title_ai"),
            OptionsSet::Document => tr("dialog.document_options"),
        }
    }
}

impl OptionsPage {
    /// The tool a Tools page is about, whose icon the page list shows.
    pub fn tool(self) -> Option<crate::tools::Tool> {
        use crate::tools::Tool;
        use OptionsPage::*;
        Some(match self {
            Pick => Tool::Pick,
            ZoomPan => Tool::Zoom,
            Curves => Tool::Freehand,
            Rectangle => Tool::Rectangle,
            Ellipse => Tool::Ellipse,
            Polygon => Tool::Polygon,
            Spiral => Tool::Spiral,
            GraphPaper => Tool::GraphPaper,
            Table => Tool::Table,
            Eraser => Tool::Eraser,
            ShapeRecognition => Tool::ShapeRecognition,
            Dimension => Tool::ParallelDimension,
            AngularDimension => Tool::AngularDimension,
            Connector => Tool::Connector,
            MeshFill => Tool::MeshFill,
            _ => return None,
        })
    }

    pub fn set(self) -> OptionsSet {
        OptionsSet::ALL
            .into_iter()
            .find(|s| s.pages().contains(&self))
            .unwrap_or(OptionsSet::App)
    }

    pub fn key(self) -> &'static str {
        use OptionsPage::*;
        match self {
            General | GlobalGeneral | DocumentGeneral => "options.general",
            Display => "options.display",
            Edit => "options.edit",
            NodesAndHandles => "options.nodes_and_handles",
            ClipFrame => "options.clip_frame",
            Snapping => "options.snapping",
            AlignmentGuides => "options.alignment_guides",
            DynamicGuides => "options.dynamic_guides",
            Save => "options.save",
            Text => "options.text",
            Appearance => "options.appearance",
            Commands => "options.commands",
            CommandBars => "options.command_bars",
            ColorPalette => "options.color_palette",
            Pick => "tool.pick",
            ZoomPan => "options.zoom_pan",
            Curves => "options.curve_tools",
            Rectangle => "tool.rectangle",
            Ellipse => "tool.ellipse",
            Polygon => "tool.polygon",
            Spiral => "tool.spiral",
            GraphPaper => "tool.graph_paper",
            Table => "tool.table",
            Eraser => "tool.eraser",
            ShapeRecognition => "tool.shape_recognition",
            Dimension => "options.dimension_tool",
            AngularDimension => "tool.angular_dimension",
            Connector => "options.connector_tool",
            MeshFill => "tool.mesh_fill",
            FileLocations => "options.file_locations",
            Printing => "options.printing",
            FileFormats => "options.file_formats",
            BitmapTracing => "options.bitmap_tracing",
            Warnings => "options.warnings",
            Workspace => "options.workspace",
            AiGeneral => "options.general",
            AiService => "options.ai_service",
            PageSize => "options.page_size",
            Layout => "options.layout",
            Background => "options.background",
            Bleed => "options.bleed_page",
            Rulers => "options.rulers",
            Grid => "options.grid",
            Guidelines => "options.guidelines",
        }
    }
}

/// What the options dialogs may change, kept when one opens so that
/// Cancel can put it back. Document changes are commands, undone back to
/// the depth the history had.
pub struct OptionsSnapshot {
    settings: crate::settings::Settings,
    language: String,
    units: Units,
    nudge_mm: f64,
    duplicate_offset: tracedraw_core::geometry::Vec2,
    show_rulers: bool,
    show_grid: bool,
    show_guides: bool,
    show_baseline_grid: bool,
    show_pixel_grid: bool,
    show_page_border: bool,
    show_page_shadow: bool,
    show_status_bar: bool,
    show_standard_toolbar: bool,
    show_property_bar: bool,
    show_toolbox: bool,
    show_text_toolbar: bool,
    show_zoom_toolbar: bool,
    show_transform_toolbar: bool,
    show_dockers: bool,
    docker_tab: crate::app::DockerTab,
    toolbox_last: Vec<crate::tools::Tool>,
    proof_colors: bool,
    snap: crate::snap::SnapSettings,
    polygon_points: u32,
    star_sharpness: f64,
    rect_corners: tracedraw_core::Corners,
    corners_together: bool,
    ellipse_arc: Option<tracedraw_core::EllipseArc>,
    spiral_revolutions: u32,
    spiral_logarithmic: bool,
    graph_rows: u32,
    graph_cols: u32,
    graph_radial: bool,
    graph_rings: u32,
    graph_spokes: u32,
    table_rows: u32,
    table_cols: u32,
    eraser_width: f64,
    eraser_square: bool,
    recognize: crate::recognize::RecognizeSettings,
    dimension_style: crate::dimensions::DimensionStyle,
    connector_radius: f64,
    mesh_rows: u32,
    mesh_cols: u32,
    text_font: String,
    text_size_pt: f64,
    text_default_font: String,
    text_default_size: f64,
    text_hyphenation: bool,
    show_non_printing: bool,
    workspace: crate::app::Workspace,
    undo_depth: usize,
}

impl OptionsSnapshot {
    pub fn take(app: &App) -> Self {
        OptionsSnapshot {
            settings: app.settings.clone(),
            language: crate::i18n::language(),
            units: app.units,
            nudge_mm: app.nudge_mm,
            duplicate_offset: app.duplicate_offset,
            show_rulers: app.show_rulers,
            show_grid: app.show_grid,
            show_guides: app.show_guides,
            show_baseline_grid: app.show_baseline_grid,
            show_pixel_grid: app.show_pixel_grid,
            show_page_border: app.show_page_border,
            show_page_shadow: app.show_page_shadow,
            show_status_bar: app.show_status_bar,
            show_standard_toolbar: app.show_standard_toolbar,
            show_property_bar: app.show_property_bar,
            show_toolbox: app.show_toolbox,
            show_text_toolbar: app.show_text_toolbar,
            show_zoom_toolbar: app.show_zoom_toolbar,
            show_transform_toolbar: app.show_transform_toolbar,
            show_dockers: app.show_dockers,
            docker_tab: app.docker_tab,
            toolbox_last: app.toolbox_last.clone(),
            proof_colors: app.proof_colors,
            snap: app.snap,
            polygon_points: app.polygon_points,
            star_sharpness: app.star_sharpness,
            rect_corners: app.rect_corners,
            corners_together: app.corners_together,
            ellipse_arc: app.ellipse_arc,
            spiral_revolutions: app.spiral_revolutions,
            spiral_logarithmic: app.spiral_logarithmic,
            graph_rows: app.graph_rows,
            graph_cols: app.graph_cols,
            graph_radial: app.graph_radial,
            graph_rings: app.graph_rings,
            graph_spokes: app.graph_spokes,
            table_rows: app.table_rows,
            table_cols: app.table_cols,
            eraser_width: app.eraser_width,
            eraser_square: app.eraser_square,
            recognize: app.recognize,
            dimension_style: app.dimension_style.clone(),
            connector_radius: app.connector_radius,
            mesh_rows: app.mesh_rows,
            mesh_cols: app.mesh_cols,
            text_font: app.text_font.clone(),
            text_size_pt: app.text_size_pt,
            text_default_font: app.text_default_font.clone(),
            text_default_size: app.text_default_size,
            text_hyphenation: app.text_hyphenation,
            show_non_printing: app.show_non_printing,
            workspace: app.workspace,
            undo_depth: undo_depth(app),
        }
    }

    /// Put everything back (Cancel).
    pub fn restore(self, app: &mut App) {
        if app.has_document() {
            while undo_depth(app) > self.undo_depth {
                if app.engine.undo().is_err() {
                    break;
                }
            }
        }
        crate::i18n::set_language(&self.language);
        app.settings = self.settings;
        // The default tab spacing acts at once while the dialog is open.
        tracedraw_core::set_default_tab_step(app.settings.default_tab_mm);
        // The workspace first: choosing one sets the bars, which the
        // snapshot then puts back as they were.
        if app.workspace != self.workspace {
            app.set_workspace(self.workspace);
        }
        app.units = self.units;
        app.nudge_mm = self.nudge_mm;
        app.duplicate_offset = self.duplicate_offset;
        app.show_rulers = self.show_rulers;
        app.show_grid = self.show_grid;
        app.show_guides = self.show_guides;
        app.show_baseline_grid = self.show_baseline_grid;
        app.show_pixel_grid = self.show_pixel_grid;
        app.show_page_border = self.show_page_border;
        app.show_page_shadow = self.show_page_shadow;
        app.show_status_bar = self.show_status_bar;
        app.show_standard_toolbar = self.show_standard_toolbar;
        app.show_property_bar = self.show_property_bar;
        app.show_toolbox = self.show_toolbox;
        app.show_text_toolbar = self.show_text_toolbar;
        app.show_zoom_toolbar = self.show_zoom_toolbar;
        app.show_transform_toolbar = self.show_transform_toolbar;
        app.proof_colors = self.proof_colors;
        app.snap = self.snap;
        app.polygon_points = self.polygon_points;
        app.star_sharpness = self.star_sharpness;
        app.rect_corners = self.rect_corners;
        app.corners_together = self.corners_together;
        app.ellipse_arc = self.ellipse_arc;
        app.spiral_revolutions = self.spiral_revolutions;
        app.spiral_logarithmic = self.spiral_logarithmic;
        app.graph_rows = self.graph_rows;
        app.graph_cols = self.graph_cols;
        app.graph_radial = self.graph_radial;
        app.graph_rings = self.graph_rings;
        app.graph_spokes = self.graph_spokes;
        app.table_rows = self.table_rows;
        app.table_cols = self.table_cols;
        app.eraser_width = self.eraser_width;
        app.eraser_square = self.eraser_square;
        app.recognize = self.recognize;
        app.dimension_style = self.dimension_style;
        app.connector_radius = self.connector_radius;
        app.mesh_rows = self.mesh_rows;
        app.mesh_cols = self.mesh_cols;
        app.text_font = self.text_font;
        app.text_size_pt = self.text_size_pt;
        app.text_default_font = self.text_default_font;
        app.text_default_size = self.text_default_size;
        app.text_hyphenation = self.text_hyphenation;
        app.show_non_printing = self.show_non_printing;
        app.show_dockers = self.show_dockers;
        app.docker_tab = self.docker_tab;
        app.toolbox_last = self.toolbox_last;
        app.apply_runtime_settings();
    }
}

fn undo_depth(app: &App) -> usize {
    app.engine.history_labels().0.len()
}

/// Draw the options dialog of the set `app.options_page` belongs to.
pub fn options_dialog(app: &mut App, ctx: &Context, close: &mut bool) {
    if app.options_snapshot.is_none() {
        app.options_snapshot = Some(OptionsSnapshot::take(app));
    }
    let set = app.options_page.set();
    let mut ok = false;
    let mut cancel = false;
    let x_closed = chrome::dialog(
        ctx,
        "options_dialog",
        &set.title(),
        egui::vec2(887.0, 663.0 + TABS_H),
        |ui| {
            let body = ui.max_rect();
            let tabs = egui::Rect::from_min_size(
                body.min + egui::vec2(14.0, 8.0),
                egui::vec2(859.0, TABS_H - 6.0),
            );
            set_tabs(app, ui, tabs, set);
            let top = 10.0 + TABS_H;
            let list = egui::Rect::from_min_size(
                body.min + egui::vec2(14.0, top),
                egui::vec2(225.0, 566.0),
            );
            let page = egui::Rect::from_min_size(
                body.min + egui::vec2(251.0, top),
                egui::vec2(622.0, 566.0),
            );
            page_list(app, ui, list, set);
            ui.scope_builder(egui::UiBuilder::new().max_rect(page), |ui| {
                chrome::panel()
                    .inner_margin(egui::Margin {
                        left: 20,
                        right: 20,
                        top: 16,
                        bottom: 12,
                    })
                    .show(ui, |ui| {
                        ui.set_min_size(page.size() - egui::vec2(42.0, 30.0));
                        ui.set_max_width(page.width() - 42.0);
                        egui::ScrollArea::vertical()
                            .id_salt(("options_page", app.options_page.key()))
                            .auto_shrink([false, false])
                            .max_height(page.height() - 30.0)
                            .show(ui, |ui| {
                                ui.spacing_mut().item_spacing.y = 7.0;
                                let from = shapes_drawn(ui);
                                #[cfg(test)]
                                let room = ui.max_rect().right();
                                draw_page(app, ui);
                                #[cfg(test)]
                                {
                                    let over = ui.min_rect().right() - room;
                                    ui.ctx()
                                        .data_mut(|d| d.insert_temp(page_overflow_id(), over));
                                }
                                highlight_setting(app, ui, from);
                            });
                    });
            });
            let buttons = egui::Rect::from_min_size(
                body.min + egui::vec2(14.0, top + 566.0 + 15.0),
                egui::vec2(859.0, 27.0),
            );
            ui.scope_builder(egui::UiBuilder::new().max_rect(buttons), |ui| {
                ui.horizontal(|ui| {
                    if ui
                        .add_sized([27.0, 27.0], egui::Button::new("?"))
                        .rich_tip(crate::ui::tips::keyed("dialog.help_button"))
                        .clicked()
                    {
                        app.open_help(crate::help::options_topic(app.options_page));
                    }
                    if set == OptionsSet::Document
                        && ui
                            .add_sized(
                                [150.0, 27.0],
                                egui::Button::new(tr("options.save_as_default")),
                            )
                            .rich_tip(crate::ui::tips::keyed("options.save_as_default"))
                            .clicked()
                    {
                        save_as_default(app);
                    }
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        // The buttons bring their own tips (#2367).
                        if chrome::button(ui, &tr("dialog.cancel")).clicked() {
                            cancel = true;
                        }
                        ui.add_space(5.0);
                        if chrome::button(ui, &tr("dialog.ok")).clicked() {
                            ok = true;
                        }
                    });
                });
            });
        },
    );
    if ok {
        app.options_snapshot = None;
        app.apply_runtime_settings();
        app.save_settings();
        *close = true;
    } else if cancel || x_closed {
        if let Some(s) = app.options_snapshot.take() {
            s.restore(app);
        }
        *close = true;
    }
}

/// The Document set's Save as Default: new drawings start with this
/// drawing's grid, rulers, guideline settings, object defaults and its
/// guidelines (those of the master page and of the current page). It is
/// saved at once and kept when the dialog is then cancelled or closed
/// (#3522).
pub(crate) fn save_as_default(app: &mut App) {
    let defaults = crate::settings::DocumentDefaults::of_page(app.doc(), Some(app.page));
    if let Some(s) = app.options_snapshot.as_mut() {
        s.settings.document_defaults = defaults.clone();
    }
    app.settings.document_defaults = defaults;
    app.save_settings();
    app.status = tr("status.settings_saved");
}

/// How far the page drawn last reached past the right edge of its
/// panel (for tests).
#[cfg(test)]
fn page_overflow_id() -> egui::Id {
    egui::Id::new("options_page_overflow")
}

/// Height of the tab row over the page list.
const TABS_H: f32 = 32.0;

/// The tabs along the top: one per set of pages (Document Setup while
/// a drawing is open), the current one selected. A tab opens the page of
/// its set shown last, else its first page (#633).
fn set_tabs(app: &mut App, ui: &mut Ui, rect: egui::Rect, set: OptionsSet) {
    let last = |s: OptionsSet| egui::Id::new(("options_last_page", s as u8));
    let page = app.options_page;
    ui.ctx().data_mut(|d| d.insert_temp(last(set), page));
    ui.scope_builder(egui::UiBuilder::new().max_rect(rect), |ui| {
        ui.horizontal(|ui| {
            for s in OptionsSet::ALL {
                if s == OptionsSet::Document && !app.has_document() {
                    continue;
                }
                let tab = ui
                    .selectable_label(s == set, s.tab_label())
                    .rich_tip_with(|| format!("{}\n{}", s.tab_label(), tr("options.set_tab_desc")));
                ui.ctx()
                    .data_mut(|d| d.insert_temp(tab_rect_id(s), tab.rect));
                if tab.clicked() && s != set {
                    app.options_page = ui
                        .ctx()
                        .data(|d| d.get_temp::<OptionsPage>(last(s)))
                        .filter(|p| p.set() == s)
                        .or_else(|| s.pages().first().copied())
                        .unwrap_or_default();
                }
            }
        });
    });
    ui.painter().hline(
        rect.x_range(),
        rect.bottom() + 2.0,
        egui::Stroke::new(1.0, crate::theme::Tokens::border()),
    );
}

/// Where the tab of `set` was drawn last (for tests).
pub(crate) fn tab_rect_id(set: OptionsSet) -> egui::Id {
    egui::Id::new(("options_tab_rect", set as u8))
}

/// The page list: one row per page, the current one highlighted.
fn page_list(app: &mut App, ui: &mut Ui, rect: egui::Rect, set: OptionsSet) {
    let painter = ui.painter();
    painter.rect_filled(rect, 0.0, crate::theme::Tokens::field());
    painter.rect_stroke(
        rect,
        0.0,
        egui::Stroke::new(1.0, crate::theme::Tokens::border()),
        egui::StrokeKind::Inside,
    );
    for (i, p) in set.pages().iter().enumerate() {
        let row = egui::Rect::from_min_size(
            rect.min + egui::vec2(5.0, 5.0 + i as f32 * 23.0),
            egui::vec2(rect.width() - 10.0, 22.0),
        );
        let resp = ui
            .interact(
                row,
                egui::Id::new(("options_list", p.key(), i)),
                egui::Sense::click(),
            )
            .rich_tip_with(|| format!("{}\n{}", tr(p.key()), tr("options.page_desc")));
        let selected = app.options_page == *p;
        if selected {
            ui.painter()
                .rect_filled(row, 0.0, crate::theme::Tokens::selected_row());
            ui.painter().rect_stroke(
                row,
                0.0,
                egui::Stroke::new(1.0, crate::theme::Tokens::selected_row_line()),
                egui::StrokeKind::Inside,
            );
        } else if resp.hovered() {
            ui.painter()
                .rect_filled(row, 0.0, crate::theme::Tokens::hovered_row());
        }
        let mut text_x = 5.0;
        if let Some(t) = p.tool() {
            let icon = egui::Rect::from_center_size(
                row.left_center() + egui::vec2(13.0, 0.0),
                egui::vec2(16.0, 16.0),
            );
            crate::ui::icons::draw(
                ui.painter(),
                icon,
                t,
                crate::ui::icons::tool_color(t, Tokens::text()),
            );
            text_x = 27.0;
        }
        ui.painter().text(
            row.left_center() + egui::vec2(text_x, 0.0),
            egui::Align2::LEFT_CENTER,
            tr(p.key()),
            egui::FontId::proportional(13.0),
            Tokens::text(),
        );
        if resp.clicked() {
            app.options_page = *p;
        }
    }
}

fn draw_page(app: &mut App, ui: &mut Ui) {
    use OptionsPage::*;
    // A command waits for its keys only while its page is shown.
    if !matches!(app.options_page, Commands) {
        app.shortcut_editor.capture = None;
    }
    match app.options_page {
        General => general_page(app, ui),
        Display => display_page(app, ui),
        Edit => edit_page(app, ui),
        NodesAndHandles => nodes_page(app, ui),
        ClipFrame => clip_frame_page(app, ui),
        Snapping => snapping_page(app, ui),
        AlignmentGuides => alignment_guides_page(app, ui),
        DynamicGuides => dynamic_guides_page(app, ui),
        Save => save_page(app, ui),
        Text => text_page(app, ui),
        Appearance => appearance_page(app, ui),
        Commands => commands_page(app, ui),
        CommandBars => command_bars_page(app, ui),
        ColorPalette => color_palette_page(app, ui),
        Pick => pick_page(app, ui),
        ZoomPan => zoom_pan_page(app, ui),
        Rectangle => rectangle_page(app, ui),
        Ellipse => ellipse_page(app, ui),
        Polygon => polygon_page(app, ui),
        Spiral => spiral_page(app, ui),
        GraphPaper => graph_paper_page(app, ui),
        Table => table_page(app, ui),
        Eraser => eraser_page(app, ui),
        ShapeRecognition => shape_recognition_page(app, ui),
        Dimension => dimension_page(app, ui),
        AngularDimension => angular_dimension_page(app, ui),
        Connector => connector_page(app, ui),
        MeshFill => mesh_fill_page(app, ui),
        Curves => curves_page(app, ui),
        GlobalGeneral => global_general_page(app, ui),
        Printing => crate::ui::options_global::printing_page(app, ui),
        FileFormats => crate::ui::options_global::file_formats_page(app, ui),
        BitmapTracing => crate::ui::options_global::bitmap_tracing_page(app, ui),
        Warnings => crate::ui::options_global::warnings_page(app, ui),
        FileLocations => file_locations_page(app, ui),
        Workspace => workspace_page(app, ui),
        AiGeneral => crate::ui::ai_ui::general_page(app, ui),
        AiService => crate::ui::ai_ui::service_page(app, ui),
        DocumentGeneral => document_general_page(app, ui),
        PageSize => crate::ui::dialogs::page_size_page(app, ui),
        Layout => layout_page(app, ui),
        Background => background_page(app, ui),
        Bleed => bleed_page(app, ui),
        Rulers => crate::ui::layout_options::rulers_page(app, ui),
        Grid => crate::ui::layout_options::grid_page(app, ui),
        Guidelines => crate::ui::layout_options::guidelines_page(app, ui),
    }
}

/// A setting of an Options page or of Document Options, as Help > Search
/// Commands finds it: the key of its label, the key of its tip when it
/// has one, and the page (and tab of Options > Text) that shows it.
#[derive(Debug, Clone, PartialEq)]
pub struct SettingEntry {
    pub key: String,
    pub tip: Option<String>,
    pub page: OptionsPage,
    pub tab: usize,
}

/// Whether the translated text of `key` names a setting the search can
/// list: a short label of one line, without placeholders (tips, hints
/// and sentences are found through the label they belong to).
fn is_setting_label(key: &str) -> bool {
    const NOT_LABELS: [&str; 6] = ["_tip", "_desc", "_hint", "_help", "_note", "_title"];
    if NOT_LABELS.iter().any(|s| key.ends_with(s)) || !key.contains('.') {
        return false;
    }
    let text = tr(key);
    let text = text.trim();
    // A key with no text comes back as its last part.
    let missing = key.rsplit('.').next() == Some(text);
    !missing
        && !text.is_empty()
        && text.chars().count() <= 60
        && !text.contains(['{', '\n'])
        && text.chars().any(char::is_alphabetic)
}

/// The settings of every page of the Options and Document Options: each
/// page is drawn once, out of sight, and the labels it translates are
/// its settings, paired with their tips (`key_tip`, `key_desc`). The
/// page's own name opens it too. Options > Customization > Commands is
/// left out: its rows are the menu commands, listed already. Cheap
/// enough to run when the search box opens; the dialog's state is put
/// back.
pub fn settings_index(app: &mut App, ctx: &Context) -> Vec<SettingEntry> {
    let far = egui::Rect::from_min_size(
        egui::pos2(-100_000.0, -100_000.0),
        egui::vec2(620.0, 50_000.0),
    );
    let saved = (
        app.options_page,
        app.options_text_tab,
        app.shortcut_editor.capture.take(),
    );
    let mut out: Vec<SettingEntry> = Vec::new();
    for set in OptionsSet::ALL {
        for &page in set.pages() {
            if page == OptionsPage::Commands {
                continue;
            }
            out.push(SettingEntry {
                key: page.key().to_string(),
                tip: None,
                page,
                tab: 0,
            });
            let tabs = if page == OptionsPage::Text {
                TEXT_TABS.len()
            } else {
                1
            };
            for tab in 0..tabs {
                app.options_page = page;
                app.options_text_tab = tab;
                let id = egui::Id::new(("settings_walk", format!("{page:?}"), tab));
                let mut ui = Ui::new(
                    ctx.clone(),
                    id,
                    egui::UiBuilder::new()
                        .invisible()
                        .max_rect(far)
                        .layer_id(egui::LayerId::new(egui::Order::Background, id)),
                );
                let ((), keys) = crate::i18n::recording(|| draw_page(app, &mut ui));
                let seen: std::collections::HashSet<&str> =
                    keys.iter().map(String::as_str).collect();
                for key in &keys {
                    // A tab's name belongs to its own tab.
                    let other_tab = page == OptionsPage::Text
                        && TEXT_TABS
                            .iter()
                            .position(|k| k == key)
                            .is_some_and(|i| i != tab);
                    if other_tab
                        || out.iter().any(|e| e.page == page && &e.key == key)
                        || !is_setting_label(key)
                    {
                        continue;
                    }
                    let tip = ["_tip", "_desc"]
                        .iter()
                        .map(|s| format!("{key}{s}"))
                        .find(|k| seen.contains(k.as_str()));
                    out.push(SettingEntry {
                        key: key.clone(),
                        tip,
                        page,
                        tab,
                    });
                }
            }
        }
    }
    (
        app.options_page,
        app.options_text_tab,
        app.shortcut_editor.capture,
    ) = saved;
    out
}

/// A setting found with Help > Search Commands, shown framed on its page
/// for a moment when the Options open there.
#[derive(Debug, Clone, PartialEq)]
pub struct SettingHighlight {
    pub page: OptionsPage,
    /// The setting's label as the page draws it.
    pub label: String,
    /// When the frame began (the input's time), once drawn.
    pub since: Option<f64>,
}

/// Where a page lies, as the search shows it: "Options > Tools >
/// Rectangle", "Document Setup > General".
pub fn setting_place(page: OptionsPage) -> String {
    let set = page.set();
    let name = tr(page.key());
    if set == OptionsSet::Document {
        return format!("{} > {name}", set.tab_label());
    }
    format!(
        "{} > {} > {name}",
        tr("menu.tools.options"),
        set.tab_label()
    )
}

/// How long the frame stays, seconds.
const HIGHLIGHT_SECS: f64 = 2.5;

/// Open the Options (or Document Options) at `page` with the setting
/// `key` framed.
pub fn open_at_setting(app: &mut App, page: OptionsPage, tab: usize, key: &str) {
    app.dialog = crate::ui::dialogs::Dialog::Options;
    app.options_page = page;
    if page == OptionsPage::Text {
        app.options_text_tab = tab;
    }
    app.options_highlight = Some(SettingHighlight {
        page,
        label: tr(key).trim().to_string(),
        since: None,
    });
}

/// Where the page drew the text `label`, among the shapes of the
/// layer from `from` on.
fn text_rect(ctx: &Context, layer: egui::LayerId, from: usize, label: &str) -> Option<egui::Rect> {
    fn find(shape: &egui::Shape, label: &str) -> Option<egui::Rect> {
        match shape {
            egui::Shape::Text(t) if t.galley.text().trim() == label => {
                Some(t.galley.rect.translate(t.pos.to_vec2()))
            }
            egui::Shape::Vec(v) => v.iter().find_map(|s| find(s, label)),
            _ => None,
        }
    }
    ctx.graphics(|g| {
        g.get(layer)?
            .all_entries()
            .skip(from)
            .find_map(|c| find(&c.shape, label))
    })
}

/// Tests: where the last frame around a found setting was drawn.
#[cfg(test)]
pub fn highlighted_rect(ctx: &Context) -> Option<egui::Rect> {
    ctx.data(|d| d.get_temp::<egui::Rect>(egui::Id::new("options_highlight_rect")))
}

/// How many shapes the layer of `ui` holds so far.
fn shapes_drawn(ui: &Ui) -> usize {
    ui.ctx()
        .graphics(|g| g.get(ui.layer_id()).map_or(0, |l| l.all_entries().len()))
}

/// Frame the setting found with the search, drawn on this page since
/// `from` shapes: scrolled into view the first time, gone after
/// [`HIGHLIGHT_SECS`] or once another page shows.
fn highlight_setting(app: &mut App, ui: &mut Ui, from: usize) {
    let Some(mut h) = app.options_highlight.take() else {
        return;
    };
    if h.page != app.options_page {
        return;
    }
    let now = ui.input(|i| i.time);
    let since = *h.since.get_or_insert(now);
    if now - since > HIGHLIGHT_SECS {
        return;
    }
    if let Some(r) = text_rect(ui.ctx(), ui.layer_id(), from, &h.label) {
        let frame = r.expand2(egui::vec2(6.0, 3.0));
        if since == now {
            ui.scroll_to_rect(frame, Some(egui::Align::Center));
        }
        #[cfg(test)]
        ui.ctx()
            .data_mut(|d| d.insert_temp(egui::Id::new("options_highlight_rect"), frame));
        ui.painter().rect(
            frame,
            3.0,
            Tokens::ACCENT.gamma_multiply(0.15),
            egui::Stroke::new(2.0, Tokens::ACCENT),
            egui::StrokeKind::Outside,
        );
    }
    ui.ctx()
        .request_repaint_after(std::time::Duration::from_secs_f64(HIGHLIGHT_SECS));
    app.options_highlight = Some(h);
}

/// A label right-aligned in a grid's first column.
pub(crate) fn row_label(ui: &mut Ui, text: &str) {
    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
        // A drag on the label slides the number field of its row (#3044).
        let resp = ui.add(egui::Label::new(text).sense(egui::Sense::DRAG));
        crate::ui::field::label_slides(ui, &resp);
    });
}

pub(crate) fn grid(id: &str) -> egui::Grid {
    egui::Grid::new(id).num_columns(2).spacing([8.0, 8.0])
}

pub(crate) fn combo<T: Copy + PartialEq>(
    ui: &mut Ui,
    id: &str,
    value: &mut T,
    options: &[T],
    label: impl Fn(T) -> String,
    width: f32,
) -> bool {
    let mut changed = false;
    crate::ui::keynav::ComboBox::from_id_salt(id)
        .selected_text(label(*value))
        .width(width)
        .show_ui(ui, |ui| {
            for o in options {
                if ui.selectable_label(*value == *o, label(*o)).clicked() {
                    *value = *o;
                    changed = true;
                }
            }
        });
    changed
}

fn rgb_button(ui: &mut Ui, rgb: &mut [u8; 3]) -> bool {
    let resp = ui.color_edit_button_srgb(rgb);
    // A frame, so a white colour shows on the white page.
    ui.painter().rect_stroke(
        resp.rect,
        0.0,
        egui::Stroke::new(1.0, Tokens::control_border()),
        egui::StrokeKind::Inside,
    );
    resp.changed()
}

// ----- TraceDraw options -------------------------------------------------

/// Options that do something on the desktop only, and are not shown
/// elsewhere (#1415): the splash screen (the browser shows its own page
/// while loading; the Android app starts without one), hardware
/// acceleration and the graphics card (the browser draws with WebGL;
/// Android always draws with OpenGL ES, `gpu::ANDROID_BACKENDS`, and
/// never reads the setting) and the link for AI agents on this computer
/// (no agent on a phone or in a browser tab to serve).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DesktopOnly {
    Splash,
    HardwareAcceleration,
    Agents,
}

impl DesktopOnly {
    pub const ALL: [DesktopOnly; 3] = [
        DesktopOnly::Splash,
        DesktopOnly::HardwareAcceleration,
        DesktopOnly::Agents,
    ];

    /// Whether the option is shown on `platform`.
    pub fn shown_on(self, platform: crate::files::Platform) -> bool {
        platform == crate::files::Platform::Desktop
    }

    /// Whether the option is shown in this build.
    pub fn shown(self) -> bool {
        self.shown_on(crate::files::Platform::current())
    }
}

fn general_page(app: &mut App, ui: &mut Ui) {
    chrome::section(ui, &tr("options.getting_started"));
    ui.indent("gs", |ui| {
        grid("startup").show(ui, |ui| {
            row_label(ui, &trf("options.on_startup", &[("app", "TraceDraw")]));
            let mut s = app.settings.startup;
            let tip = crate::ui::tips::pair("options.startup", "options.startup_desc");
            let changed = crate::ui::tips::tip_over(ui, tip, |ui| {
                combo(ui, "startup", &mut s, &Startup::ALL, |v| tr(v.key()), 240.0)
            });
            if changed {
                app.settings.startup = s;
                app.settings.show_welcome_on_start = s == Startup::WelcomeScreen;
            }
            ui.end_row();
        });
        ui.checkbox(
            &mut app.settings.show_new_document_dialog,
            tr("options.show_new_document_dialog"),
        )
        .rich_tip(crate::ui::tips::keyed("options.show_new_document_dialog"));
        if DesktopOnly::Splash.shown() {
            ui.checkbox(&mut app.settings.show_splash, tr("options.show_splash"))
                .rich_tip(crate::ui::tips::keyed("options.show_splash"));
        }
        ui.checkbox(&mut app.settings.tracecut.show, tr("options.show_tracecut"))
            .rich_tip(crate::ui::tips::keyed("options.show_tracecut"));
        #[cfg(not(target_arch = "wasm32"))]
        if DesktopOnly::HardwareAcceleration.shown() {
            hardware_acceleration(app, ui);
        }
        // Linux: the desktop's title bar on a Wayland desktop that leaves
        // it to the application, from the next start (#2070); on by
        // default, as only that window takes file drops there (#2486).
        #[cfg(target_os = "linux")]
        ui.checkbox(
            &mut app.settings.system_title_bar,
            tr("options.system_title_bar"),
        )
        .rich_tip(crate::ui::tips::keyed("options.system_title_bar"));
        // The system's save dialog for Save As (#2965).
        #[cfg(not(any(target_arch = "wasm32", target_os = "android")))]
        ui.checkbox(
            &mut app.settings.system_save_dialog,
            tr("options.system_save_dialog"),
        )
        .rich_tip(crate::ui::tips::keyed("options.system_save_dialog"));
        // Minimize, Maximize and Close on the menu bar, for a window
        // without a title bar (#2574).
        #[cfg(not(any(target_arch = "wasm32", target_os = "android")))]
        ui.checkbox(
            &mut app.settings.window_buttons,
            tr("options.window_buttons"),
        )
        .rich_tip(crate::ui::tips::keyed("options.window_buttons"));
    });
    chrome::section(ui, &tr("options.undo_levels"));
    ui.indent("undo", |ui| {
        grid("undo_grid").show(ui, |ui| {
            row_label(ui, &tr("options.undo_regular"));
            ui.add_sized(
                [70.0, 22.0],
                crate::ui::field::NumField::new(&mut app.settings.undo_levels).range(1..=99_999),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.undo_levels",
                "options.undo_levels_desc",
            ));
            ui.end_row();
        });
    });
}

/// Use hardware acceleration and the graphics card (#445); they take
/// effect at the next start.
#[cfg(not(target_arch = "wasm32"))]
fn hardware_acceleration(app: &mut App, ui: &mut Ui) {
    let before = (
        app.settings.hardware_acceleration,
        app.settings.gpu_adapter.clone(),
    );
    ui.add_space(4.0);
    ui.horizontal(|ui| {
        ui.checkbox(
            &mut app.settings.hardware_acceleration,
            tr("options.hardware_acceleration"),
        )
        .rich_tip(crate::ui::tips::keyed("options.hardware_acceleration"));
        let on = app.settings.hardware_acceleration;
        let chosen = &mut app.settings.gpu_adapter;
        let shown = if chosen.is_empty() {
            tr("options.gpu_automatic")
        } else {
            chosen.clone()
        };
        ui.add_enabled_ui(on, |ui| {
            crate::ui::keynav::ComboBox::from_id_salt("gpu_adapter")
                .width(260.0)
                .selected_text(shown)
                .show_ui(ui, |ui| {
                    ui.selectable_value(chosen, String::new(), tr("options.gpu_automatic"))
                        .rich_tip(crate::ui::tips::pair(
                            "options.gpu_automatic",
                            "options.gpu_automatic_tip",
                        ));
                    for name in crate::gpu::adapters() {
                        ui.selectable_value(chosen, name.clone(), name);
                    }
                })
                .response
                .rich_tip_always(crate::ui::tips::keyed("options.gpu_adapter"));
        });
    });
    let dim = |ui: &mut Ui, text: String| {
        ui.label(
            egui::RichText::new(text)
                .color(Tokens::text_dim())
                .size(11.0),
        );
    };
    if let Some(name) = crate::gpu::in_use() {
        dim(ui, trf("options.gpu_in_use", &[("name", name)]));
    }
    dim(ui, tr("options.restart_to_apply"));
    // How fast this computer is, with this setting and the other one.
    if ui
        .button(tr("menu.help.benchmark"))
        .rich_tip(crate::ui::tips::pair(
            "menu.help.benchmark",
            "menu.help.benchmark_tip",
        ))
        .clicked()
    {
        app.dialog = crate::ui::dialogs::Dialog::Benchmark;
    }
    // What the card does and what the processor does, and why.
    ui.add_space(4.0);
    ui.scope(|ui| {
        ui.set_max_width(520.0);
        dim(ui, tr("options.gpu_explain"));
    });
    // Shadows blurred on the card: from this frame on, the same pixels
    // as on the processor; exports and printing stay on the processor.
    let available = crate::gpu_fx::available();
    ui.add_enabled_ui(app.settings.hardware_acceleration, |ui| {
        ui.checkbox(&mut app.settings.gpu_effects, tr("options.gpu_effects"))
            .rich_tip(crate::ui::tips::keyed("options.gpu_effects"));
    });
    if app.settings.gpu_effects && app.settings.hardware_acceleration && !available {
        dim(ui, tr("options.gpu_effects_unavailable"));
    }
    // A new choice is tried afresh at the next start.
    if (
        app.settings.hardware_acceleration,
        app.settings.gpu_adapter.clone(),
    ) != before
    {
        app.settings.working_renderer.clear();
    }
}

fn display_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(&mut app.proof_colors, tr("menu.view.proof_colors"))
        .rich_tip(crate::ui::tips::pair(
            "menu.view.proof_colors",
            "menu.view.proof_colors_tip",
        ));
    chrome::section(ui, &tr("options.other_controls"));
    ui.indent("oc", |ui| {
        ui.checkbox(&mut app.settings.show_tooltips, tr("options.show_tooltips"))
            .rich_tip(crate::ui::tips::pair(
                "options.show_tooltips",
                "options.show_tooltips_tip",
            ));
        ui.checkbox(
            &mut app.settings.hide_bbox_curve_tools,
            tr("options.hide_bbox_curve_tools"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.hide_bbox_curve_tools",
            "options.hide_bbox_curve_tools_tip",
        ));
        ui.checkbox(&mut app.settings.node_tracking, tr("options.node_tracking"))
            .rich_tip(crate::ui::tips::pair(
                "options.node_tracking",
                "options.node_tracking_tip",
            ));
        ui.checkbox(
            &mut app.settings.live_transform_preview,
            tr("options.live_transform_preview"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.live_transform_preview",
            "options.live_transform_preview_tip",
        ));
        ui.checkbox(&mut app.settings.touch_keys, tr("options.touch_keys"))
            .rich_tip(crate::ui::tips::pair(
                "options.touch_keys",
                "options.touch_keys_tip",
            ));
        ui.checkbox(
            &mut app.settings.touch_selection_bar,
            tr("options.touch_selection_bar"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.touch_selection_bar",
            "options.touch_selection_bar_tip",
        ));
        // Android has no mouse of its own: the bars show there already.
        if !crate::files::ANDROID {
            ui.checkbox(
                &mut app.settings.selection_bar_mouse,
                tr("options.selection_bar_mouse"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.selection_bar_mouse",
                "options.selection_bar_mouse_tip",
            ));
        }
    });
    chrome::section(ui, &tr("options.full_screen_preview"));
    ui.indent("fsp", |ui| {
        ui.checkbox(
            &mut app.settings.preview_page_border,
            tr("options.show_page_border"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.show_page_border",
            "options.show_page_border_tip",
        ));
    });
    ui.separator();
    grid("display_wheel").show(ui, |ui| {
        row_label(ui, &tr("options.wheel_default_action"));
        let mut zoom = app.settings.wheel_zooms;
        let tip = crate::ui::tips::pair(
            "options.wheel_default_action",
            "options.wheel_default_action_tip",
        );
        crate::ui::tips::tip_over(ui, tip, |ui| {
            combo(
                ui,
                "wheel",
                &mut zoom,
                &[true, false],
                |v| {
                    tr(if v {
                        "options.wheel_zoom"
                    } else {
                        "options.wheel_scroll"
                    })
                },
                120.0,
            );
        });
        app.settings.wheel_zooms = zoom;
        ui.end_row();
        row_label(ui, &tr("options.open_view"));
        let mut view = app.settings.open_view;
        let tip = crate::ui::tips::pair("options.open_view", "options.open_view_tip");
        ui.horizontal(|ui| {
            crate::ui::tips::tip_over(ui, tip, |ui| {
                combo(
                    ui,
                    "open_view",
                    &mut view,
                    &crate::settings::OpenView::ALL,
                    |v| tr(v.key()),
                    160.0,
                );
            });
            // Zoom level: the percent beside the list (#1266).
            if view == crate::settings::OpenView::Percent {
                ui.add(
                    crate::ui::field::NumField::new(&mut app.settings.open_zoom_percent)
                        .range(crate::settings::OPEN_ZOOM_RANGE)
                        .speed(1.0)
                        .suffix(" %"),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.open_view_percent",
                    "options.open_zoom_tip",
                ));
            }
        });
        app.settings.open_view = view;
        ui.end_row();
    });
    chrome::section(ui, &tr("options.ruler_calibration"));
    ui.label(
        egui::RichText::new(tr("options.calibrate_help"))
            .color(Tokens::text_dim())
            .size(12.0),
    );
    ui.horizontal(|ui| {
        ui.label(tr("options.screen_resolution"));
        let mut ppi = crate::settings::screen_ppi(&app.settings);
        if ui
            .add_sized(
                [80.0, 22.0],
                crate::ui::field::NumField::new(&mut ppi)
                    .range(48.0..=400.0)
                    .speed(0.1)
                    .max_decimals(1),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.screen_resolution",
                "options.screen_resolution_tip",
            ))
            .changed()
        {
            app.settings.screen_ppi = ppi;
        }
        ui.label(tr("options.points_per_inch"));
        if ui
            .button(tr("options.reset"))
            .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
            .clicked()
        {
            app.settings.screen_ppi = 96.0;
        }
    });
    calibration_rulers(ui, crate::settings::screen_points_per_inch(&app.settings));
    // The phone's notch and rounded corners (#1917).
    if crate::ui::screen_margins::OFFERED {
        crate::ui::screen_margins::options_section(ui, &mut app.settings.screen_margins);
    }
}

/// Two rulers drawn at the calibrated resolution, 100 mm and 4 inches
/// long, to hold a real ruler against.
fn calibration_rulers(ui: &mut Ui, ppi: f32) {
    let per_mm = ppi / 25.4;
    let pad = 8.0;
    // Room at the right end for the unit's name.
    let width = 100.0 * per_mm + pad + 30.0;
    for metric in [true, false] {
        let (rect, _) = ui.allocate_exact_size(egui::vec2(width, 36.0), egui::Sense::hover());
        let p = ui.painter();
        p.rect(
            rect,
            0.0,
            crate::theme::Tokens::field(),
            egui::Stroke::new(1.0, crate::theme::Tokens::control_border()),
            egui::StrokeKind::Inside,
        );
        let x0 = rect.left() + pad;
        let top = rect.top() + 1.0;
        let font = egui::FontId::proportional(10.0);
        let (count, step, label_every, unit) = if metric {
            (100, per_mm, 10, "mm")
        } else {
            // Eighths of an inch.
            (32, ppi / 8.0, 8, "in")
        };
        for i in 0..=count {
            let x = (x0 + i as f32 * step).round() + 0.5;
            let long = i % label_every == 0;
            let mid = if metric { i % 5 == 0 } else { i % 4 == 0 };
            let h = if long {
                14.0
            } else if mid {
                9.0
            } else {
                5.0
            };
            p.line_segment(
                [egui::pos2(x, top), egui::pos2(x, top + h)],
                egui::Stroke::new(1.0, Tokens::text()),
            );
            if long {
                let n = if metric { i } else { i / 8 };
                p.text(
                    egui::pos2(x, top + 16.0),
                    egui::Align2::CENTER_TOP,
                    n.to_string(),
                    font.clone(),
                    Tokens::text(),
                );
            }
        }
        p.text(
            egui::pos2(rect.right() - 4.0, rect.bottom() - 3.0),
            egui::Align2::RIGHT_BOTTOM,
            unit,
            font,
            Tokens::text_dim(),
        );
        ui.add_space(4.0);
    }
}

fn edit_page(app: &mut App, ui: &mut Ui) {
    grid("edit").show(ui, |ui| {
        row_label(ui, &tr("options.constrain_angle"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.constrain_angle", "options.constrain_angle_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    ui.add_sized(
                        [80.0, 22.0],
                        crate::ui::field::NumField::new(&mut app.settings.constrain_angle)
                            .range(0.1..=90.0)
                            .max_decimals(1)
                            .speed(0.5),
                    );
                    ui.label(tr("options.degrees"));
                });
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.drawing_precision"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.drawing_precision", "options.drawing_precision_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    ui.add_sized(
                        [80.0, 22.0],
                        crate::ui::field::NumField::new(&mut app.settings.precision).range(0..=10),
                    );
                    ui.label(tr("options.decimal_places"));
                });
            },
        );

        ui.end_row();
    });
    // Focus mode.
    crate::ui::chrome::section(ui, &tr("options.focus_inactive"));
    ui.horizontal(|ui| {
        let mut v = app.settings.focus_visibility as f32;
        // The slider takes the rest of the row but for the Reset button
        // after it, which stood past the panel's edge (#2199).
        let reset = egui::WidgetText::from(tr("dialog.reset"))
            .into_galley(
                ui,
                Some(egui::TextWrapMode::Extend),
                f32::INFINITY,
                egui::TextStyle::Button,
            )
            .size()
            .x
            + 2.0 * ui.spacing().button_padding.x
            + ui.spacing().item_spacing.x;
        if ui
            .add(
                crate::ui::Slider::new(&mut v, 0.0..=100.0)
                    .suffix(" %")
                    .integer()
                    .reserve(reset),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.focus_inactive",
                "options.focus_inactive_tip",
            ))
            .changed()
        {
            app.settings.focus_visibility = v.round() as u8;
        }
        if ui
            .button(tr("dialog.reset"))
            .rich_tip(crate::ui::tips::keyed("dialog.reset"))
            .clicked()
        {
            app.settings.focus_visibility = 20;
        }
    });
    ui.label(
        egui::RichText::new(tr("options.focus_inactive_hint"))
            .color(crate::theme::Tokens::text_dim()),
    );
    ui.add_space(6.0);
    ui.checkbox(
        &mut app.settings.focus_double_click,
        tr("options.focus_double_click"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.focus_double_click",
        "options.focus_double_click_tip",
    ));
}

fn shape_label(s: NodeShape) -> String {
    match s {
        NodeShape::Square => "\u{25FB}".into(),
        NodeShape::Circle => "\u{25CB}".into(),
        NodeShape::Diamond => "\u{2666}".into(),
    }
}

fn nodes_page(app: &mut App, ui: &mut Ui) {
    let n = &mut app.settings.nodes;
    grid("node_size").show(ui, |ui| {
        row_label(ui, &tr("options.node_size"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.node_size", "options.node_size_tip"),
            |ui| {
                combo(
                    ui,
                    "node_size",
                    &mut n.size,
                    &NodeSize::ALL,
                    |v| tr(v.key()),
                    100.0,
                );
            },
        );

        ui.end_row();
        // The Pick tool's selection handles (#1285).
        row_label(ui, &tr("options.handle_size"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.handle_size", "options.handle_size_tip"),
            |ui| {
                combo(
                    ui,
                    "handle_size",
                    &mut n.handles,
                    &HandleSize::ALL,
                    |v| tr(v.key()),
                    100.0,
                );
            },
        );

        ui.end_row();
    });
    chrome::section(ui, &tr("options.node_shape"));
    grid("node_shapes").show(ui, |ui| {
        row_label(ui, &tr("options.node_cusp"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.node_cusp", "options.node_cusp_tip"),
            |ui| {
                combo(ui, "cusp", &mut n.cusp, &NodeShape::ALL, shape_label, 50.0);
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.node_smooth"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.node_smooth", "options.node_smooth_tip"),
            |ui| {
                combo(
                    ui,
                    "smooth",
                    &mut n.smooth,
                    &NodeShape::ALL,
                    shape_label,
                    50.0,
                );
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.node_symmetrical"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.node_symmetrical", "options.node_symmetrical_tip"),
            |ui| {
                combo(
                    ui,
                    "symmetrical",
                    &mut n.symmetrical,
                    &NodeShape::ALL,
                    shape_label,
                    50.0,
                );
            },
        );

        ui.end_row();
        ui.label("");
        if chrome::button(ui, &tr("options.reset")).clicked() {
            let d = crate::settings::NodePrefs::default();
            n.cusp = d.cusp;
            n.smooth = d.smooth;
            n.symmetrical = d.symmetrical;
        }
        ui.end_row();
    });
    ui.checkbox(&mut n.show_direction, tr("options.show_curve_direction"))
        .rich_tip(crate::ui::tips::pair(
            "options.show_curve_direction",
            "options.show_curve_direction_tip",
        ));
    ui.checkbox(&mut n.corner_widgets, tr("options.corner_widgets"))
        .rich_tip(tr("options.corner_widgets_tip"));
    ui.add_enabled_ui(n.corner_widgets, |ui| {
        ui.indent("corner_one_at_a_time", |ui| {
            ui.checkbox(
                &mut n.corner_one_at_a_time,
                tr("options.corner_one_at_a_time"),
            )
            .rich_tip(tr("options.corner_one_at_a_time_tip"));
        });
    });
    ui.horizontal(|ui| {
        ui.label(tr("options.node_pick_distance"));
        ui.add(
            crate::ui::field::NumField::new(&mut n.pick_distance)
                .range(2.0..=20.0)
                .speed(0.2)
                .max_decimals(0)
                .suffix(" px"),
        )
        .rich_tip(tr("options.node_pick_distance_tip"));
        // On the same row, so the page keeps its height (#1679).
        ui.add_space(12.0);
        ui.label(tr("options.object_pick_distance"));
        ui.add(
            crate::ui::field::NumField::new(&mut n.object_pick_distance)
                .range(0.0..=20.0)
                .speed(0.2)
                .max_decimals(0)
                .suffix(" px"),
        )
        .rich_tip(tr("options.object_pick_distance_tip"));
    });
    chrome::section(ui, &tr("options.colors"));
    grid("node_colors").show(ui, |ui| {
        row_label(ui, &tr("options.main_color"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.main_color", "options.main_color_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    rgb_button(ui, &mut n.main_rgb);
                    if ui
                        .button(tr("options.reset"))
                        .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
                        .clicked()
                    {
                        n.main_rgb = crate::settings::NodePrefs::default().main_rgb;
                    }
                });
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.secondary_color"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.secondary_color", "options.secondary_color_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    rgb_button(ui, &mut n.secondary_rgb);
                    if ui
                        .button(tr("options.reset"))
                        .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
                        .clicked()
                    {
                        n.secondary_rgb = crate::settings::NodePrefs::default().secondary_rgb;
                    }
                });
            },
        );

        ui.end_row();
    });
    ui.checkbox(
        &mut n.unselected_filled,
        tr("options.unselected_nodes_filled"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.unselected_nodes_filled",
        "options.unselected_nodes_filled_tip",
    ));
    // Nodes in a colour for their type (#3000).
    ui.checkbox(&mut n.color_by_type, tr("options.node_color_by_type"))
        .rich_tip(crate::ui::tips::pair(
            "options.node_color_by_type",
            "options.node_color_by_type_tip",
        ));
    ui.add_enabled_ui(n.color_by_type, |ui| {
        ui.indent("node_type_colors", |ui| {
            ui.horizontal(|ui| {
                let d = crate::settings::NodePrefs::default();
                for (rgb, key, default) in [
                    (&mut n.cusp_rgb, "options.node_cusp_color", d.cusp_rgb),
                    (&mut n.smooth_rgb, "options.node_smooth_color", d.smooth_rgb),
                    (
                        &mut n.symmetrical_rgb,
                        "options.node_symmetrical_color",
                        d.symmetrical_rgb,
                    ),
                ] {
                    ui.label(tr(key));
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair(key, "options.node_type_color_tip"),
                        |ui| rgb_button(ui, rgb),
                    );
                    if *rgb != default {
                        if ui
                            .small_button(tr("options.reset"))
                            .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
                            .clicked()
                        {
                            *rgb = default;
                        }
                    }
                    ui.add_space(8.0);
                }
            });
        });
    });
}

fn clip_frame_page(app: &mut App, ui: &mut Ui) {
    let p = &mut app.settings.clip_frame;
    ui.label(tr("options.auto_center"));
    ui.indent("ac", |ui| {
        for (v, key) in [
            (AutoCenter::WhenOutside, "options.auto_center_outside"),
            (AutoCenter::Always, "options.auto_center_always"),
            (AutoCenter::Never, "options.auto_center_never"),
        ] {
            ui.radio_value(&mut p.auto_center, v, tr(key))
                .rich_tip_with(|| format!("{}\n{}", tr(key), tr(&format!("{key}_tip"))));
        }
    });
    ui.separator();
    ui.checkbox(&mut p.empty_lines, tr("options.empty_frame_lines"))
        .rich_tip(crate::ui::tips::pair(
            "options.empty_frame_lines",
            "options.empty_frame_lines_tip",
        ));
}

fn snapping_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(&mut app.snap.objects, tr("options.snap_to_objects"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_objects",
            "options.snap_to_objects_tip",
        ));
    ui.checkbox(&mut app.snap.page, tr("options.snap_to_page"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_page",
            "options.snap_to_page_tip",
        ));
    ui.horizontal(|ui| {
        ui.add_space(16.0);
        ui.label(tr("options.snapping_radius"));
        ui.add_sized(
            [70.0, 22.0],
            crate::ui::field::NumField::new(&mut app.settings.snap.threshold_px).range(1.0..=100.0),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.snapping_radius",
            "options.snapping_radius_tip",
        ));
        ui.label(tr("options.pixels"));
    });
    ui.checkbox(&mut app.snap.guides, tr("options.snap_to_guidelines"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_guidelines",
            "options.snap_to_guidelines_tip",
        ));
    ui.checkbox(&mut app.snap.grid, tr("options.snap_to_grid"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_grid",
            "options.snap_to_grid_tip",
        ));
    ui.checkbox(
        &mut app.snap.baseline_grid,
        tr("menu.view.snap_baseline_grid"),
    )
    .rich_tip(crate::ui::tips::pair(
        "menu.view.snap_baseline_grid",
        "menu.view.snap_baseline_grid_tip",
    ));
    ui.checkbox(&mut app.snap.pixels, tr("options.snap_to_pixels"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_pixels",
            "options.snap_to_pixels_tip",
        ));
    ui.checkbox(
        &mut app.settings.snap.show_marks,
        tr("options.show_snap_marks"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.show_snap_marks",
        "options.show_snap_marks_tip",
    ));
    ui.horizontal(|ui| {
        ui.add_space(16.0);
        ui.add_enabled(
            app.settings.snap.show_marks,
            egui::Checkbox::new(
                &mut app.settings.snap.screen_tips,
                tr("options.snap_screen_tip"),
            ),
        )
        .rich_tip_always(crate::ui::tips::pair(
            "options.snap_screen_tip",
            "options.snap_screen_tip_desc",
        ));
    });
    chrome::section(ui, &tr("options.snap_modes"));
    ui.indent("snap_modes", |ui| {
        let modes = &mut app.settings.snap.modes;
        for m in crate::snap_points::SnapMode::ALL {
            ui.horizontal(|ui| {
                let mut on = modes.get(m);
                if ui
                    .checkbox(&mut on, "")
                    .rich_tip_with(|| format!("{}\n{}", tr(m.key()), tr("options.snap_mode_tip")))
                    .changed()
                {
                    modes.set(m, on);
                }
                let (r, _) = ui.allocate_exact_size(egui::vec2(16.0, 16.0), egui::Sense::hover());
                crate::canvas::draw_snap_glyph(ui.painter(), r.center(), m, Tokens::icon());
                ui.label(tr(m.key()));
            });
        }
        ui.horizontal(|ui| {
            if ui
                .button(tr("options.select_all"))
                .rich_tip(crate::ui::tips::pair(
                    "options.select_all",
                    "options.select_all_tip",
                ))
                .clicked()
            {
                *modes = crate::snap_points::SnapModes::default();
            }
            if ui
                .button(tr("options.deselect_all"))
                .rich_tip(crate::ui::tips::pair(
                    "options.deselect_all",
                    "options.deselect_all_tip",
                ))
                .clicked()
            {
                *modes = crate::snap_points::SnapModes::none();
            }
        });
    });
}

/// A length typed in the document's units, kept in millimetres.
fn length_field(ui: &mut Ui, units: Units, mm: &mut f64, max_mm: f64) {
    let mut v = units.world_from_mm(*mm);
    let resp = ui.add_sized(
        [80.0, 22.0],
        crate::ui::field::NumField::new(&mut v)
            .range(0.0..=units.world_from_mm(max_mm))
            .max_decimals(3)
            .speed(0.1),
    );
    if resp.changed() && v.is_finite() {
        *mm = units.world_to_mm(v).clamp(0.0, max_mm);
    }
    ui.label(units.short());
}

/// The colour and line style of a kind of guide.
fn guide_look(
    ui: &mut Ui,
    id: &str,
    color: &mut [u8; 3],
    style: &mut crate::live_guides::GuideStyle,
) {
    grid(id).show(ui, |ui| {
        row_label(ui, &tr("options.guide_color"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.guide_color", "options.guide_color_tip"),
            |ui| {
                rgb_button(ui, color);
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.guide_style"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.guide_style", "options.guide_style_tip"),
            |ui| {
                combo(
                    ui,
                    &format!("{id}_style"),
                    style,
                    &crate::live_guides::GuideStyle::ALL,
                    |v| tr(v.key()),
                    140.0,
                );
            },
        );

        ui.end_row();
    });
}

/// Options > Alignment Guides: what lines up with what while objects are
/// moved, drawn or resized.
fn alignment_guides_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.snap.alignment_guides,
        tr("options.alignment_guides_on"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.alignment_guides_on",
        "options.alignment_guides_on_tip",
    ));
    let units = app.units;
    let on = app.snap.alignment_guides;
    let a = &mut app.settings.snap.align;
    ui.add_enabled_ui(on, |ui| {
        chrome::section(ui, &tr("options.align_moving"));
        ui.indent("align_moving", |ui| {
            ui.radio_value(
                &mut a.each_object,
                false,
                tr("options.align_selection_as_one"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.align_selection_as_one",
                "options.align_selection_as_one_tip",
            ));
            ui.radio_value(&mut a.each_object, true, tr("options.align_each_object"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_each_object",
                    "options.align_each_object_tip",
                ));
        });
        chrome::section(ui, &tr("options.align_what"));
        ui.indent("align_what", |ui| {
            ui.checkbox(&mut a.edges, tr("options.align_edges"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_edges",
                    "options.align_edges_tip",
                ));
            ui.checkbox(&mut a.centers, tr("options.align_centers"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_centers",
                    "options.align_centers_tip",
                ));
            ui.checkbox(&mut a.page, tr("options.align_page"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_page",
                    "options.align_page_tip",
                ));
            ui.checkbox(&mut a.equal_spacing, tr("options.align_equal_spacing"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_equal_spacing",
                    "options.align_equal_spacing_tip",
                ));
            ui.checkbox(&mut a.equal_size, tr("options.align_equal_size"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_equal_size",
                    "options.align_equal_size_tip",
                ));
        });
        chrome::section(ui, &tr("options.align_margins"));
        ui.indent("align_margins", |ui| {
            ui.checkbox(&mut a.margins, tr("options.align_margins_on"))
                .rich_tip(crate::ui::tips::pair(
                    "options.align_margins_on",
                    "options.align_margins_on_tip",
                ));
            ui.add_enabled_ui(a.margins, |ui| {
                grid("align_margin_values").show(ui, |ui| {
                    row_label(ui, &tr("options.align_offset"));
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair("options.align_offset", "options.align_offset_tip"),
                        |ui| {
                            ui.horizontal(|ui| length_field(ui, units, &mut a.offset_mm, 1000.0));
                        },
                    );

                    ui.end_row();
                    row_label(ui, &tr("options.align_inset"));
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair("options.align_inset", "options.align_inset_tip"),
                        |ui| {
                            ui.horizontal(|ui| length_field(ui, units, &mut a.inset_mm, 1000.0));
                        },
                    );

                    ui.end_row();
                });
            });
        });
        chrome::section(ui, &tr("options.guide_look"));
        guide_look(ui, "align_look", &mut a.color, &mut a.style);
        if ui
            .button(tr("options.reset"))
            .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
            .clicked()
        {
            *a = crate::live_guides::AlignOptions::default();
        }
    });
}

/// The angles offered as check boxes on the Dynamic Guides page.
const DYNAMIC_PRESETS: [f64; 12] = [
    0.0, 15.0, 30.0, 45.0, 60.0, 75.0, 90.0, 105.0, 120.0, 135.0, 150.0, 165.0,
];

/// Options > Dynamic Guides: the angles of the guides from acquired snap
/// points, their tip and ticks.
fn dynamic_guides_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.snap.dynamic_guides,
        tr("options.dynamic_guides_on"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.dynamic_guides_on",
        "options.dynamic_guides_on_tip",
    ));
    let units = app.units;
    let on = app.snap.dynamic_guides;
    let d = &mut app.settings.snap.dynamic;
    ui.add_enabled_ui(on, |ui| {
        chrome::section(ui, &tr("options.dynamic_angles"));
        ui.indent("dyn_angles", |ui| {
            let mut angles = d.clean_angles();
            egui::Grid::new("dyn_angle_grid")
                .num_columns(4)
                .show(ui, |ui| {
                    for (i, a) in DYNAMIC_PRESETS.iter().enumerate() {
                        let mut has = angles.iter().any(|b| (b - a).abs() < 1e-6);
                        if ui.checkbox(&mut has, format!("{a:.0}\u{00B0}")).changed() {
                            if has {
                                angles.push(*a);
                            } else {
                                angles.retain(|b| (b - a).abs() >= 1e-6);
                            }
                        }
                        if i % 4 == 3 {
                            ui.end_row();
                        }
                    }
                });
            // Other angles, each with a button that takes it away.
            let others: Vec<f64> = angles
                .iter()
                .copied()
                .filter(|a| !DYNAMIC_PRESETS.iter().any(|b| (b - a).abs() < 1e-6))
                .collect();
            if !others.is_empty() {
                ui.horizontal_wrapped(|ui| {
                    for a in others {
                        if ui
                            .button(format!("{a:.1}\u{00B0} \u{00D7}"))
                            .rich_tip(tr("options.dynamic_remove_angle"))
                            .clicked()
                        {
                            angles.retain(|b| (b - a).abs() >= 1e-6);
                        }
                    }
                });
            }
            ui.horizontal(|ui| {
                let id = egui::Id::new("dyn_new_angle");
                let mut v: f64 = ui.data_mut(|m| *m.get_temp_mut_or(id, 22.5));
                ui.add_sized(
                    [70.0, 22.0],
                    crate::ui::field::NumField::new(&mut v)
                        .range(0.0..=179.9)
                        .max_decimals(1),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.dynamic_new_angle",
                    "options.dynamic_new_angle_tip",
                ));
                ui.label(tr("options.degrees"));
                if ui
                    .button(tr("options.dynamic_add_angle"))
                    .rich_tip(crate::ui::tips::pair(
                        "options.dynamic_add_angle",
                        "options.dynamic_add_angle_tip",
                    ))
                    .clicked()
                    && v.is_finite()
                {
                    angles.push(v);
                }
                ui.data_mut(|m| m.insert_temp(id, v));
            });
            angles.sort_by(|a, b| a.total_cmp(b));
            if angles != d.angles {
                d.angles = angles;
            }
        });
        chrome::section(ui, &tr("options.dynamic_display"));
        ui.indent("dyn_display", |ui| {
            ui.checkbox(&mut d.tooltip, tr("options.dynamic_tooltip"))
                .rich_tip(crate::ui::tips::pair(
                    "options.dynamic_tooltip",
                    "options.dynamic_tooltip_tip",
                ));
            ui.checkbox(&mut d.ticks, tr("options.dynamic_ticks"))
                .rich_tip(crate::ui::tips::pair(
                    "options.dynamic_ticks",
                    "options.dynamic_ticks_tip",
                ));
            ui.add_enabled_ui(d.ticks, |ui| {
                grid("dyn_ticks").show(ui, |ui| {
                    row_label(ui, &tr("options.dynamic_tick_spacing"));
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair(
                            "options.dynamic_tick_spacing",
                            "options.dynamic_tick_spacing_tip",
                        ),
                        |ui| {
                            ui.horizontal(|ui| length_field(ui, units, &mut d.tick_mm, 10_000.0));
                        },
                    );

                    ui.end_row();
                });
                ui.checkbox(&mut d.snap_ticks, tr("options.dynamic_snap_ticks"))
                    .rich_tip(crate::ui::tips::pair(
                        "options.dynamic_snap_ticks",
                        "options.dynamic_snap_ticks_tip",
                    ));
            });
        });
        chrome::section(ui, &tr("options.guide_look"));
        guide_look(ui, "dyn_look", &mut d.color, &mut d.style);
        if ui
            .button(tr("options.reset"))
            .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
            .clicked()
        {
            *d = crate::live_guides::DynamicOptions::default();
        }
    });
}

/// A read-only path with a Browse button for the folder of `place`: it
/// picks a folder on the desktop; elsewhere it is greyed with the reason,
/// or (a folder that is read) true comes back when it is pressed, for the
/// caller to pick the files (#1399).
fn path_field(
    ui: &mut Ui,
    dir: &mut Option<std::path::PathBuf>,
    fallback: String,
    place: crate::files::FolderUse,
) -> bool {
    use crate::files::FolderAction;
    let text = dir
        .as_ref()
        .map(|p| p.display().to_string())
        .unwrap_or(fallback);
    let action = place.action();
    let mut files = false;
    ui.horizontal(|ui| {
        ui.add_enabled(
            false,
            egui::TextEdit::singleline(&mut text.clone()).desired_width(320.0),
        )
        .rich_tip_always(crate::ui::tips::pair(
            "options.folder",
            "options.folder_tip",
        ));
        let tip = match place.tip() {
            Some(why) => crate::ui::tips::pair("options.browse", why),
            None => crate::ui::tips::pair("options.browse", "options.browse_tip"),
        };
        let browse = ui
            .add_enabled(
                !matches!(action, FolderAction::Unavailable(_)),
                egui::Button::new(tr("options.browse")),
            )
            .rich_tip_always(tip);
        if browse.clicked() {
            match action {
                FolderAction::PickFolder(token) => {
                    if let Some(p) = crate::files::pick_folder(token) {
                        *dir = Some(p);
                    }
                }
                FolderAction::OpenFiles => files = true,
                FolderAction::SaveZip | FolderAction::Unavailable(_) => {}
            }
        }
    });
    files
}

fn save_page(app: &mut App, ui: &mut Ui) {
    let b = &mut app.settings.backup;
    chrome::section(ui, &tr("options.backup"));
    ui.indent("bk", |ui| {
        ui.checkbox(&mut b.before_save, tr("options.backup_before_save"))
            .rich_tip(crate::ui::tips::pair(
                "options.backup_before_save",
                "options.backup_before_save_tip",
            ));
        ui.add_enabled_ui(b.before_save, |ui| {
            let mut choose = b.before_save_dir.is_some();
            ui.horizontal(|ui| {
                ui.label(tr("options.backup_to"));
                ui.vertical(|ui| {
                    ui.radio_value(&mut choose, false, tr("options.same_folder"))
                        .rich_tip(crate::ui::tips::pair(
                            "options.same_folder",
                            "options.same_folder_tip",
                        ));
                    ui.radio_value(&mut choose, true, tr("options.choose_location"))
                        .rich_tip(crate::ui::tips::pair(
                            "options.choose_location",
                            "options.choose_location_tip",
                        ));
                });
            });
            if choose && b.before_save_dir.is_none() {
                b.before_save_dir = Some(std::env::temp_dir());
            } else if !choose {
                b.before_save_dir = None;
            }
            ui.add_enabled_ui(choose, |ui| {
                path_field(
                    ui,
                    &mut b.before_save_dir,
                    String::new(),
                    crate::files::FolderUse::BackupFolder,
                );
            });
        });
    });
    chrome::section(ui, &tr("options.auto_backup"));
    ui.indent("ab", |ui| {
        ui.horizontal(|ui| {
            ui.checkbox(&mut b.auto, tr("options.backup_every"))
                .rich_tip(crate::ui::tips::pair(
                    "options.backup_every",
                    "options.backup_every_tip",
                ));
            ui.add_enabled(
                b.auto,
                crate::ui::field::NumField::new(&mut b.minutes).range(1..=999),
            )
            .rich_tip_always(crate::ui::tips::pair(
                "options.backup_every",
                "options.backup_minutes_tip",
            ));
            ui.label(tr("options.minutes"));
        });
        // A browser keeps them in the page's storage and Android in the
        // app's folder: Browse is greyed with the reason (#1399).
        ui.add_enabled_ui(b.auto, |ui| {
            path_field(
                ui,
                &mut b.auto_dir,
                crate::app::App::auto_backup_dir_default()
                    .map(|p| p.display().to_string())
                    .unwrap_or_default(),
                crate::files::FolderUse::AutoBackupFolder,
            );
        });
    });
}

/// The tabs of Options > Text, in order.
pub const TEXT_TABS: [&str; 5] = [
    "options.display",
    "options.paragraph_text",
    "docker.fonts",
    "options.spelling",
    "dialog.autocorrect",
];

/// Options > Text > Autocorrect's tab.
pub const AUTOCORRECT_TAB: usize = 4;

/// Options > Text: Display, Paragraph Text, Fonts, Spelling and
/// Autocorrect tabs.
fn text_page(app: &mut App, ui: &mut Ui) {
    ui.horizontal(|ui| {
        for (i, key) in TEXT_TABS.iter().enumerate() {
            if ui
                .selectable_label(app.options_text_tab == i, tr(key))
                .rich_tip_with(|| format!("{}\n{}", tr(key), tr("options.set_tab_desc")))
                .clicked()
            {
                app.options_text_tab = i;
            }
        }
    });
    ui.separator();
    match app.options_text_tab {
        0 => text_display_tab(app, ui),
        1 => paragraph_text_tab(app, ui),
        2 => fonts_tab(app, ui),
        3 => spelling_tab(app, ui),
        _ => autocorrect_tab(app, ui),
    }
}

fn text_display_tab(app: &mut App, ui: &mut Ui) {
    grid("text_display").show(ui, |ui| {
        row_label(ui, &tr("options.keyboard_text_increment"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair(
                "options.keyboard_text_increment",
                "options.keyboard_text_increment_tip",
            ),
            |ui| {
                ui.horizontal(|ui| {
                    ui.add_sized(
                        [70.0, 22.0],
                        crate::ui::field::NumField::new(&mut app.settings.text_increment_pt)
                            .range(0.1..=100.0)
                            .max_decimals(1),
                    );
                    ui.label(tr("options.points"));
                });
            },
        );

        ui.end_row();
        // The font and size of new text, whatever text is selected (#449).
        // The unit of font sizes everywhere (#529): points, or millimetres
        // and the like for large work.
        row_label(ui, &tr("options.text_units"));
        let u = app.text_units();
        let tip = crate::ui::tips::pair("options.text_units", "options.text_units_tip");
        crate::ui::tips::tip_over(ui, tip, |ui| {
            crate::ui::keynav::ComboBox::from_id_salt("options_text_units")
                .selected_text(u.label())
                .width(160.0)
                .show_ui(ui, |ui| {
                    for v in Units::ALL {
                        if ui.selectable_label(v == u, v.label()).clicked() {
                            app.settings.text_units = v.id().to_string();
                        }
                    }
                });
        });
        ui.end_row();
        row_label(ui, &tr("options.default_font"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.default_font", "options.default_font_tip"),
            |ui| {
                crate::ui::font_list::default_font_list(app, ui, "options_default_font", 220.0);
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.default_size"));
        let u = app.text_units();
        let mut shown = u.from_pt(app.text_default_size);
        if ui
            .add(
                crate::ui::field::NumField::new(&mut shown)
                    .range(u.from_pt(1.0)..=u.from_pt(999.0))
                    .max_decimals(if u == Units::Points { 1 } else { 3 })
                    .unit_mm(u.mm())
                    .suffix(format!(" {}", u.short())),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.default_size",
                "options.default_size_tip",
            ))
            .changed()
        {
            app.text_default_size = u.to_pt(shown);
            if !app.has_text_target() {
                app.text_size_pt = app.text_default_size;
            }
        }
        ui.end_row();
    });
    ui.checkbox(
        &mut app.show_non_printing,
        tr("menu.text.show_non_printing"),
    )
    .rich_tip(crate::ui::tips::pair(
        "menu.text.show_non_printing",
        "menu.text.show_non_printing_tip",
    ));
}

fn paragraph_text_tab(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.settings.show_text_frames,
        tr("menu.text.show_text_frames"),
    )
    .rich_tip(crate::ui::tips::pair(
        "menu.text.show_text_frames",
        "menu.text.show_text_frames_tip",
    ));
    ui.checkbox(&mut app.text_hyphenation, tr("menu.text.use_hyphenation"))
        .rich_tip(crate::ui::tips::pair(
            "menu.text.use_hyphenation",
            "menu.text.use_hyphenation_tip",
        ));
    // Where a tab goes in a paragraph with no stops of its own (#1852).
    grid("default_tab_spacing").show(ui, |ui| {
        row_label(ui, &tr("options.default_tab_spacing"));
        let u = app.units;
        let mut shown = u.from_mm(app.settings.default_tab_mm);
        if ui
            .add(
                crate::ui::field::NumField::new(&mut shown)
                    .range(u.from_mm(1.0)..=u.from_mm(100.0))
                    .max_decimals(3)
                    .unit_mm(u.mm())
                    .suffix(format!(" {}", u.short())),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.default_tab_spacing",
                "options.default_tab_spacing_tip",
            ))
            .changed()
        {
            app.settings.default_tab_mm = u.to_mm(shown).clamp(1.0, 100.0);
            tracedraw_core::set_default_tab_step(app.settings.default_tab_mm);
            app.raster.borrow_mut().invalidate();
        }
        ui.end_row();
    });
    // The pattern files, read when the tab shows a new folder.
    type Found = (
        Option<std::path::PathBuf>,
        Vec<crate::spell::DictionaryFile>,
    );
    let cache = ui.id().with("hyphenation_found");
    let sp = &mut app.settings.spelling;
    let key = sp.dictionary_folder.clone();
    let mut found: Option<Found> = ui.data(|d| d.get_temp(cache));
    // Dictionaries downloaded or added since: read the list again.
    let generation_id = ui.id().with("hyphenation_generation");
    let generation = crate::spell::generation();
    if ui.data(|d| d.get_temp::<u64>(generation_id)) != Some(generation) {
        ui.data_mut(|d| d.insert_temp(generation_id, generation));
        found = None;
    }
    if found.as_ref().is_none_or(|(k, _)| *k != key) {
        found = Some((key.clone(), crate::spell::find_hyphenation(key.as_deref())));
    }
    let list = found.as_ref().map(|f| f.1.clone()).unwrap_or_default();
    let shown = |name: &str| {
        if name.is_empty() {
            tr("options.hyphenation_builtin")
        } else {
            name.strip_prefix("hyph_").unwrap_or(name).to_string()
        }
    };
    grid("hyphenation_patterns").show(ui, |ui| {
        row_label(ui, &tr("options.hyphenation_patterns"));
        crate::ui::keynav::ComboBox::from_id_salt("hyphenation_patterns_combo")
            .width(220.0)
            .selected_text(shown(&sp.hyphenation_patterns))
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut sp.hyphenation_patterns, String::new(), shown(""));
                for d in &list {
                    ui.selectable_value(
                        &mut sp.hyphenation_patterns,
                        d.name.clone(),
                        shown(&d.name),
                    )
                    .rich_tip(d.dic.display().to_string());
                }
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.hyphenation_patterns",
                "options.hyphenation_patterns_tip",
            ));
        ui.end_row();
    });
    ui.label(egui::RichText::new(tr("options.hyphenation_note")).color(Tokens::text_dim()));
    if let Some(f) = found {
        ui.data_mut(|d| d.insert_temp(cache, f));
    }
}

fn fonts_tab(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.settings.show_recent_fonts,
        tr("options.show_recent_fonts"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.show_recent_fonts",
        "options.show_recent_fonts_tip",
    ));
    ui.add_enabled_ui(app.settings.show_recent_fonts, |ui| {
        ui.horizontal(|ui| {
            ui.label(tr("options.recent_font_count"));
            ui.add(
                crate::ui::field::NumField::new(&mut app.settings.recent_font_count)
                    .range(1..=crate::ui::font_list::RECENT_MAX),
            )
            .rich_tip_always(crate::ui::tips::pair(
                "options.recent_font_count",
                "options.recent_font_count_tip",
            ));
        });
    });
    ui.horizontal(|ui| {
        ui.label(tr("options.font_sample_size"));
        ui.add(
            crate::ui::field::NumField::new(&mut app.settings.font_sample_px)
                .range(crate::ui::font_list::SAMPLE_SIZES)
                .max_decimals(0)
                .suffix(" pt"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.font_sample_size",
            "options.font_sample_size_tip",
        ));
    });
}

/// Options > Text > Spelling: download a dictionary of the collection, or
/// add dictionary files (#1405).
fn dictionary_download_row(app: &mut App, ui: &mut Ui) {
    use crate::dictionary_download as dl;
    let chosen_id = ui.id().with("dictionary_download_code");
    let mut code: String = ui
        .data(|d| d.get_temp(chosen_id))
        .unwrap_or_else(|| default_dictionary_code(&crate::i18n::language()));
    ui.horizontal(|ui| {
        ui.label(tr("options.download_dictionary"));
        let shown = dl::entry(&code)
            .map(|e| e.name.to_string())
            .unwrap_or_else(|| code.clone());
        crate::ui::keynav::ComboBox::from_id_salt("dictionary_download")
            .selected_text(shown)
            .width(200.0)
            .show_ui(ui, |ui| {
                for e in dl::CATALOG {
                    ui.selectable_value(&mut code, e.code.to_string(), e.name)
                        .on_hover_text(e.license);
                }
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.download_dictionary",
                "options.download_dictionary_tip",
            ));
        let busy = dl::downloading(&code);
        let label = if busy {
            tr("options.downloading")
        } else {
            tr("options.download")
        };
        let licence = dl::entry(&code).map(|e| e.license).unwrap_or("");
        if ui
            .add_enabled(!busy, egui::Button::new(label))
            .rich_tip(format!(
                "{}\n{}",
                crate::ui::tips::pair(
                    "options.download_dictionary",
                    "options.download_dictionary_tip"
                ),
                crate::i18n::trf("options.dictionary_licence", &[("l", licence)])
            ))
            .clicked()
        {
            dl::start(&code, false);
            let kept = &mut app.settings.spelling.downloaded_dictionaries;
            if !kept.contains(&code) {
                kept.push(code.clone());
            }
        }
        if ui
            .button(tr("options.add_dictionary_files"))
            .rich_tip(crate::ui::tips::pair(
                "options.add_dictionary_files",
                "options.add_dictionary_files_tip",
            ))
            .clicked()
        {
            add_dictionary_files(app);
        }
    });
    ui.data_mut(|d| d.insert_temp(chosen_id, code));
}

/// Pick Hunspell files (`.dic` and `.aff`, several at once) and add them
/// to TraceDraw's own dictionaries.
fn add_dictionary_files(app: &mut App) {
    crate::files::Dialog::new()
        .add_filter("Hunspell", &["dic", "aff"])
        .pick_files(app, |app, paths| {
            let n = crate::dictionary_download::add_files(&paths);
            app.status = crate::i18n::trf("status.dictionaries_added", &[("n", &n.to_string())]);
        });
}

/// The dictionary offered first: the interface language's when the
/// collection has it (`pt-BR` is its `pt`), else English.
fn default_dictionary_code(language: &str) -> String {
    let lang = language.replace('_', "-");
    let base = lang.split('-').next().unwrap_or("");
    let code = match lang.as_str() {
        "pt-BR" => "pt",
        "pt-PT" => "pt-PT",
        "en-GB" => "en-GB",
        _ => base,
    };
    match crate::dictionary_download::entry(code) {
        Some(e) => e.code.to_string(),
        None => "en".to_string(),
    }
}

fn spelling_tab(app: &mut App, ui: &mut Ui) {
    let p = &mut app.settings.spelling;
    ui.checkbox(&mut p.ignore_digits, tr("writing.ignore_digits"))
        .rich_tip(crate::ui::tips::pair(
            "writing.ignore_digits",
            "writing.ignore_digits_tip",
        ));
    ui.checkbox(&mut p.ignore_capitals, tr("writing.ignore_capitals"))
        .rich_tip(crate::ui::tips::pair(
            "writing.ignore_capitals",
            "writing.ignore_capitals_tip",
        ));
    ui.checkbox(&mut p.add_to_autocorrect, tr("options.add_to_autocorrect"))
        .rich_tip(crate::ui::tips::pair(
            "options.add_to_autocorrect",
            "options.add_to_autocorrect_tip",
        ));
    ui.add_space(4.0);
    ui.label(egui::RichText::new(tr("options.spelling_note")).color(Tokens::text_dim()));
    chrome::section(ui, &tr("options.dictionaries"));
    // The folders are read when the tab shows a new folder or on Refresh,
    // not every frame.
    type Found = (
        Option<std::path::PathBuf>,
        Vec<crate::spell::DictionaryFile>,
    );
    let cache = ui.id().with("dictionaries_found");
    let key = p.dictionary_folder.clone();
    let mut found: Option<Found> = ui.data(|d| d.get_temp(cache));
    // Dictionaries downloaded or added since: read the list again.
    let generation_id = ui.id().with("dictionaries_generation");
    let generation = crate::spell::generation();
    if ui.data(|d| d.get_temp::<u64>(generation_id)) != Some(generation) {
        ui.data_mut(|d| d.insert_temp(generation_id, generation));
        found = None;
    }
    if found.as_ref().is_none_or(|(k, _)| *k != key) {
        found = Some((key.clone(), crate::spell::find_dictionaries(key.as_deref())));
    }
    let list = found.as_ref().map(|f| f.1.clone()).unwrap_or_default();
    egui::Frame::new()
        .fill(Tokens::field())
        .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
        .inner_margin(egui::Margin::same(4))
        .show(ui, |ui| {
            egui::ScrollArea::vertical()
                .id_salt("dictionaries_list")
                .max_height(120.0)
                .auto_shrink([false, true])
                .show(ui, |ui| {
                    // The spell checker of Windows, switched off like a
                    // dictionary (#1405).
                    let system = crate::spell::system_languages();
                    if !system.is_empty() {
                        let name = crate::spell::SYSTEM_CHECKER;
                        let mut on = !p.disabled_dictionaries.iter().any(|n| n == name);
                        if ui
                            .checkbox(
                                &mut on,
                                format!(
                                    "{}  ({})",
                                    tr("options.windows_spell_checker"),
                                    system.join(", ")
                                ),
                            )
                            .changed()
                        {
                            p.disabled_dictionaries.retain(|n| n != name);
                            if !on {
                                p.disabled_dictionaries.push(name.to_string());
                            }
                        }
                    }
                    if list.is_empty() && system.is_empty() {
                        ui.label(
                            egui::RichText::new(tr("options.no_dictionaries"))
                                .color(Tokens::text_dim()),
                        );
                    }
                    for d in &list {
                        let mut on = !p.disabled_dictionaries.contains(&d.name);
                        let label = if d.aff.is_some() {
                            d.name.clone()
                        } else {
                            format!("{}  ({})", d.name, tr("options.word_list"))
                        };
                        if ui
                            .checkbox(&mut on, label)
                            .rich_tip(d.dic.display().to_string())
                            .changed()
                        {
                            p.disabled_dictionaries.retain(|n| *n != d.name);
                            if !on {
                                p.disabled_dictionaries.push(d.name.clone());
                            }
                        }
                    }
                });
        });
    let own = crate::spell::own_folder();
    let mut add_files = false;
    grid("dictionary_folders").show(ui, |ui| {
        // A browser has no folders: its dictionaries are downloaded or
        // added below.
        if crate::files::WEB {
            return;
        }
        row_label(ui, &tr("options.dictionaries_folder"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair(
                "options.dictionaries_folder",
                "options.dictionaries_folder_tip",
            ),
            |ui| {
                ui.horizontal(|ui| {
                    let mut text = own
                        .as_ref()
                        .map(|p| p.display().to_string())
                        .unwrap_or_default();
                    ui.add_enabled(
                        false,
                        egui::TextEdit::singleline(&mut text).desired_width(320.0),
                    );
                    // Android shows no app's private folder in another
                    // app (#1398): the button says so instead.
                    let mut open = ui.add_enabled(
                        own.is_some() && !crate::files::WEB && !crate::files::ANDROID,
                        egui::Button::new(tr("options.open_folder")),
                    );
                    if crate::files::ANDROID {
                        open = open.rich_disabled_tip(crate::ui::tips::pair(
                            "options.open_folder",
                            "options.open_folder_android",
                        ));
                    }
                    if open.clicked() {
                        if let Some(dir) = &own {
                            let _ = std::fs::create_dir_all(dir);
                            if let Err(e) = crate::export::open_with_system(dir) {
                                app.status = e;
                            }
                        }
                    }
                });
            },
        );

        ui.end_row();
        let p = &mut app.settings.spelling;
        row_label(ui, &tr("options.more_dictionaries"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.more_dictionaries", "options.more_dictionaries_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    // Where no folder can be read, Browse picks the
                    // Hunspell files, as Add Dictionary Files does (#1399).
                    add_files = path_field(
                        ui,
                        &mut p.dictionary_folder,
                        String::new(),
                        crate::files::FolderUse::DictionaryFolder,
                    );
                    if ui
                        .add_enabled(
                            p.dictionary_folder.is_some(),
                            egui::Button::new(tr("options.clear_folder")),
                        )
                        .clicked()
                    {
                        p.dictionary_folder = None;
                    }
                });
            },
        );

        ui.end_row();
    });
    if add_files {
        add_dictionary_files(app);
    }
    dictionary_download_row(app, ui);
    if ui
        .button(tr("options.refresh_dictionaries"))
        .rich_tip(crate::ui::tips::pair(
            "options.refresh_dictionaries",
            "options.refresh_dictionaries_tip",
        ))
        .clicked()
    {
        found = None;
        crate::spell::reload();
        let hyph = ui.id().with("hyphenation_found");
        ui.data_mut(|d| d.remove::<Found>(hyph));
    }
    ui.data_mut(|d| match found {
        Some(f) => {
            d.insert_temp(cache, f);
        }
        None => {
            d.remove::<Found>(cache);
        }
    });
}

/// A quotation mark list (one of [`crate::autocorrect::QUOTE_CHOICES`]).
fn quote_combo(ui: &mut Ui, id: &str, tip: String, value: &mut char) -> bool {
    let mut changed = false;
    crate::ui::keynav::ComboBox::from_id_salt(id)
        .width(48.0)
        .selected_text(value.to_string())
        .show_ui(ui, |ui| {
            for q in crate::autocorrect::QUOTE_CHOICES {
                changed |= ui.selectable_value(value, q, q.to_string()).changed();
            }
        })
        .response
        .rich_tip(tip);
    changed
}

fn autocorrect_tab(app: &mut App, ui: &mut Ui) {
    let style = app.settings.autocorrect.style();
    let p = &mut app.settings.autocorrect;
    ui.checkbox(&mut p.capitalize_sentences, tr("autocorrect.capitalize"))
        .rich_tip(crate::ui::tips::pair(
            "autocorrect.capitalize",
            "autocorrect.capitalize_tip",
        ));
    ui.checkbox(
        &mut p.fix_two_initial_capitals,
        tr("autocorrect.two_capitals"),
    )
    .rich_tip(crate::ui::tips::pair(
        "autocorrect.two_capitals",
        "autocorrect.two_capitals_tip",
    ));
    ui.checkbox(&mut p.capitalize_days, tr("autocorrect.days"))
        .rich_tip(crate::ui::tips::pair(
            "autocorrect.days",
            "autocorrect.days_tip",
        ));
    ui.checkbox(&mut p.auto_hyperlinks, tr("autocorrect.hyperlinks"))
        .rich_tip(crate::ui::tips::pair(
            "autocorrect.hyperlinks",
            "autocorrect.hyperlinks_tip",
        ));
    ui.separator();
    grid("autocorrect_language").show(ui, |ui| {
        row_label(ui, &tr("autocorrect.language"));
        let shown = crate::i18n::LANGUAGES
            .iter()
            .find(|(code, _)| *code == p.quote_language)
            .map(|(_, name)| name.to_string())
            .unwrap_or_else(|| tr("autocorrect.interface_language"));
        let before = p.quote_language.clone();
        crate::ui::keynav::ComboBox::from_id_salt("autocorrect_quote_language")
            .width(220.0)
            .selected_text(shown)
            .show_ui(ui, |ui| {
                ui.selectable_value(
                    &mut p.quote_language,
                    String::new(),
                    tr("autocorrect.interface_language"),
                )
                .rich_tip(crate::ui::tips::pair(
                    "autocorrect.interface_language",
                    "autocorrect.interface_language_tip",
                ));
                for (code, name) in crate::i18n::LANGUAGES {
                    ui.selectable_value(&mut p.quote_language, code.to_string(), name);
                }
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "autocorrect.language",
                "autocorrect.language_tip",
            ));
        // Another language brings its own quotation marks.
        if p.quote_language != before {
            p.single_quotes = None;
            p.double_quotes = None;
        }
        ui.end_row();
    });
    ui.checkbox(&mut p.typographic_quotes, tr("autocorrect.quotes"))
        .rich_tip(crate::ui::tips::pair(
            "autocorrect.quotes",
            "autocorrect.quotes_tip",
        ));
    ui.checkbox(
        &mut p.straight_after_numbers,
        tr("autocorrect.straight_after_numbers"),
    )
    .rich_tip(crate::ui::tips::pair(
        "autocorrect.straight_after_numbers",
        "autocorrect.straight_after_numbers_tip",
    ));
    let style = if p.quote_language.is_empty() {
        style
    } else {
        p.style()
    };
    ui.add_enabled_ui(p.typographic_quotes, |ui| {
        grid("autocorrect_quotes").show(ui, |ui| {
            for (label, single) in [
                ("autocorrect.single_quotes", true),
                ("autocorrect.double_quotes", false),
            ] {
                row_label(ui, &tr(label));
                let (mut o, mut c) = if single {
                    p.single(style)
                } else {
                    p.double(style)
                };
                let mut changed = false;
                ui.horizontal(|ui| {
                    ui.label(tr("autocorrect.open"));
                    let tip = crate::ui::tips::pair("autocorrect.open", "autocorrect.open_tip");
                    changed |= quote_combo(ui, &format!("{label}_open"), tip, &mut o);
                    ui.add_space(12.0);
                    ui.label(tr("autocorrect.close"));
                    let tip = crate::ui::tips::pair("autocorrect.close", "autocorrect.close_tip");
                    changed |= quote_combo(ui, &format!("{label}_close"), tip, &mut c);
                });
                if changed {
                    if single {
                        p.single_quotes = Some([o, c]);
                    } else {
                        p.double_quotes = Some([o, c]);
                    }
                }
                ui.end_row();
            }
        });
    });
    ui.separator();
    ui.label(egui::RichText::new(tr("autocorrect.replacements")).strong());
    ui.checkbox(
        &mut p.replace_while_typing,
        tr("autocorrect.replace_while_typing"),
    )
    .rich_tip(crate::ui::tips::pair(
        "autocorrect.replace_while_typing",
        "autocorrect.replace_while_typing_tip",
    ));
    let from_id = ui.id().with("autocorrect_from");
    let to_id = ui.id().with("autocorrect_to");
    let row_id = ui.id().with("autocorrect_row");
    let mut from: String = ui.data(|d| d.get_temp(from_id)).unwrap_or_default();
    let mut to: String = ui.data(|d| d.get_temp(to_id)).unwrap_or_default();
    let mut picked: Option<usize> = ui.data(|d| d.get_temp(row_id)).flatten();
    if picked.is_some_and(|i| i >= p.replacements.len()) {
        picked = None;
    }
    let key = from.trim().to_string();
    let existing = p.replacements.iter().position(|(f, _)| *f == key);
    let usable = !key.is_empty() && !key.contains(char::is_whitespace);
    ui.horizontal(|ui| {
        ui.label(tr("autocorrect.replace_col"));
        ui.add(egui::TextEdit::singleline(&mut from).desired_width(130.0))
            .rich_tip(crate::ui::tips::pair(
                "autocorrect.replace_col",
                "autocorrect.replace_col_tip",
            ));
        ui.add_space(10.0);
        ui.label(tr("autocorrect.with_col"));
        ui.add(egui::TextEdit::singleline(&mut to).desired_width(130.0))
            .rich_tip(crate::ui::tips::pair(
                "autocorrect.with_col",
                "autocorrect.with_col_tip",
            ));
    });
    ui.horizontal(|ui| {
        if ui
            .add_enabled(
                usable && existing.is_none(),
                egui::Button::new(tr("autocorrect.add")),
            )
            .rich_tip_always(crate::ui::tips::pair(
                "autocorrect.add",
                "autocorrect.add_tip",
            ))
            .clicked()
        {
            p.replacements.push((key.clone(), to.clone()));
            from.clear();
            to.clear();
        }
        if ui
            .add_enabled(
                picked.is_some(),
                egui::Button::new(tr("autocorrect.delete")),
            )
            .rich_tip_always(crate::ui::tips::pair(
                "autocorrect.delete",
                "autocorrect.delete_tip",
            ))
            .clicked()
        {
            if let Some(i) = picked.take() {
                p.replacements.remove(i);
            }
            from.clear();
            to.clear();
        }
        if ui
            .add_enabled(
                usable && existing.is_some(),
                egui::Button::new(tr("autocorrect.replace")),
            )
            .rich_tip_always(crate::ui::tips::pair(
                "autocorrect.replace",
                "autocorrect.replace_tip",
            ))
            .clicked()
        {
            if let Some(i) = existing {
                p.replacements[i].1 = to.clone();
            }
        }
    });
    egui::Frame::new()
        .fill(Tokens::field())
        .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
        .inner_margin(egui::Margin::same(4))
        .show(ui, |ui| {
            egui::ScrollArea::vertical()
                .id_salt("autocorrect_table")
                .max_height(150.0)
                .auto_shrink([false, true])
                .show(ui, |ui| {
                    egui::Grid::new("autocorrect_rows")
                        .num_columns(2)
                        .min_col_width(160.0)
                        .show(ui, |ui| {
                            for (i, (f, t)) in p.replacements.iter().enumerate() {
                                let on = picked == Some(i);
                                let tip = || {
                                    crate::ui::tips::pair(
                                        "autocorrect.replacement",
                                        "autocorrect.replacement_tip",
                                    )
                                };
                                let a = ui.selectable_label(on, f.as_str()).rich_tip(tip());
                                let b = ui.selectable_label(on, t.as_str()).rich_tip(tip());
                                if a.clicked() || b.clicked() {
                                    picked = Some(i);
                                    from = f.clone();
                                    to = t.clone();
                                }
                                ui.end_row();
                            }
                        });
                });
        });
    ui.data_mut(|d| {
        d.insert_temp(from_id, from);
        d.insert_temp(to_id, to);
        d.insert_temp(row_id, picked);
    });
    ui.add_space(4.0);
    if ui
        .button(tr("autocorrect.apply_selection"))
        .rich_tip(crate::ui::tips::pair(
            "autocorrect.apply_selection",
            "autocorrect.apply_selection_tip",
        ))
        .clicked()
    {
        if app.text_shapes().is_empty() {
            app.status = tr("autocorrect.no_selection");
        } else {
            let n = crate::autocorrect::apply_to_selection(app);
            app.status = trf("autocorrect.applied", &[("n", &n.to_string())]);
        }
    }
}

// ----- Customization -----------------------------------------------------

/// The interface sizes the Appearance slider offers, in percent.
const UI_SIZE_RANGE: std::ops::RangeInclusive<f32> = 75.0..=250.0;

/// Customization > Appearance: where dialogs open, the interface size
/// and the desktop colour.
fn appearance_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.settings.center_dialogs,
        tr("options.center_dialogs"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.center_dialogs",
        "options.center_dialogs_tip",
    ));
    ui.checkbox(&mut app.settings.ui_shadows, tr("options.ui_shadows"))
        .rich_tip(tr("options.ui_shadows_tip"));
    ui.horizontal(|ui| {
        ui.checkbox(
            &mut app.settings.translucent_menus,
            tr("options.translucent_menus"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.translucent_menus",
            "options.translucent_menus_tip",
        ));
        let mut pct = app.settings.menu_opacity * 100.0;
        let tip = crate::ui::tips::pair("options.menu_opacity", "options.menu_opacity_tip");
        let field = ui
            .add_enabled(
                app.settings.translucent_menus,
                crate::ui::field::NumField::new(&mut pct)
                    .range(crate::theme::MENU_OPACITY_MIN * 100.0..=100.0)
                    .speed(1.0)
                    .max_decimals(0)
                    .suffix(" %"),
            )
            .rich_tip(tip.clone())
            .rich_disabled_tip(tip);
        if field.changed() {
            app.settings.menu_opacity = (pct / 100.0).clamp(crate::theme::MENU_OPACITY_MIN, 1.0);
        }
    });
    ui.checkbox(&mut app.settings.colored_icons, tr("options.colored_icons"))
        .rich_tip(tr("options.colored_icons_tip"));
    ui.checkbox(
        &mut app.settings.docker_tabs_icons_only,
        tr("options.docker_tabs_icons_only"),
    )
    .rich_tip(tr("options.docker_tabs_icons_only_tip"));
    crate::ui::chrome::section(ui, &tr("options.ui_size"));
    // The size takes effect when the slider is let go or the field is
    // left, so the page does not grow under the pointer.
    let pending = ui.id().with("ui_size_pending");
    let current = crate::ui::interface_size(app.settings.ui_size) * 100.0;
    let mut pct: f32 = ui.data(|d| d.get_temp(pending)).unwrap_or(current);
    let mut reset = false;
    let busy = ui
        .horizontal(|ui| {
            let slider = ui
                .add(
                    crate::ui::Slider::new(&mut pct, UI_SIZE_RANGE)
                        .step_by(5.0)
                        .show_value(false)
                        .trailing_fill(true)
                        .width(220.0),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.interface_size",
                    "options.ui_size_tip",
                ));
            let field = ui
                .add(
                    crate::ui::field::NumField::new(&mut pct)
                        .range(UI_SIZE_RANGE)
                        .speed(1.0)
                        .max_decimals(0)
                        .suffix(" %"),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.interface_size",
                    "options.ui_size_tip",
                ));
            reset = ui
                .button(tr("options.reset_to_default"))
                .rich_tip(crate::ui::tips::pair(
                    "options.reset_to_default",
                    "options.reset_to_default_tip",
                ))
                .clicked();
            slider.dragged() || field.dragged() || field.has_focus()
        })
        .inner;
    if reset {
        app.settings.ui_size = 0.0;
        ui.data_mut(|d| d.remove::<f32>(pending));
    } else if busy {
        ui.data_mut(|d| d.insert_temp(pending, pct));
    } else {
        ui.data_mut(|d| d.remove::<f32>(pending));
        if (pct - current).abs() > 0.5 {
            app.settings.ui_size = pct.round() / 100.0;
        }
    }
    ui.label(egui::RichText::new(tr("options.ui_scale_hint")).color(Tokens::text_dim()));
    let sys = crate::system_prefs::get();
    // Greyed with the reason where the system's text size cannot be read
    // (#1412): macOS has none for programs of this kind.
    let label = if sys.text_scale_known {
        crate::i18n::trf(
            "options.follow_text_size",
            &[("n", &format!("{:.0}", sys.text_scale * 100.0))],
        )
    } else {
        tr("options.follow_text_size_title")
    };
    ui.add_enabled(
        sys.text_scale_known,
        egui::Checkbox::new(&mut app.settings.follow_text_size, label),
    )
    .rich_tip_with(|| {
        format!(
            "{}\n{}",
            tr("options.follow_text_size_title"),
            tr("options.follow_text_size_tip")
        )
    })
    .rich_disabled_tip(crate::ui::tips::pair(
        "options.follow_text_size_title",
        text_size_unread_key(),
    ));
    crate::ui::chrome::section(ui, &tr("options.color_section"));
    grid("appearance_color").show(ui, |ui| {
        row_label(ui, &tr("options.theme"));
        // With none picked yet, the desktop's light or dark one (#2748).
        let current =
            crate::theme::Theme::from_id(&crate::settings::chosen_theme_with(&app.settings, sys));
        let tip = crate::ui::tips::pair("options.theme", "options.theme_tip");
        crate::ui::tips::tip_over(ui, tip, |ui| {
            crate::ui::keynav::ComboBox::from_id_salt("ui_theme")
                .selected_text(tr(current.key()))
                .width(170.0)
                .show_ui(ui, |ui| {
                    for t in crate::theme::Theme::ALL {
                        if ui.selectable_label(t == current, tr(t.key())).clicked() {
                            app.settings.theme = t.id().to_string();
                        }
                    }
                });
        });
        ui.end_row();
        row_label(ui, "");
        let on = sys.high_contrast.is_some();
        ui.add_enabled(
            sys.contrast_known,
            egui::Checkbox::new(
                &mut app.settings.follow_high_contrast,
                tr(if on {
                    "options.follow_high_contrast_on"
                } else {
                    "options.follow_high_contrast"
                }),
            ),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.follow_high_contrast_title",
            "options.follow_high_contrast_tip",
        ))
        .rich_disabled_tip(crate::ui::tips::pair(
            "options.follow_high_contrast_title",
            "options.follow_high_contrast_unread",
        ));
        ui.end_row();
        row_label(ui, &tr("options.desktop_color"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.desktop_color", "options.desktop_color_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    // The colour shown is the one around the page, the theme's
                    // until one is picked; any pick counts, white too (#530).
                    let [r, g, b, _] = app.desktop_color().to_array();
                    let mut rgb = [r, g, b];
                    if rgb_button(ui, &mut rgb) {
                        app.settings.desktop_rgb = rgb;
                        app.settings.desktop_custom = true;
                    }
                    if ui
                        .button(tr("options.reset"))
                        .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
                        .clicked()
                    {
                        app.settings.desktop_rgb = [255, 255, 255];
                        app.settings.desktop_custom = false;
                    }
                });
            },
        );

        ui.end_row();
    });
}

/// Customization > Color Palette: the document palette, the swatches and
/// what the right mouse button does on them.
fn color_palette_page(app: &mut App, ui: &mut Ui) {
    let p = &mut app.settings.palette;
    ui.checkbox(
        &mut p.auto_update_document,
        tr("options.palette_auto_update"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.palette_auto_update",
        "options.palette_auto_update_tip",
    ));
    ui.checkbox(&mut p.show_document, tr("options.palette_show_document"))
        .rich_tip(crate::ui::tips::pair(
            "options.palette_show_document",
            "options.palette_show_document_tip",
        ));
    crate::ui::chrome::section(ui, &tr("options.palette_swatches"));
    ui.checkbox(&mut p.show_no_color, tr("options.palette_no_color"))
        .rich_tip(crate::ui::tips::pair(
            "options.palette_no_color",
            "options.palette_no_color_tip",
        ));
    palette_layout_grid(app, ui);
    let p = &mut app.settings.palette;
    crate::ui::chrome::section(ui, &tr("options.palette_right_button"));
    ui.radio_value(
        &mut p.right_click_outline,
        false,
        tr("options.palette_context_menu"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.palette_context_menu",
        "options.palette_context_menu_tip",
    ));
    ui.radio_value(
        &mut p.right_click_outline,
        true,
        tr("options.palette_set_outline"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.palette_set_outline",
        "options.palette_set_outline_tip",
    ));
    if p.right_click_outline {
        ui.horizontal(|ui| {
            ui.add_space(22.0);
            ui.label(
                egui::RichText::new(tr("options.palette_hold_hint")).color(Tokens::text_dim()),
            );
        });
    }
}

/// The default palette's place, rows and swatch size on the Color
/// Palette page, set as the palette's own menu sets them: a floating
/// palette takes the rows at its length, and a palette put elsewhere goes
/// there at once (#1983).
fn palette_layout_grid(app: &mut App, ui: &mut Ui) {
    use crate::ui::bars::{Bar, Dock};
    use crate::ui::palette::Row;
    use crate::ui::palette_bars::{set_dock, set_rows, set_swatch, PLACES};
    let dock = app.settings.bars.dock(Bar::Palette);
    let floating = dock == Dock::Floating;
    grid("palette_rows").show(ui, |ui| {
        // Where it lies: a side of the window, or floating.
        row_label(ui, &tr("options.palette_position"));
        let locked = app.settings.bars.locked;
        let mut place = dock;
        let changed = ui
            .add_enabled_ui(!locked, |ui| {
                crate::ui::tips::tip_over(
                    ui,
                    crate::ui::tips::pair(
                        "options.palette_position",
                        "options.palette_position_tip",
                    ),
                    |ui| {
                        let docks: Vec<Dock> = PLACES.iter().map(|(d, _)| *d).collect();
                        combo(
                            ui,
                            "opt_palette_position",
                            &mut place,
                            &docks,
                            |d| {
                                PLACES
                                    .iter()
                                    .find(|(p, _)| *p == d)
                                    .map(|(_, k)| tr(k))
                                    .unwrap_or_default()
                            },
                            140.0,
                        )
                    },
                )
            })
            .inner;
        if changed && place != dock {
            set_dock(app, Row::Main, place, None);
        }
        ui.end_row();
        // Rows of the default palette (columns docked on a side, #610);
        // floating, the lines its window shows.
        row_label(ui, &tr("options.palette_rows"));
        let mut rows = if floating {
            crate::ui::palette::lines_of(app, Row::Main).min(usize::from(crate::settings::MAX_ROWS))
                as u8
        } else {
            app.settings.palette.rows.min(crate::settings::MAX_ROWS)
        };
        let before = rows;
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.palette_rows", "options.palette_rows_tip"),
            |ui| {
                combo(
                    ui,
                    "opt_palette_rows",
                    &mut rows,
                    &[1, 2, 3, 4, 5, 6, 7, 8, crate::settings::ROWS_FIT],
                    |n| {
                        if n == crate::settings::ROWS_FIT {
                            tr("palette.rows_fit")
                        } else {
                            n.to_string()
                        }
                    },
                    90.0,
                );
            },
        );
        if rows != before {
            set_rows(app, Row::Main, rows);
        }
        ui.end_row();
        // The swatch size, as the palette menu names its steps; a size
        // set with Ctrl+wheel between two shows as it is.
        row_label(ui, &tr("options.palette_swatch_size"));
        let mut size = app.settings.palette.swatch_size;
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair(
                "options.palette_swatch_size",
                "options.palette_swatch_size_tip",
            ),
            |ui| {
                let mut sizes: Vec<u8> = crate::settings::SWATCH_STEPS
                    .iter()
                    .map(|(s, _)| *s)
                    .collect();
                if !sizes.contains(&size) {
                    sizes.push(size);
                    sizes.sort_unstable();
                }
                combo(
                    ui,
                    "opt_palette_swatch_size",
                    &mut size,
                    &sizes,
                    |n| match crate::settings::swatch_step_of(n) {
                        Some(i) => tr(crate::settings::SWATCH_STEPS[i].1),
                        None => trf("palette.size_custom", &[("n", &n.to_string())]),
                    },
                    140.0,
                );
            },
        );
        if size != app.settings.palette.swatch_size {
            set_swatch(app, Row::Main, size);
        }
        ui.end_row();
    });
}

/// Options > Customization > Commands: the menu commands found, the
/// search text, the command waiting for its keys and what the last
/// shortcut set took over.
#[derive(Debug, Clone, Default)]
pub struct ShortcutEditor {
    pub entries: Vec<crate::ui::menus::invoke::Entry>,
    pub filter: String,
    pub capture: Option<String>,
    pub note: Option<String>,
    /// The list shows one menu (its title key), the toolbox
    /// ([`TOOLBOX`]) or everything (`None`).
    pub category: Option<String>,
    /// The command picked in the list (a menu key or a tool id).
    pub selected: Option<String>,
    /// The tab beside the list: General (false) or Shortcut Keys (true).
    pub keys_tab: bool,
    /// Reset all shortcuts was pressed: the question is shown.
    pub confirm_reset_all: bool,
    /// The General tab's list of pictures to choose a command's icon
    /// from is open (#2100).
    pub icon_picker: bool,
    /// The page shows the Node editing table (`Settings::node_shortcuts`,
    /// keys that hold only with the Shape tool) instead of the main one
    /// (#3243).
    pub node_table: bool,
}

/// The Commands page's category for the toolbox's tools.
pub const TOOLBOX: &str = "toolbox";
/// The commands category of the loaded VBA macros.
pub const MACROS: &str = "macros";
/// The commands category of the Standard and Zoom toolbars' own buttons
/// (#836).
pub const BUTTONS: &str = "toolbar_buttons";

/// The user's shortcut for `id` (a menu key or a tool id).
fn user_shortcut(app: &App, id: &str) -> Option<String> {
    app.settings
        .shortcuts
        .iter()
        .find(|(k, _)| k == id)
        .map(|(_, v)| v.clone())
}

/// Give the command `id` (a menu command's key or a tool's id) the
/// shortcut `text`. Every other command with it loses it, so one key
/// runs one command: another command of the user's loses that entry;
/// a command or tool that has it built in is left with an empty shortcut
/// (as Delete leaves it, so its keys do nothing until Reset gives them
/// back, #1595). The commands that lost the keys are named in the note.
fn set_menu_shortcut(app: &mut App, id: &str, text: &str) {
    use crate::shortcuts::same;
    let mut others: Vec<String> = Vec::new();
    for (k, v) in &app.settings.shortcuts {
        if k != id && same(v, text) {
            others.push(menu_or_tool_name(app, k));
        }
    }
    app.settings
        .shortcuts
        .retain(|(k, v)| k == id || !same(v, text));
    // Built-in holders without keys of their own: the key was theirs
    // alone, so they are left without one. The Node editing table takes
    // nothing from them: its key holds over theirs with the Shape tool
    // only (#3243).
    let node = app.shortcut_editor.node_table;
    let mut lost: Vec<String> = Vec::new();
    for e in app.shortcut_editor.entries.iter().filter(|_| !node) {
        if e.key != id && same(&e.shortcut, text) && user_shortcut(app, &e.key).is_none() {
            others.push(command_label(e));
            lost.push(e.key.clone());
        }
    }
    for t in crate::tools::Tool::ALL.iter().filter(|_| !node) {
        if t.id() != id
            && user_shortcut(app, t.id()).is_none()
            && t.shortcut().is_some_and(|s| same(s, text))
        {
            others.push(t.name());
            lost.push(t.id().to_string());
        }
    }
    for k in lost {
        app.settings.shortcuts.push((k, String::new()));
    }
    // The keys it had stay (a command may have several, #822): a built-in
    // key joins the user's list first so that it keeps working.
    if user_shortcut(app, id).is_none() && !node {
        if let Some(b) = built_in_keys(app, id) {
            app.settings.shortcuts.push((id.to_string(), b));
        }
    }
    let has = app
        .settings
        .shortcuts
        .iter()
        .any(|(k, v)| k == id && same(v, text));
    if !has {
        app.settings
            .shortcuts
            .push((id.to_string(), text.to_string()));
    }
    others.dedup();
    app.shortcut_editor.note = (!others.is_empty()).then(|| {
        trf(
            "options.shortcut_taken",
            &[("keys", text), ("others", &others.join(", "))],
        )
    });
}

/// The keys `id` has built in (a menu command's or a tool's), if any.
fn built_in_keys(app: &App, id: &str) -> Option<String> {
    let menu = app
        .shortcut_editor
        .entries
        .iter()
        .find(|e| e.key == id)
        .map(|e| e.shortcut.clone());
    let tool = crate::tools::Tool::ALL
        .iter()
        .find(|t| t.id() == id)
        .and_then(|t| t.shortcut())
        .map(str::to_string);
    menu.or(tool).filter(|k| !k.is_empty())
}

/// "File > Export...": the menus a command sits in and its name.
fn command_label(e: &crate::ui::menus::invoke::Entry) -> String {
    let mut parts: Vec<String> = e.path.iter().map(|k| tr(k)).collect();
    parts.push(match crate::macros::command_name(&e.key) {
        Some((name, _)) => name,
        None => tr(&e.key),
    });
    parts
        .iter()
        .map(|p| p.trim_end_matches("...").to_string())
        .collect::<Vec<_>>()
        .join(" > ")
}

fn menu_or_tool_name(app: &App, id: &str) -> String {
    if let Some(e) = app.shortcut_editor.entries.iter().find(|e| e.key == id) {
        return command_label(e);
    }
    crate::tools::Tool::ALL
        .iter()
        .find(|t| t.id() == id)
        .map(|t| t.name())
        .unwrap_or_else(|| id.to_string())
}

/// One row of the command list: a menu command or a toolbox tool.
#[derive(Debug, Clone)]
struct CommandItem {
    id: String,
    name: String,
    /// "File > Export" for a menu command, the toolbox for a tool.
    place: String,
    built_in: String,
    tool: Option<crate::tools::Tool>,
}

/// The rows of `category`, filtered by `filter` (lower case).
fn command_items(app: &App, category: Option<&str>, filter: &str) -> Vec<CommandItem> {
    let mut out = Vec::new();
    if category.is_none_or(|c| c != TOOLBOX && c != BUTTONS) {
        for e in &app.shortcut_editor.entries {
            let top = e.path.first().map(String::as_str);
            let is_macro = e.key.starts_with("menu.macro.");
            match category {
                Some(MACROS) if !is_macro => continue,
                Some(c) if c != MACROS && top != Some(c) => continue,
                _ => {}
            }
            let label = command_label(e);
            let name = match crate::macros::command_name(&e.key) {
                Some((name, _)) => name,
                None => tr(&e.key).trim_end_matches("...").to_string(),
            };
            out.push(CommandItem {
                id: e.key.clone(),
                name,
                place: label,
                built_in: e.shortcut.clone(),
                tool: None,
            });
        }
    }
    if category.is_none_or(|c| c == TOOLBOX) {
        for t in crate::tools::Tool::ALL {
            out.push(CommandItem {
                id: t.id().to_string(),
                name: t.name(),
                place: tr("menu.window.toolbar_toolbox"),
                built_in: t.shortcut().unwrap_or("").to_string(),
                tool: Some(t),
            });
        }
    }
    // The bars' own buttons, so one taken off a bar can be put back
    // (#836).
    if category.is_none_or(|c| c == BUTTONS) {
        for id in crate::ui::bar_items::all_buttons() {
            out.push(CommandItem {
                id: id.to_string(),
                name: crate::ui::toolbar::item_name(id).unwrap_or_else(|| id.to_string()),
                place: tr("options.toolbar_buttons"),
                built_in: String::new(),
                tool: None,
            });
        }
    }
    if !filter.is_empty() {
        out.retain(|c| {
            c.name.to_lowercase().contains(filter) || c.place.to_lowercase().contains(filter)
        });
    }
    out
}

/// The commands the Commands page lists: [`command_items`] in
/// alphabetical order. In menu order a command
/// was slow to find in a long category (#3212).
fn listed_commands(app: &App, category: Option<&str>, filter: &str) -> Vec<CommandItem> {
    let mut out = command_items(app, category, filter);
    out.sort_by_cached_key(|c| c.name.to_lowercase());
    out
}

const LIST_W: f32 = 240.0;
const LIST_H: f32 = 330.0;
const ROW_H: f32 = 24.0;

/// Options > Customization > Commands: a category and a search above the
/// list of commands (with their pictures); beside it the picked
/// command's General and Shortcut Keys tabs.
fn commands_page(app: &mut App, ui: &mut Ui) {
    // The shortcut table shown (#3243): Main, or Node editing, whose keys
    // hold only while the Shape tool is chosen. The page edits the table
    // shown as `Settings::shortcuts` while it draws.
    ui.horizontal(|ui| {
        ui.label(tr("options.shortcut_table"));
        let mut node = app.shortcut_editor.node_table;
        let name = |n: bool| {
            tr(if n {
                "options.shortcut_table_node"
            } else {
                "options.shortcut_table_main"
            })
        };
        crate::ui::keynav::ComboBox::from_id_salt("shortcut_table")
            .selected_text(name(node))
            .width(200.0)
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut node, false, name(false));
                ui.selectable_value(&mut node, true, name(true));
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.shortcut_table",
                "options.shortcut_table_tip",
            ));
        if node != app.shortcut_editor.node_table {
            app.shortcut_editor.node_table = node;
            app.shortcut_editor.capture = None;
            app.shortcut_editor.note = None;
            app.shortcut_editor.confirm_reset_all = false;
        }
    });
    if app.shortcut_editor.node_table {
        ui.label(
            egui::RichText::new(tr("options.shortcut_table_node_hint"))
                .color(Tokens::text_dim())
                .size(11.0),
        );
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
        commands_page_body(app, ui);
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
    } else {
        commands_page_body(app, ui);
    }
}

/// The Commands page for the table shown, which is `Settings::shortcuts`
/// while it draws.
fn commands_page_body(app: &mut App, ui: &mut Ui) {
    if app.shortcut_editor.entries.is_empty() {
        let ctx = ui.ctx().clone();
        app.shortcut_editor.entries = crate::ui::menus::commands(app, &ctx);
    }
    capture_keys(app, ui);
    ui.label(
        egui::RichText::new(tr("options.toolbar_drag_hint"))
            .color(Tokens::text_dim())
            .size(11.0),
    );
    // The shortcuts the browser keeps and the keys that replace them
    // there (#1409).
    if crate::shortcuts::web_keys() {
        ui.label(
            egui::RichText::new(trf(
                "options.browser_keys",
                &[("keys", &crate::shortcuts::browser_keys_list())],
            ))
            .color(Tokens::text_dim())
            .size(11.0),
        );
    }
    let category_name = |c: Option<&str>| match c {
        None => tr("options.all_commands"),
        Some(TOOLBOX) => tr("menu.window.toolbar_toolbox"),
        Some(MACROS) => tr("options.macros_category"),
        Some(BUTTONS) => tr("options.toolbar_buttons"),
        Some(k) => tr(k),
    };
    ui.horizontal(|ui| {
        let current = app.shortcut_editor.category.clone();
        crate::ui::keynav::ComboBox::from_id_salt("command_category")
            .selected_text(category_name(current.as_deref()))
            .width(LIST_W - 8.0)
            .show_ui(ui, |ui| {
                let mut pick = current.clone();
                ui.selectable_value(&mut pick, None, category_name(None));
                for k in crate::ui::menus::menu_titles() {
                    ui.selectable_value(&mut pick, Some(k.to_string()), category_name(Some(k)));
                }
                ui.selectable_value(
                    &mut pick,
                    Some(TOOLBOX.to_string()),
                    category_name(Some(TOOLBOX)),
                );
                ui.selectable_value(
                    &mut pick,
                    Some(MACROS.to_string()),
                    category_name(Some(MACROS)),
                );
                ui.selectable_value(
                    &mut pick,
                    Some(BUTTONS.to_string()),
                    category_name(Some(BUTTONS)),
                );
                app.shortcut_editor.category = pick;
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.command_category",
                "options.command_category_tip",
            ));
        ui.add_space(12.0);
        ui.label(tr("options.find_command"));
        ui.add(egui::TextEdit::singleline(&mut app.shortcut_editor.filter).desired_width(180.0))
            .rich_tip(crate::ui::tips::pair(
                "options.find_command",
                "options.find_command_tip",
            ));
    });
    ui.add_space(4.0);
    let filter = app.shortcut_editor.filter.trim().to_lowercase();
    let items = listed_commands(app, app.shortcut_editor.category.as_deref(), &filter);
    if app
        .shortcut_editor
        .selected
        .as_ref()
        .is_none_or(|s| !items.iter().any(|c| &c.id == s))
    {
        app.shortcut_editor.selected = items.first().map(|c| c.id.clone());
    }
    ui.horizontal_top(|ui| {
        egui::Frame::new()
            .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
            .fill(crate::theme::Tokens::field())
            .show(ui, |ui| {
                ui.set_width(LIST_W);
                ui.vertical(|ui| {
                    ui.spacing_mut().item_spacing.y = 0.0;
                    egui::ScrollArea::vertical()
                        .id_salt("command_list")
                        .auto_shrink([false, false])
                        .max_height(LIST_H)
                        .min_scrolled_height(LIST_H)
                        .show_rows(ui, ROW_H, items.len(), |ui, rows| {
                            for i in rows {
                                if let Some(c) = items.get(i) {
                                    command_list_row(app, ui, c);
                                }
                            }
                        });
                });
            });
        ui.add_space(10.0);
        ui.vertical(|ui| {
            ui.set_max_width(ui.available_width());
            let selected = app
                .shortcut_editor
                .selected
                .as_ref()
                .and_then(|s| items.iter().find(|c| &c.id == s))
                .cloned();
            // A bar's button takes the keys of the menu command it runs
            // (#1148); one the menus lack runs no command a key could take.
            let selected = selected.map(|c| keys_target(app, c));
            let button = selected
                .as_ref()
                .is_some_and(|c| c.tool.is_none() && crate::ui::bar_items::is_button(&c.id));
            if button {
                app.shortcut_editor.keys_tab = false;
            }
            ui.horizontal(|ui| {
                let keys = &mut app.shortcut_editor.keys_tab;
                ui.selectable_value(keys, false, tr("options.general"))
                    .rich_tip(crate::ui::tips::pair(
                        "options.general",
                        "options.general_tip",
                    ));
                if !button {
                    ui.selectable_value(keys, true, tr("options.shortcut_keys"))
                        .rich_tip(crate::ui::tips::pair(
                            "options.shortcut_keys",
                            "options.shortcut_keys_tip",
                        ));
                }
            });
            ui.separator();
            match selected {
                None => {
                    ui.label(
                        egui::RichText::new(tr("options.no_command")).color(Tokens::text_dim()),
                    );
                }
                Some(c) if !app.shortcut_editor.keys_tab => {
                    command_general(app, ui, &c);
                    if c.id.starts_with("menu.") {
                        command_icon(app, ui, &c);
                    }
                }
                Some(c) => command_keys(app, ui, &c),
            }
        });
    });
}

/// The command whose keys `c` shows and sets: a bar button that runs a
/// menu command stands for that command (its keys are the button's),
/// keeping its own name; anything else is itself.
fn keys_target(app: &App, c: CommandItem) -> CommandItem {
    if c.tool.is_some() {
        return c;
    }
    let entry = crate::ui::bar_items::menu_command(&c.id)
        .and_then(|key| app.shortcut_editor.entries.iter().find(|e| e.key == key));
    match entry {
        Some(e) => CommandItem {
            id: e.key.clone(),
            name: c.name,
            place: command_label(e),
            built_in: e.shortcut.clone(),
            tool: None,
        },
        None => c,
    }
}

/// One row of the list: the command's picture and name.
fn command_list_row(app: &mut App, ui: &mut Ui, c: &CommandItem) {
    // A command or a tool dragged onto the Standard or Zoom toolbar
    // joins it (#563).
    let button = c.tool.is_none() && crate::ui::bar_items::is_button(&c.id);
    let item = match c.tool {
        Some(t) => Some(format!("{}{}", crate::ui::bar_items::TOOL, t.id())),
        None => (c.id.starts_with("menu.") || button).then(|| c.id.clone()),
    };
    let (row, resp) = ui.allocate_exact_size(
        egui::vec2(ui.available_width(), ROW_H),
        if item.is_some() {
            egui::Sense::click_and_drag()
        } else {
            egui::Sense::click()
        },
    );
    if let (true, Some(item)) = (resp.drag_started(), item) {
        app.bar_item_drag = Some(crate::ui::bar_items::ItemDrag { item, from: None });
    }
    let on = app.shortcut_editor.selected.as_deref() == Some(c.id.as_str());
    if on {
        ui.painter()
            .rect_filled(row, 0.0, crate::theme::Tokens::selected_row());
    } else if resp.hovered() {
        ui.painter()
            .rect_filled(row, 0.0, crate::theme::Tokens::hovered_row());
    }
    let icon = egui::Rect::from_center_size(
        egui::pos2(row.left() + 14.0, row.center().y),
        egui::vec2(16.0, 16.0),
    );
    match c.tool {
        Some(t) => crate::ui::icons::draw(ui.painter(), icon, t, Tokens::icon()),
        None if button => crate::ui::bar_items::picture(ui.painter(), icon, &c.id, Tokens::icon()),
        None => {
            crate::ui::menus::draw_menu_picture(ui.painter(), icon, &c.id, Tokens::icon());
        }
    }
    let galley = ui.painter().layout_no_wrap(
        c.name.clone(),
        egui::FontId::proportional(13.0),
        Tokens::text(),
    );
    ui.painter().with_clip_rect(row).galley(
        egui::pos2(row.left() + 30.0, row.center().y - galley.size().y / 2.0),
        galley,
        Tokens::text(),
    );
    let resp = resp.rich_tip(&c.place);
    if resp.clicked() {
        app.shortcut_editor.selected = Some(c.id.clone());
        app.shortcut_editor.capture = None;
        app.shortcut_editor.note = None;
    }
}

/// General: the command's name, where it is and its keys.
fn command_general(app: &App, ui: &mut Ui, c: &CommandItem) {
    grid("command_general").show(ui, |ui| {
        row_label(ui, &tr("options.command_name"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.command_name", "options.command_name_tip"),
            |ui| {
                ui.add(egui::Label::new(egui::RichText::new(&c.name).strong()).wrap());
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.available_on"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.available_on", "options.available_on_tip"),
            |ui| {
                ui.add(egui::Label::new(&c.place).wrap());
            },
        );

        ui.end_row();
        row_label(ui, &format!("{}:", tr("options.shortcut_keys")));
        let keys = current_keys(app, c);
        ui.label(if keys.is_empty() {
            "-".to_string()
        } else {
            keys.join(", ")
        });
        ui.end_row();
    });
}

/// The pictures a command's icon can be chosen from (#2100): those of
/// the menu commands that have one of their own, then the tools'.
pub(crate) fn icon_sources(entries: &[crate::ui::menus::invoke::Entry]) -> Vec<String> {
    let mut out: Vec<String> = Vec::new();
    for e in entries {
        if crate::ui::menus::has_own_picture(&e.key) && !out.contains(&e.key) {
            out.push(e.key.clone());
        }
    }
    out.extend(
        crate::tools::Tool::ALL
            .into_iter()
            .map(|t| format!("{}{}", crate::ui::bar_items::TOOL, t.id())),
    );
    out
}

/// Give the command `key` the picture `source`, or its own back with
/// `None`; kept in the settings (#2100).
pub(crate) fn set_command_icon(app: &mut App, key: &str, source: Option<&str>) {
    app.settings.command_icons.retain(|(k, _)| k != key);
    if let Some(src) = source.filter(|s| *s != key) {
        app.settings
            .command_icons
            .push((key.to_string(), src.to_string()));
    }
    crate::ui::menus::set_command_icons(&app.settings.command_icons);
    app.settings.save();
}

/// The General tab's Icon (#2100): the command's picture, Choose... with
/// the pictures to pick from, and Reset to Default. A command with a
/// picture shows it on a toolbar instead of its name.
fn command_icon(app: &mut App, ui: &mut Ui, c: &CommandItem) {
    ui.add_space(6.0);
    let chosen = crate::ui::menus::chosen_icon(&c.id).is_some();
    ui.horizontal(|ui| {
        ui.label(tr("options.command_icon"));
        let (r, resp) = ui.allocate_exact_size(egui::vec2(32.0, 32.0), egui::Sense::hover());
        ui.painter().rect_stroke(
            r,
            2.0,
            egui::Stroke::new(1.0, Tokens::control_border()),
            egui::StrokeKind::Inside,
        );
        if !crate::ui::menus::draw_menu_picture(
            ui.painter(),
            egui::Rect::from_center_size(r.center(), egui::vec2(20.0, 20.0)),
            &c.id,
            Tokens::icon(),
        ) {
            ui.painter().text(
                r.center(),
                egui::Align2::CENTER_CENTER,
                "-",
                egui::FontId::proportional(13.0),
                Tokens::text_dim(),
            );
        }
        resp.rich_tip(crate::ui::tips::pair(
            "options.command_icon",
            "options.command_icon_tip",
        ));
        let open = app.shortcut_editor.icon_picker;
        if ui
            .add(egui::Button::new(tr("options.command_icon_choose")).selected(open))
            .rich_tip(crate::ui::tips::pair(
                "options.command_icon_choose",
                "options.command_icon_choose_tip",
            ))
            .clicked()
        {
            app.shortcut_editor.icon_picker = !open;
        }
        if ui
            .add_enabled(chosen, egui::Button::new(tr("options.command_icon_reset")))
            .rich_tip(crate::ui::tips::pair(
                "options.command_icon_reset",
                "options.command_icon_reset_tip",
            ))
            .clicked()
        {
            set_command_icon(app, &c.id, None);
        }
    });
    if !app.shortcut_editor.icon_picker {
        return;
    }
    let sources = icon_sources(&app.shortcut_editor.entries);
    const CELL: f32 = 26.0;
    egui::Frame::new()
        .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
        .fill(Tokens::field())
        .show(ui, |ui| {
            egui::ScrollArea::vertical()
                .id_salt("command_icon_picker")
                .max_height(150.0)
                .show(ui, |ui| {
                    let per_row = ((ui.available_width() / CELL).floor() as usize).max(1);
                    for row in sources.chunks(per_row) {
                        ui.horizontal(|ui| {
                            ui.spacing_mut().item_spacing.x = 0.0;
                            for src in row {
                                let (r, resp) = ui.allocate_exact_size(
                                    egui::vec2(CELL, CELL),
                                    egui::Sense::click(),
                                );
                                if resp.hovered() {
                                    ui.painter().rect_filled(r, 2.0, Tokens::hovered_row());
                                }
                                crate::ui::menus::draw_icon_source(
                                    ui.painter(),
                                    egui::Rect::from_center_size(
                                        r.center(),
                                        egui::vec2(16.0, 16.0),
                                    ),
                                    src,
                                    Tokens::icon(),
                                );
                                let name = match crate::ui::bar_items::tool_of(src) {
                                    Some(t) => t.name(),
                                    None => tr(src),
                                };
                                if resp.rich_tip(name).clicked() {
                                    set_command_icon(app, &c.id, Some(src));
                                    app.shortcut_editor.icon_picker = false;
                                }
                            }
                        });
                    }
                });
        });
}

/// The keys that run `c` now: the user's, else the built-in ones. The
/// user's may be empty: the command's shortcut was removed.
fn current_keys(app: &App, c: &CommandItem) -> Vec<String> {
    // The Node editing table lists its own keys only (#3243).
    let built_in = (!app.shortcut_editor.node_table).then_some(c.built_in.as_str());
    crate::shortcuts::keys_for(&app.settings.shortcuts, &c.id, built_in)
}

/// Shortcut Keys: the key waiting for a press, the current keys with
/// Delete, and Reset All.
fn command_keys(app: &mut App, ui: &mut Ui, c: &CommandItem) {
    ui.label(tr("options.new_shortcut"));
    let capturing = app.shortcut_editor.capture.as_deref() == Some(c.id.as_str());
    let text = if capturing {
        tr("options.press_keys")
    } else {
        tr("options.set_shortcut")
    };
    let button = ui
        .add_sized([200.0, 24.0], egui::Button::new(text).selected(capturing))
        .rich_tip(tr("options.set_shortcut_hint"));
    if button.clicked() {
        app.shortcut_editor.capture = (!capturing).then(|| c.id.clone());
        app.shortcut_editor.note = None;
        // The keys pressed next are the shortcut, not typing or a press
        // of this button.
        ui.ctx().memory_mut(|m| m.stop_text_input());
        button.surrender_focus();
    }
    ui.add_space(6.0);
    ui.label(tr("options.current_shortcuts"));
    let custom = user_shortcut(app, &c.id).is_some();
    let keys = current_keys(app, c);
    let mut delete_key = None;
    egui::Frame::new()
        .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
        .fill(crate::theme::Tokens::field())
        .inner_margin(4)
        .show(ui, |ui| {
            ui.set_width(260.0);
            ui.set_min_height(70.0);
            // Each key on its row, deleted on its own (#822).
            for k in &keys {
                ui.horizontal(|ui| {
                    if custom {
                        ui.label(k);
                    } else {
                        ui.label(format!("{k}  ({})", tr("options.built_in")));
                    }
                    if ui
                        .small_button(tr("options.delete"))
                        .rich_tip(tr("options.clear_shortcut"))
                        .clicked()
                    {
                        delete_key = Some(k.clone());
                    }
                });
            }
        });
    if let Some(k) = delete_key {
        remove_key(app, c, &k);
    }
    let has_keys = !current_keys(app, c).is_empty();
    ui.horizontal(|ui| {
        if ui
            .add_enabled(has_keys, egui::Button::new(tr("options.delete")))
            .rich_tip(tr("options.clear_shortcut"))
            .clicked()
        {
            remove_shortcut(app, c);
        }
        // The commands of the category shown; with every command shown,
        // the same as resetting all, so it asks first.
        if ui
            .button(tr("options.reset_shortcuts"))
            .rich_tip(crate::ui::tips::pair(
                "options.reset_shortcuts",
                "options.reset_shortcuts_tip",
            ))
            .clicked()
        {
            match app.shortcut_editor.category.clone() {
                Some(category) => reset_category_shortcuts(app, &category),
                None => app.shortcut_editor.confirm_reset_all = true,
            }
        }
    });
    if ui
        .button(tr("options.reset_all_shortcuts"))
        .rich_tip(crate::ui::tips::pair(
            "options.reset_all_shortcuts",
            "options.reset_all_shortcuts_tip",
        ))
        .clicked()
    {
        app.shortcut_editor.confirm_reset_all = true;
    }
    if app.shortcut_editor.confirm_reset_all {
        ui.label(tr("options.reset_all_shortcuts_question"));
        ui.horizontal(|ui| {
            if ui
                .button(tr("dialog.reset"))
                .rich_tip(crate::ui::tips::keyed("dialog.reset"))
                .clicked()
            {
                app.settings.shortcuts.clear();
                app.shortcut_editor.note = None;
                app.shortcut_editor.capture = None;
                app.shortcut_editor.confirm_reset_all = false;
            }
            if ui
                .button(tr("dialog.cancel"))
                .rich_tip(crate::ui::tips::keyed("dialog.cancel"))
                .clicked()
            {
                app.shortcut_editor.confirm_reset_all = false;
            }
        });
    }
    // What the last shortcut set took over.
    if let Some(note) = &app.shortcut_editor.note {
        ui.label(egui::RichText::new(note).color(Tokens::ACCENT));
    }
}

/// Take `key` from the keys of `c`, keeping its others; with none left,
/// `c` is left without a shortcut ([`remove_shortcut`]).
fn remove_key(app: &mut App, c: &CommandItem, key: &str) {
    use crate::shortcuts::same;
    let keys: Vec<String> = current_keys(app, c)
        .into_iter()
        .filter(|k| !same(k, key))
        .collect();
    if keys.is_empty() {
        remove_shortcut(app, c);
        return;
    }
    app.settings.shortcuts.retain(|(k, _)| k != &c.id);
    for k in keys {
        app.settings.shortcuts.push((c.id.clone(), k));
    }
    app.shortcut_editor.note = None;
}

/// Leave `c` without a shortcut: the user's goes, and a built-in one is
/// overridden by an empty shortcut, so its keys no longer run it.
fn remove_shortcut(app: &mut App, c: &CommandItem) {
    app.settings.shortcuts.retain(|(k, _)| k != &c.id);
    if !c.built_in.is_empty() && !app.shortcut_editor.node_table {
        app.settings.shortcuts.push((c.id.clone(), String::new()));
    }
    app.shortcut_editor.note = None;
}

/// Reset to defaults on the Commands page: the shortcuts of the commands
/// in `category` (a menu's title key, the toolbox or the macros) only.
fn reset_category_shortcuts(app: &mut App, category: &str) {
    let ids: Vec<String> = command_items(app, Some(category), "")
        .into_iter()
        .map(|c| c.id)
        .collect();
    app.settings.shortcuts.retain(|(k, _)| !ids.contains(k));
    app.shortcut_editor.note = None;
    app.shortcut_editor.capture = None;
}

/// The command waiting for its keys takes the next key pressed (Shift,
/// Ctrl and Alt alone keep it waiting); tools take the same keys as
/// menu commands.
fn capture_keys(app: &mut App, ui: &mut Ui) {
    let Some(target) = app.shortcut_editor.capture.clone() else {
        return;
    };
    let pressed = ui.input(|i| {
        i.events.iter().find_map(|e| match e {
            egui::Event::Key {
                key,
                pressed: true,
                modifiers,
                ..
            } if !crate::shortcuts::is_modifier(*key) => Some((*key, *modifiers)),
            _ => None,
        })
    });
    let Some((key, mods)) = pressed else {
        return;
    };
    if key == egui::Key::Escape && !(mods.ctrl || mods.alt || mods.command) {
        app.shortcut_editor.capture = None;
        return;
    }
    if crate::shortcuts::allowed(mods, key) {
        let text = crate::shortcuts::format(mods, key);
        set_menu_shortcut(app, &target, &text);
        app.shortcut_editor.capture = None;
    }
}

/// Customization > Command Bars: the bars shown, in a list, with Reset;
/// beside it the options that hold for every bar.
fn command_bars_page(app: &mut App, ui: &mut Ui) {
    ui.horizontal_top(|ui| {
        ui.vertical(|ui| {
            ui.set_width(230.0);
            ui.label(tr("options.command_bars_hint"));
            ui.label(
                egui::RichText::new(tr("options.toolbar_drag_hint"))
                    .color(Tokens::text_dim())
                    .size(11.0),
            );
            egui::Frame::new()
                .stroke(egui::Stroke::new(1.0, Tokens::border()))
                .fill(crate::theme::Tokens::field())
                .inner_margin(6)
                .show(ui, |ui| {
                    ui.set_width(216.0);
                    ui.set_min_height(230.0);
                    // The menu bar is always there.
                    ui.add_enabled(
                        false,
                        egui::Checkbox::new(&mut true, tr("menu.window.toolbar_menu_bar")),
                    )
                    .rich_disabled_tip(crate::ui::tips::pair(
                        "menu.window.toolbar_menu_bar",
                        "options.menu_bar_always_tip",
                    ));
                    let palette = &mut app.settings.palette.show_palette;
                    for (flag, key) in [
                        (
                            &mut app.show_standard_toolbar,
                            "menu.window.toolbar_standard",
                        ),
                        (
                            &mut app.show_property_bar,
                            "menu.window.toolbar_property_bar",
                        ),
                        (&mut app.show_toolbox, "menu.window.toolbar_toolbox"),
                        (&mut app.show_status_bar, "menu.window.toolbar_status_bar"),
                        (palette, "bars.palette"),
                        (&mut app.show_text_toolbar, "menu.window.toolbar_text"),
                        (&mut app.show_zoom_toolbar, "menu.window.toolbar_zoom"),
                        (
                            &mut app.show_transform_toolbar,
                            "menu.window.toolbar_transform",
                        ),
                    ] {
                        ui.checkbox(flag, tr(key)).rich_tip_with(|| {
                            format!("{}\n{}", tr(key), tr("options.show_bar_tip"))
                        });
                    }
                    custom_bars_list(app, ui);
                });
            custom_bars_buttons(app, ui);
            if ui
                .button(tr("options.reset"))
                .rich_tip(crate::ui::tips::pair("options.reset", "dialog.reset_desc"))
                .clicked()
            {
                app.reset_command_bars();
            }
        });
        ui.add_space(16.0);
        ui.vertical(|ui| {
            crate::ui::chrome::section(ui, &tr("options.other"));
            ui.checkbox(&mut app.settings.bars.locked, tr("bars.lock"))
                .rich_tip(crate::ui::tips::pair("bars.lock", "bars.lock_tip"));
            ui.checkbox(
                &mut app.settings.show_outline_flyout,
                tr("options.show_outline_flyout"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.show_outline_flyout",
                "options.show_outline_flyout_tip",
            ));
        });
    });
}

/// The toolbar the user made that is picked in the Command Bars list
/// (renamed and deleted with the controls under it).
fn picked_custom_bar(app: &App, ui: &Ui) -> Option<u8> {
    let picked: Option<u8> = ui.data(|d| d.get_temp(custom_bar_pick_id())).flatten();
    picked.filter(|s| app.settings.bars.custom_bar(*s).is_some())
}

fn custom_bar_pick_id() -> egui::Id {
    egui::Id::new("command_bars_custom_picked")
}

/// The toolbars the user made in the Command Bars list (#3264): each
/// shown or not with its box, picked with a click on its name.
fn custom_bars_list(app: &mut App, ui: &mut Ui) {
    let picked = picked_custom_bar(app, ui);
    let bars: Vec<(u8, String, bool)> = app
        .settings
        .bars
        .custom
        .iter()
        .map(|c| {
            let bar = crate::ui::bars::Bar::Custom(c.slot);
            (c.slot, bar.name(app), c.shown)
        })
        .collect();
    for (slot, name, shown) in bars {
        ui.horizontal(|ui| {
            ui.spacing_mut().item_spacing.x = 2.0;
            let mut on = shown;
            if ui
                .checkbox(&mut on, "")
                .rich_tip_with(|| format!("{}\n{}", name, tr("options.show_bar_tip")))
                .changed()
            {
                crate::ui::bars::Bar::Custom(slot).set_visible(app, on);
            }
            if ui
                .selectable_label(picked == Some(slot), &name)
                .rich_tip(crate::ui::tips::pair(
                    "bars.custom_bar",
                    "options.custom_bar_pick_tip",
                ))
                .clicked()
            {
                ui.data_mut(|d| d.insert_temp(custom_bar_pick_id(), Some(slot)));
            }
        });
    }
}

/// New, the picked toolbar's name and Delete, under the Command Bars list
/// (#3264). A new toolbar is empty and shown; commands are dragged onto
/// it from the Commands page (or with Alt from another bar).
fn custom_bars_buttons(app: &mut App, ui: &mut Ui) {
    let picked = picked_custom_bar(app, ui);
    ui.horizontal(|ui| {
        let room = app.settings.bars.custom.len() < crate::ui::bars::MAX_CUSTOM;
        if ui
            .add_enabled(room, egui::Button::new(tr("options.custom_bar_new")))
            .rich_tip(crate::ui::tips::pair(
                "options.custom_bar_new",
                "options.custom_bar_new_tip",
            ))
            .clicked()
        {
            let name = new_custom_bar_name(app);
            if let Some(crate::ui::bars::Bar::Custom(slot)) = app.settings.bars.add_custom(&name) {
                ui.data_mut(|d| d.insert_temp(custom_bar_pick_id(), Some(slot)));
            }
        }
        if ui
            .add_enabled(
                picked.is_some(),
                egui::Button::new(tr("options.custom_bar_delete")),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.custom_bar_delete",
                "options.custom_bar_delete_tip",
            ))
            .clicked()
        {
            if let Some(slot) = picked {
                delete_custom_bar(app, slot);
                ui.data_mut(|d| d.insert_temp(custom_bar_pick_id(), None::<u8>));
            }
        }
    });
    if let Some(slot) = picked {
        ui.horizontal(|ui| {
            ui.label(tr("options.custom_bar_name"));
            let mut name = app
                .settings
                .bars
                .custom_bar(slot)
                .map(|c| c.name.clone())
                .unwrap_or_default();
            if ui
                .add(egui::TextEdit::singleline(&mut name).desired_width(140.0))
                .changed()
            {
                app.settings.bars.rename_custom(slot, &name);
            }
        });
    }
}

/// The name a new toolbar gets: "New Toolbar", then "New Toolbar 2" and
/// so on, one no other toolbar the user made has.
pub(crate) fn new_custom_bar_name(app: &App) -> String {
    let base = tr("options.custom_bar_default_name");
    let taken = |n: &str| app.settings.bars.custom.iter().any(|c| c.name == n);
    if !taken(&base) {
        return base;
    }
    (2..)
        .map(|i| format!("{base} {i}"))
        .find(|n| !taken(n))
        .unwrap_or(base)
}

/// Take away the toolbar the user made in `slot`, with its buttons.
pub(crate) fn delete_custom_bar(app: &mut App, slot: u8) {
    let id = crate::ui::bars::Bar::Custom(slot).id();
    app.settings.bar_items.remove(id);
    app.settings.bars.remove_custom(slot);
}

// ----- Tools -------------------------------------------------------------

fn pick_page(app: &mut App, ui: &mut Ui) {
    ui.checkbox(
        &mut app.settings.crosshair_cursor,
        tr("options.crosshair_cursor"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.crosshair_cursor",
        "options.crosshair_cursor_tip",
    ));
    ui.checkbox(
        &mut app.settings.treat_all_filled,
        tr("options.treat_all_filled"),
    )
    .rich_tip(crate::ui::tips::keyed("options.treat_all_filled"));
    ui.checkbox(
        &mut app.settings.marquee_touching,
        tr("options.marquee_touching"),
    )
    .rich_tip(tr("options.marquee_touching_tip"));
    ui.add_space(6.0);
    ui.label(tr("options.ctrl_shift_keys"));
    ui.indent("pick_keys", |ui| {
        ui.radio_value(
            &mut app.settings.pick_windows_keys,
            false,
            tr("options.keys_traditional"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.keys_traditional",
            "options.keys_traditional_tip",
        ));
        ui.radio_value(
            &mut app.settings.pick_windows_keys,
            true,
            tr("options.keys_windows"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.keys_windows",
            "options.keys_windows_tip",
        ));
    });
}

fn zoom_pan_page(app: &mut App, ui: &mut Ui) {
    chrome::section(ui, &tr("options.zoom_tool"));
    ui.label(tr("options.zoom_right_button"));
    ui.indent("zr", |ui| {
        ui.radio_value(
            &mut app.settings.zoom_right_click_out,
            true,
            tr("options.zoom_out"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.zoom_out",
            "options.zoom_out_tip",
        ));
        ui.radio_value(
            &mut app.settings.zoom_right_click_out,
            false,
            tr("options.context_menu"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.context_menu",
            "options.context_menu_tip",
        ));
    });
    ui.checkbox(
        &mut app.settings.zoom_relative_1to1,
        tr("options.zoom_relative_1to1"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.zoom_relative_1to1",
        "options.zoom_relative_1to1_tip",
    ));
    ui.checkbox(
        &mut app.settings.wheel_zoom_centers,
        tr("options.wheel_center_mouse"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.wheel_center_mouse",
        "options.wheel_center_mouse_tip",
    ));
    // The wheel's glide and its step (#1648, #895).
    ui.checkbox(&mut app.settings.smooth_zoom, tr("options.smooth_zoom"))
        .rich_tip(crate::ui::tips::pair(
            "options.smooth_zoom",
            "options.smooth_zoom_tip",
        ));
    // Slow computers: one jump a notch, one render once the zoom stops.
    ui.checkbox(&mut app.settings.light_zoom, tr("options.light_zoom"))
        .rich_tip(crate::ui::tips::pair(
            "options.light_zoom",
            "options.light_zoom_tip",
        ));
    ui.horizontal(|ui| {
        ui.label(tr("options.wheel_zoom_step"));
        ui.add(
            crate::ui::field::NumField::new(&mut app.settings.wheel_zoom_step)
                .range(1.0..=100.0)
                .speed(0.5)
                .suffix(" %"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.wheel_zoom_step",
            "options.wheel_zoom_step_tip",
        ));
    });
    ui.separator();
    ui.label(tr("options.wheel_action"));
    ui.indent("wa", |ui| {
        ui.radio_value(
            &mut app.settings.wheel_zooms,
            true,
            tr("options.wheel_zoom"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.wheel_zoom",
            "options.wheel_zoom_tip",
        ));
        ui.radio_value(
            &mut app.settings.wheel_zooms,
            false,
            tr("options.wheel_scroll"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.wheel_scroll",
            "options.wheel_scroll_tip",
        ));
        // Ctrl+wheel zooms like the plain wheel instead of scrolling
        // sideways (#3473).
        ui.add_enabled_ui(app.settings.wheel_zooms, |ui| {
            ui.checkbox(
                &mut app.settings.ctrl_wheel_zooms,
                tr("options.ctrl_wheel_zooms"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.ctrl_wheel_zooms",
                "options.ctrl_wheel_zooms_tip",
            ));
        });
    });
    ui.separator();
    // The ruler calibration lives on the Display page; this opens it there.
    if ui
        .button(tr("options.calibrate_zoom"))
        .rich_tip(crate::ui::tips::pair(
            "options.calibrate_zoom",
            "options.calibrate_zoom_tip",
        ))
        .clicked()
    {
        app.options_page = OptionsPage::Display;
    }
    ui.label(
        egui::RichText::new(tr("options.calibrate_zoom_desc"))
            .color(Tokens::text_dim())
            .size(12.0),
    );
    chrome::section(ui, &tr("options.pan_tool"));
    ui.label(tr("options.pan_right_button"));
    ui.indent("pr", |ui| {
        ui.radio_value(
            &mut app.settings.pan_right_click_out,
            true,
            tr("options.zoom_out"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.zoom_out",
            "options.pan_zoom_out_tip",
        ));
        ui.radio_value(
            &mut app.settings.pan_right_click_out,
            false,
            tr("options.context_menu"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.context_menu",
            "options.pan_context_menu_tip",
        ));
    });
    // A flick keeps the view sliding (#831).
    ui.checkbox(&mut app.settings.pan_inertia, tr("options.pan_inertia"))
        .rich_tip(crate::ui::tips::pair(
            "options.pan_inertia",
            "options.pan_inertia_tip",
        ));
}

fn rectangle_page(app: &mut App, ui: &mut Ui) {
    use tracedraw_core::{CornerKind, Corners};
    let mut c = app.rect_corners;
    let u = app.units;
    let together = app.corners_together;
    chrome::section(ui, &tr("options.rectangle_corners"));
    ui.indent("rect_corners", |ui| {
        ui.horizontal(|ui| {
            for (kind, key) in [
                (CornerKind::Round, "toolbar.corner_round"),
                (CornerKind::Scallop, "toolbar.corner_scallop"),
                (CornerKind::Chamfer, "toolbar.corner_chamfer"),
            ] {
                ui.radio_value(&mut c.kind, kind, tr(key))
                    .rich_tip(crate::ui::tips::keyed(key));
            }
        });
        egui::Grid::new("rect_corners_grid")
            .num_columns(4)
            .spacing([8.0, 8.0])
            .show(ui, |ui| {
                for pair in [
                    [
                        (Corners::TOP_LEFT, "toolbar.corner_top_left"),
                        (Corners::TOP_RIGHT, "toolbar.corner_top_right"),
                    ],
                    [
                        (Corners::BOTTOM_LEFT, "toolbar.corner_bottom_left"),
                        (Corners::BOTTOM_RIGHT, "toolbar.corner_bottom_right"),
                    ],
                ] {
                    for (i, key) in pair {
                        row_label(ui, &tr(key));
                        let mut v = u.world_from_mm(c.radii[i]);
                        if ui
                            .add_sized(
                                [80.0, 22.0],
                                crate::ui::field::NumField::new(&mut v)
                                    .range(0.0..=10_000.0)
                                    .speed(0.1)
                                    .suffix(format!(" {}", u.short())),
                            )
                            .rich_tip(crate::ui::tips::keyed(key))
                            .changed()
                        {
                            let v = u.world_to_mm(v).max(0.0);
                            if together {
                                c.radii = [v; 4];
                            } else {
                                c.radii[i] = v;
                            }
                        }
                    }
                    ui.end_row();
                }
            });
        ui.checkbox(&mut app.corners_together, tr("toolbar.corners_together"))
            .rich_tip(crate::ui::tips::keyed("toolbar.corners_together"));
    });
    chrome::section(ui, &tr("options.scale_corners"));
    ui.indent("scale_corners", |ui| {
        let mut relative = !c.fixed;
        if ui
            .checkbox(&mut relative, tr("toolbar.relative_corners"))
            .rich_tip(crate::ui::tips::keyed("toolbar.relative_corners"))
            .changed()
        {
            c.fixed = !relative;
        }
    });
    app.rect_corners = c;
}

fn ellipse_page(app: &mut App, ui: &mut Ui) {
    let mut kind = match app.ellipse_arc {
        None => 0,
        Some(a) if a.pie => 1,
        Some(_) => 2,
    };
    let before = kind;
    ui.radio_value(&mut kind, 0, tr("options.ellipse"))
        .rich_tip(crate::ui::tips::pair(
            "options.ellipse",
            "options.ellipse_tip",
        ));
    ui.radio_value(&mut kind, 1, tr("options.pie"))
        .rich_tip(crate::ui::tips::pair("options.pie", "options.pie_tip"));
    ui.radio_value(&mut kind, 2, tr("options.arc"))
        .rich_tip(crate::ui::tips::pair("options.arc", "options.arc_tip"));
    let mut arc = app.ellipse_arc.unwrap_or(crate::app::DEFAULT_ELLIPSE_ARC);
    if kind != before {
        app.ellipse_arc = match kind {
            0 => None,
            k => {
                arc.pie = k == 1;
                Some(arc)
            }
        };
    }
    let clockwise = &mut app.settings.ellipse_clockwise;
    if let Some(a) = &mut app.ellipse_arc {
        // The angles as typed: from the start to the end in the chosen
        // direction; the stored arc always runs counterclockwise (#1436).
        let (mut start, mut end) = if *clockwise {
            (a.end_deg, a.start_deg)
        } else {
            (a.start_deg, a.end_deg)
        };
        grid("arc").show(ui, |ui| {
            row_label(ui, &tr("options.starting_angle"));
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.starting_angle", "options.starting_angle_tip"),
                |ui| {
                    ui.add(
                        crate::ui::field::NumField::new(&mut start)
                            .range(-360.0..=360.0)
                            .suffix("°"),
                    );
                },
            );

            ui.end_row();
            row_label(ui, &tr("options.ending_angle"));
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.ending_angle", "options.ending_angle_tip"),
                |ui| {
                    ui.add(
                        crate::ui::field::NumField::new(&mut end)
                            .range(-360.0..=360.0)
                            .suffix("°"),
                    );
                },
            );

            ui.end_row();
            row_label(ui, &tr("options.arc_direction"));
            ui.horizontal(|ui| {
                ui.radio_value(clockwise, false, tr("options.counterclockwise"))
                    .rich_tip(crate::ui::tips::keyed("options.arc_direction"));
                ui.radio_value(clockwise, true, tr("options.clockwise"))
                    .rich_tip(crate::ui::tips::keyed("options.arc_direction"));
            });
            ui.end_row();
        });
        (a.start_deg, a.end_deg) = if *clockwise {
            (end, start)
        } else {
            (start, end)
        };
    }
}

fn polygon_page(app: &mut App, ui: &mut Ui) {
    grid("polygon").show(ui, |ui| {
        row_label(ui, &tr("options.number_of_points"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.number_of_points", "options.number_of_points_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.polygon_points).range(3..=500));
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.sharpness"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.sharpness", "options.sharpness_tip"),
            |ui| {
                // Stored as a fraction, shown in percent like the property bar.
                let mut pct = (app.star_sharpness * 100.0).round();
                if ui
                    .add(
                        crate::ui::field::NumField::new(&mut pct)
                            .range(-99.0..=99.0)
                            .suffix("%"),
                    )
                    .changed()
                {
                    app.star_sharpness =
                        crate::ui::propbar::sharpness_from_pct(pct, app.star_sharpness);
                };
            },
        );

        ui.end_row();
    });
}

fn spiral_page(app: &mut App, ui: &mut Ui) {
    grid("spiral").show(ui, |ui| {
        row_label(ui, &tr("options.revolutions"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.revolutions", "options.revolutions_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.spiral_revolutions).range(1..=100));
            },
        );

        ui.end_row();
    });
    ui.radio_value(
        &mut app.spiral_logarithmic,
        false,
        tr("options.symmetrical_spiral"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.symmetrical_spiral",
        "options.symmetrical_spiral_tip",
    ));
    ui.radio_value(
        &mut app.spiral_logarithmic,
        true,
        tr("options.logarithmic_spiral"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.logarithmic_spiral",
        "options.logarithmic_spiral_tip",
    ));
    // How fast the logarithmic spiral widens, and a picture of the
    // spiral the tool draws (#1436).
    ui.add_enabled_ui(app.spiral_logarithmic, |ui| {
        grid("spiral_expansion").show(ui, |ui| {
            row_label(ui, &tr("options.spiral_expansion"));
            ui.add(crate::ui::Slider::new(
                &mut app.settings.spiral_expansion,
                1..=100,
            ))
            .rich_tip(crate::ui::tips::pair(
                "options.spiral_expansion",
                "options.spiral_expansion_tip",
            ));
            ui.end_row();
        });
    });
    spiral_picture(
        ui,
        app.spiral_revolutions,
        app.spiral_logarithmic,
        app.settings.spiral_expansion,
    );
}

/// A small picture of the spiral the tool draws with these settings.
fn spiral_picture(ui: &mut Ui, revolutions: u32, logarithmic: bool, expansion: u32) {
    let side = 96.0;
    let (rect, resp) = ui.allocate_exact_size(egui::vec2(side, side), egui::Sense::hover());
    resp.on_hover_text(tr("options.spiral_preview_tip"));
    let painter = ui.painter_at(rect);
    painter.rect_stroke(
        rect,
        4.0,
        egui::Stroke::new(1.0, Tokens::border()),
        egui::StrokeKind::Inside,
    );
    let box_mm = tracedraw_core::geometry::Rect::new(0.0, 0.0, 1.0, 1.0);
    let path = crate::tools2::spiral_path(box_mm, revolutions.min(20), logarithmic, expansion);
    let inner = rect.shrink(8.0);
    let mut pts = Vec::new();
    tracedraw_core::geometry::flatten(&path, 0.002, &mut |el| {
        use tracedraw_core::geometry::PathEl;
        match el {
            PathEl::MoveTo(p) | PathEl::LineTo(p) => pts.push(egui::pos2(
                inner.left() + p.x as f32 * inner.width(),
                inner.top() + p.y as f32 * inner.height(),
            )),
            _ => {}
        }
    });
    painter.add(egui::Shape::line(
        pts,
        egui::Stroke::new(1.5, Tokens::text()),
    ));
}

fn graph_paper_page(app: &mut App, ui: &mut Ui) {
    grid("graph").show(ui, |ui| {
        row_label(ui, &tr("options.rows"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.rows", "options.rows_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.graph_rows).range(1..=99));
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.columns"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.columns", "options.columns_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.graph_cols).range(1..=99));
            },
        );

        ui.end_row();
        // The radial grid (rings and spokes).
        row_label(ui, "");
        ui.checkbox(&mut app.graph_radial, tr("toolbar.graph_radial"))
            .rich_tip(crate::ui::tips::keyed("toolbar.graph_radial"));
        ui.end_row();
        row_label(ui, &format!("{}:", tr("toolbar.rings")));
        ui.add(crate::ui::field::NumField::new(&mut app.graph_rings).range(1..=99))
            .rich_tip(crate::ui::tips::keyed("toolbar.rings"));
        ui.end_row();
        row_label(ui, &format!("{}:", tr("toolbar.spokes")));
        ui.add(crate::ui::field::NumField::new(&mut app.graph_spokes).range(0..=360))
            .rich_tip(crate::ui::tips::keyed("toolbar.spokes"));
        ui.end_row();
    });
}

/// Shape Recognition's levels, as on its property bar.
fn shape_recognition_page(app: &mut App, ui: &mut Ui) {
    grid("shape_recognition").show(ui, |ui| {
        row_label(ui, &tr("recognize.recognition"));
        crate::ui::drawing_bars::level(
            ui,
            "options_recognize_level",
            "recognize.recognition_tip",
            &mut app.recognize.recognition,
        );
        ui.end_row();
        row_label(ui, &tr("recognize.smoothing"));
        crate::ui::drawing_bars::level(
            ui,
            "options_recognize_smoothing",
            "recognize.smoothing_tip",
            &mut app.recognize.smoothing,
        );
        ui.end_row();
    });
}

/// The label new dimensions take: precision, units, prefix and suffix,
/// as on the dimension tools' property bar.
fn dimension_page(app: &mut App, ui: &mut Ui) {
    let mut style = app.dimension_style.clone();
    grid("dimension").show(ui, |ui| {
        row_label(ui, &tr("dimension.precision"));
        let mut precision = style.precision.min(6);
        crate::ui::keynav::ComboBox::from_id_salt("options_dimension_precision")
            .selected_text(crate::ui::dimension_bar::precision_sample(precision))
            .width(120.0)
            .show_ui(ui, |ui| {
                for p in 0..=6u8 {
                    ui.selectable_value(
                        &mut precision,
                        p,
                        crate::ui::dimension_bar::precision_sample(p),
                    );
                }
            })
            .response
            .rich_tip(crate::ui::tips::keyed("dimension.precision"));
        style.precision = precision;
        ui.end_row();
        row_label(ui, &tr("options.dimension_style"));
        crate::ui::keynav::ComboBox::from_id_salt("options_dimension_style")
            .selected_text(tr(if style.fractional {
                "options.fractional"
            } else {
                "options.decimal"
            }))
            .width(120.0)
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut style.fractional, false, tr("options.decimal"));
                ui.selectable_value(&mut style.fractional, true, tr("options.fractional"));
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.dimension_style",
                "options.dimension_style_tip",
            ));
        ui.end_row();
        row_label(ui, &tr("dimension.units"));
        let choices = crate::dimensions::units_choices();
        let shown = choices
            .iter()
            .find(|(id, _)| *id == style.units)
            .map(|(_, l)| l.clone())
            .unwrap_or_default();
        crate::ui::keynav::ComboBox::from_id_salt("options_dimension_units")
            .selected_text(shown)
            .width(120.0)
            .show_ui(ui, |ui| {
                for (id, label) in &choices {
                    ui.selectable_value(&mut style.units, id.clone(), label);
                }
            })
            .response
            .rich_tip(crate::ui::tips::keyed("dimension.units"));
        ui.end_row();
        ui.label("");
        ui.checkbox(&mut style.show_units, tr("dimension.show_units"))
            .rich_tip(crate::ui::tips::keyed("dimension.show_units"));
        ui.end_row();
        row_label(ui, &tr("dimension.prefix"));
        ui.add(egui::TextEdit::singleline(&mut style.prefix).desired_width(190.0))
            .rich_tip(crate::ui::tips::keyed("dimension.prefix"));
        ui.end_row();
        row_label(ui, &tr("dimension.suffix"));
        ui.add(egui::TextEdit::singleline(&mut style.suffix).desired_width(190.0))
            .rich_tip(crate::ui::tips::keyed("dimension.suffix"));
        ui.end_row();
    });
    if style != app.dimension_style {
        app.dimension_style = style;
    }
}

/// The decimals, degree sign, prefix and suffix new angular dimensions
/// take (#1436).
fn angular_dimension_page(app: &mut App, ui: &mut Ui) {
    let a = &mut app.settings.angular_dimension;
    grid("angular_dimension").show(ui, |ui| {
        row_label(ui, &tr("dimension.precision"));
        let mut precision = a.precision.min(6);
        crate::ui::keynav::ComboBox::from_id_salt("options_angular_precision")
            .selected_text(crate::ui::dimension_bar::precision_sample(precision))
            .width(120.0)
            .show_ui(ui, |ui| {
                for p in 0..=6u8 {
                    ui.selectable_value(
                        &mut precision,
                        p,
                        crate::ui::dimension_bar::precision_sample(p),
                    );
                }
            })
            .response
            .rich_tip(crate::ui::tips::keyed("dimension.precision"));
        a.precision = precision;
        ui.end_row();
        row_label(ui, &tr("dimension.units"));
        ui.label("\u{b0}").rich_tip(tr("options.angular_units_tip"));
        ui.end_row();
        ui.label("");
        ui.checkbox(&mut a.show_units, tr("dimension.show_units"))
            .rich_tip(crate::ui::tips::keyed("dimension.show_units"));
        ui.end_row();
        row_label(ui, &tr("dimension.prefix"));
        ui.add(egui::TextEdit::singleline(&mut a.prefix).desired_width(190.0))
            .rich_tip(crate::ui::tips::keyed("dimension.prefix"));
        ui.end_row();
        row_label(ui, &tr("dimension.suffix"));
        ui.add(egui::TextEdit::singleline(&mut a.suffix).desired_width(190.0))
            .rich_tip(crate::ui::tips::keyed("dimension.suffix"));
        ui.end_row();
    });
}

/// The corner radius new rounded connectors take, whether an object's
/// nodes are anchors and how far right-angle connectors leave objects.
fn connector_page(app: &mut App, ui: &mut Ui) {
    grid("connector").show(ui, |ui| {
        row_label(ui, &tr("connector.radius"));
        let mut r = app.connector_radius;
        if ui
            .add(
                crate::ui::field::NumField::new(&mut r)
                    .speed(0.1)
                    .range(0.0..=1000.0)
                    .suffix(" mm"),
            )
            .rich_tip(crate::ui::tips::keyed("connector.radius"))
            .changed()
        {
            app.connector_radius = r.clamp(0.0, 1000.0);
        }
        ui.end_row();
        row_label(ui, &tr("options.connector_gap"));
        let mut gap = app.settings.connector_gap;
        if ui
            .add(
                crate::ui::field::NumField::new(&mut gap)
                    .speed(0.1)
                    .range(0.0..=100.0)
                    .suffix(" mm"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.connector_gap",
                "options.connector_gap_tip",
            ))
            .changed()
        {
            app.settings.connector_gap = if gap.is_finite() {
                gap.clamp(0.0, 100.0)
            } else {
                0.0
            };
        }
        ui.end_row();
    });
    ui.checkbox(
        &mut app.settings.connector_geometric_anchors,
        tr("options.connector_geometric_anchors"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.connector_geometric_anchors",
        "options.connector_geometric_anchors_tip",
    ));
}

/// The grid new mesh fills take.
fn mesh_fill_page(app: &mut App, ui: &mut Ui) {
    grid("mesh_fill").show(ui, |ui| {
        row_label(ui, &tr("options.columns"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.columns", "options.columns_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.mesh_cols).range(1..=50));
            },
        );
        ui.end_row();
        row_label(ui, &tr("options.rows"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.rows", "options.rows_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.mesh_rows).range(1..=50));
            },
        );
        ui.end_row();
    });
}

fn table_page(app: &mut App, ui: &mut Ui) {
    grid("table").show(ui, |ui| {
        row_label(ui, &tr("options.rows"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.rows", "options.rows_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.table_rows).range(1..=99));
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.columns"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.columns", "options.columns_tip"),
            |ui| {
                ui.add(crate::ui::field::NumField::new(&mut app.table_cols).range(1..=99));
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.table_tab_key"));
        ui.vertical(|ui| {
            let p = &mut app.settings.table;
            ui.radio_value(&mut p.tab_inserts_tab, false, tr("options.table_tab_moves"))
                .rich_tip(crate::ui::tips::pair(
                    "options.table_tab_moves",
                    "options.table_tab_moves_tip",
                ));
            ui.radio_value(
                &mut p.tab_inserts_tab,
                true,
                tr("options.table_tab_inserts"),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.table_tab_inserts",
                "options.table_tab_inserts_tip",
            ));
        });
        ui.end_row();
        row_label(ui, &tr("options.table_tab_order"));
        ui.vertical(|ui| {
            let p = &mut app.settings.table;
            ui.radio_value(&mut p.tab_by_columns, false, tr("options.table_tab_rows"))
                .rich_tip(crate::ui::tips::pair(
                    "options.table_tab_rows",
                    "options.table_tab_rows_tip",
                ));
            ui.radio_value(&mut p.tab_by_columns, true, tr("options.table_tab_columns"))
                .rich_tip(crate::ui::tips::pair(
                    "options.table_tab_columns",
                    "options.table_tab_columns_tip",
                ));
        });
        ui.end_row();
    });
}

/// Options > Tools > Curve tools: the Freehand smoothing, how near an
/// end node a new line joins the selected curve (and a curve closes on
/// its first node), and the Pen's preview mode and automatic adding and
/// deleting of nodes. See `prefs::CurvePrefs`.
fn curves_page(app: &mut App, ui: &mut Ui) {
    let c = &mut app.settings.curves;
    grid("curves").show(ui, |ui| {
        row_label(ui, &tr("options.freehand_smoothing"));
        let mut v = c.smoothing.min(100);
        ui.add(crate::ui::Slider::new(&mut v, 0..=100))
            .rich_tip(crate::ui::tips::pair(
                "options.freehand_smoothing",
                "options.freehand_smoothing_tip",
            ));
        c.smoothing = v;
        ui.end_row();
        row_label(ui, &tr("options.join_within"));
        let mut px = if c.join_px.is_finite() {
            c.join_px
        } else {
            5.0
        };
        ui.add(
            crate::ui::field::NumField::new(&mut px)
                .range(1.0..=50.0)
                .speed(0.2)
                .suffix(" px"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.join_within",
            "options.join_within_tip",
        ));
        c.join_px = px;
        ui.end_row();
        // Corners and straight stretches of freehand strokes (#1436).
        row_label(ui, &tr("options.corner_threshold"));
        ui.add(crate::ui::Slider::new(&mut c.corner_threshold, 0..=10))
            .rich_tip(crate::ui::tips::pair(
                "options.corner_threshold",
                "options.corner_threshold_tip",
            ));
        ui.end_row();
        row_label(ui, &tr("options.straight_threshold"));
        ui.add(crate::ui::Slider::new(&mut c.straight_threshold, 0..=10).suffix(" px"))
            .rich_tip(crate::ui::tips::pair(
                "options.straight_threshold",
                "options.straight_threshold_tip",
            ));
        ui.end_row();
        row_label(ui, &tr("options.pen"));
        ui.checkbox(&mut c.pen_preview, tr("options.pen_preview"))
            .rich_tip(crate::ui::tips::pair(
                "options.pen_preview",
                "options.pen_preview_tip",
            ));
        ui.end_row();
        ui.label("");
        ui.checkbox(
            &mut c.pen_auto_add_delete,
            tr("options.pen_auto_add_delete"),
        )
        .rich_tip(crate::ui::tips::pair(
            "options.pen_auto_add_delete",
            "options.pen_auto_add_delete_tip",
        ));
        ui.end_row();
        row_label(ui, &tr("options.pen_tablet"));
        ui.checkbox(&mut c.pen_pressure, tr("options.pen_pressure"))
            .rich_tip(crate::ui::tips::pair(
                "options.pen_pressure",
                "options.pen_pressure_tip",
            ));
        ui.end_row();
        // Palm rejection: Android tells a pen from a finger (#1832).
        if crate::files::ANDROID {
            ui.label("");
            ui.checkbox(&mut c.pen_ignores_hand, tr("options.pen_ignores_hand"))
                .rich_tip(crate::ui::tips::pair(
                    "options.pen_ignores_hand",
                    "options.pen_ignores_hand_tip",
                ));
            ui.end_row();
        }
        row_label(ui, &tr("options.constrain_key"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.constrain_key", "options.constrain_key_tip"),
            |ui| {
                ui.horizontal(|ui| {
                    for k in crate::prefs::ConstrainKey::ALL {
                        ui.radio_value(&mut c.constrain_key, k, tr(k.i18n_key()))
                            .rich_tip_with(|| {
                                format!("{}\n{}", tr(k.i18n_key()), tr("options.constrain_key_tip"))
                            });
                    }
                });
            },
        );

        ui.end_row();
    });
    ui.add_space(4.0);
    ui.label(egui::RichText::new(tr("options.join_hint")).color(crate::theme::Tokens::text_dim()));
}

fn eraser_page(app: &mut App, ui: &mut Ui) {
    grid("eraser").show(ui, |ui| {
        row_label(ui, &tr("options.eraser_width"));
        let u = app.units;
        let mut v = u.from_mm(app.eraser_width);
        if ui
            .add(
                crate::ui::field::NumField::new(&mut v)
                    .speed(0.1)
                    .suffix(format!(" {}", u.short())),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.eraser_width",
                "options.eraser_width_tip",
            ))
            .changed()
        {
            app.eraser_width = u.to_mm(v).max(0.01);
        }
        ui.end_row();
    });
    ui.radio_value(&mut app.eraser_square, false, tr("options.eraser_round"))
        .rich_tip(crate::ui::tips::pair(
            "options.eraser_round",
            "options.eraser_round_tip",
        ));
    ui.radio_value(&mut app.eraser_square, true, tr("options.eraser_square"))
        .rich_tip(crate::ui::tips::pair(
            "options.eraser_square",
            "options.eraser_square_tip",
        ));
    ui.checkbox(
        &mut app.settings.eraser_reduce_nodes,
        tr("options.eraser_reduce_nodes"),
    )
    .rich_tip(crate::ui::tips::pair(
        "options.eraser_reduce_nodes",
        "options.eraser_reduce_nodes_tip",
    ));
}

// ----- Global ------------------------------------------------------------

fn global_general_page(app: &mut App, ui: &mut Ui) {
    grid("global").show(ui, |ui| {
        row_label(ui, &tr("options.language"));
        let current = crate::i18n::language();
        let name = crate::i18n::LANGUAGES
            .iter()
            .find(|(c, _)| *c == current)
            .map(|(_, n)| *n)
            .unwrap_or("English");
        // Following the system shows as System language and the language
        // it gives now.
        let shown = if app.settings.language == crate::i18n::SYSTEM {
            format!("{} ({name})", tr("options.language_system"))
        } else {
            name.to_string()
        };
        crate::ui::keynav::ComboBox::from_id_salt("opt_lang")
            .selected_text(shown)
            .width(200.0)
            .show_ui(ui, |ui| {
                // System language: follow the system's language, now and
                // when it changes (docs/behavior/language.md).
                let follows = app.settings.language == crate::i18n::SYSTEM;
                let system = crate::i18n::system_language();
                let system_name = crate::i18n::LANGUAGES
                    .iter()
                    .find(|(c, _)| *c == system)
                    .map(|(_, n)| *n)
                    .unwrap_or("English");
                let label = format!("{} ({system_name})", tr("options.language_system"));
                if ui.selectable_label(follows, label).clicked() {
                    crate::i18n::set_language(system);
                    app.settings.language = crate::i18n::SYSTEM.to_string();
                    #[cfg(not(target_arch = "wasm32"))]
                    crate::theme::language_changed(ui.ctx(), &current, system);
                }
                ui.separator();
                for (code, n) in crate::i18n::LANGUAGES {
                    let picked = !follows && current == code;
                    if ui.selectable_label(picked, n).clicked() {
                        crate::i18n::set_language(code);
                        app.settings.language = code.to_string();
                        #[cfg(not(target_arch = "wasm32"))]
                        crate::theme::language_changed(ui.ctx(), &current, code);
                    }
                }
            })
            .response
            .rich_tip(crate::ui::tips::pair(
                "options.language",
                "options.language_tip",
            ));
        ui.end_row();
    });
    // A copy from the Microsoft Store is updated by the Store.
    #[cfg(not(target_arch = "wasm32"))]
    if !crate::updates::store_install() {
        ui.checkbox(&mut app.settings.check_updates, tr("options.check_updates"))
            .rich_tip(tr("options.check_updates_tip"));
    }
    // AI agents on this computer and the open drawing (desktop only).
    #[cfg(not(target_arch = "wasm32"))]
    if DesktopOnly::Agents.shown() {
        chrome::section(ui, &tr("options.agents"));
        ui.checkbox(&mut app.settings.mcp_window, tr("options.mcp_window"))
            .rich_tip(crate::ui::tips::pair(
                "options.mcp_window",
                "options.mcp_window_tip",
            ));
        ui.label(egui::RichText::new(tr("options.mcp_window_hint")).color(Tokens::text_dim()));
        if let Some(link) = &app.mcp_link {
            ui.label(
                egui::RichText::new(trf(
                    "options.mcp_window_port",
                    &[("port", &link.info.port.to_string())],
                ))
                .color(Tokens::text_dim()),
            );
        }
    }
    ui.add_space(10.0);
    ui.label(egui::RichText::new(tr("options.reset_all_hint")).color(Tokens::text_dim()));
    if ui
        .button(tr("options.reset_all"))
        .rich_tip(crate::ui::tips::pair(
            "options.reset_all",
            "options.reset_all_tip",
        ))
        .clicked()
    {
        // The question replaces the options; nothing changes unless it is
        // answered Reset.
        if let Some(snapshot) = app.options_snapshot.take() {
            snapshot.restore(app);
        }
        app.dialog = crate::ui::dialogs::Dialog::ConfirmResetSettings;
    }
}

/// Why the system's text size is not followed here (#1412): macOS has
/// none for programs of this kind; elsewhere it could not be read.
pub fn text_size_unread_key() -> &'static str {
    if cfg!(target_os = "macos") {
        "options.follow_text_size_macos"
    } else {
        "options.follow_text_size_unread"
    }
}

fn file_locations_page(app: &mut App, ui: &mut Ui) {
    // The program Edit Bitmap opens pictures in (#593). Android has no
    // programs to name: it asks which app edits the picture (#1398).
    if crate::files::ANDROID {
        ui.label(tr("options.bitmap_editor"));
        ui.label(
            egui::RichText::new(tr("options.bitmap_editor_android"))
                .color(Tokens::text_dim())
                .size(11.0),
        );
        ui.add_space(10.0);
    } else if !crate::files::WEB {
        ui.label(tr("options.bitmap_editor"));
        ui.horizontal(|ui| {
            ui.add(
                egui::TextEdit::singleline(&mut app.settings.bitmap_editor)
                    .desired_width(300.0)
                    .hint_text(tr("options.bitmap_editor_system")),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.bitmap_editor",
                "options.bitmap_editor_tip",
            ));
            if ui
                .button(tr("options.browse"))
                .rich_tip(crate::ui::tips::pair(
                    "options.browse",
                    "options.browse_tip",
                ))
                .clicked()
            {
                crate::files::Dialog::new().pick_file(app, |app, path| {
                    app.settings.bitmap_editor = path.display().to_string();
                });
            }
            if ui
                .add_enabled(
                    !app.settings.bitmap_editor.is_empty(),
                    egui::Button::new(tr("options.clear_folder")),
                )
                .clicked()
            {
                app.settings.bitmap_editor.clear();
            }
        });
        ui.label(
            egui::RichText::new(tr("options.bitmap_editor_hint"))
                .color(Tokens::text_dim())
                .size(11.0),
        );
        ui.add_space(10.0);
    }
    ui.label(tr("options.save_hint"));
    if let Some(p) = crate::settings::Settings::path() {
        ui.label(
            egui::RichText::new(p.display().to_string())
                .color(Tokens::text_dim())
                .size(12.0),
        );
    }
    if let Some(p) = crate::app::App::auto_backup_dir_default() {
        ui.add_space(6.0);
        ui.label(tr("options.auto_backup"));
        ui.label(
            egui::RichText::new(p.display().to_string())
                .color(Tokens::text_dim())
                .size(12.0),
        );
    }
}

// ----- Workspaces --------------------------------------------------------

fn workspace_page(app: &mut App, ui: &mut Ui) {
    ui.label(tr("options.workspace_choose"));
    let frame = chrome::panel();
    frame.show(ui, |ui| {
        ui.set_min_width(ui.available_width());
        for ws in crate::app::Workspace::ALL {
            if ui
                .selectable_label(
                    app.workspace == ws,
                    tr(&format!("menu.window.workspace_{}", ws.id())),
                )
                .rich_tip_with(|| {
                    format!(
                        "{}\n{}",
                        tr(&format!("menu.window.workspace_{}", ws.id())),
                        tr("options.workspace_pick_tip")
                    )
                })
                .clicked()
            {
                app.set_workspace(ws);
            }
        }
    });
    ui.add_space(10.0);
    ui.strong(tr("options.workspace_transfer"));
    ui.label(egui::RichText::new(tr("options.workspace_transfer_hint")).color(Tokens::text_dim()));
    let mut parts = app.settings.workspace_parts;
    for (on, key) in parts.flags_mut() {
        ui.checkbox(on, tr(key))
            .rich_tip_with(|| format!("{}\n{}", tr(key), tr("options.workspace_part_tip")));
    }
    app.settings.workspace_parts = parts;
    ui.horizontal(|ui| {
        let any = parts.any();
        if ui
            .add_enabled(any, egui::Button::new(tr("options.workspace_export")))
            .rich_tip_always(crate::ui::tips::pair(
                "options.workspace_export",
                "options.workspace_export_tip",
            ))
            .clicked()
        {
            app.export_workspace_dialog(parts);
        }
        // Imported parts stay until OK; Cancel puts the old ones back.
        if ui
            .add_enabled(any, egui::Button::new(tr("options.workspace_import")))
            .rich_tip_always(crate::ui::tips::pair(
                "options.workspace_import",
                "options.workspace_import_tip",
            ))
            .clicked()
        {
            app.import_workspace_dialog(parts, false);
        }
    });
}

// ----- Document Setup --------------------------------------------------

fn document_general_page(app: &mut App, ui: &mut Ui) {
    if !app.has_document() {
        return;
    }
    let mut meta = app.doc().metadata.clone();
    grid("doc_general").show(ui, |ui| {
        row_label(ui, &tr("options.rendering_resolution"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair(
                "options.rendering_resolution",
                "options.rendering_resolution_tip",
            ),
            |ui| {
                ui.horizontal(|ui| {
                    let mut dpi = app.document_dpi();
                    if ui
                        .add_sized(
                            [80.0, 22.0],
                            crate::ui::field::NumField::new(&mut dpi).range(36.0..=2400.0),
                        )
                        .rich_tip(crate::ui::tips::pair(
                            "options.rendering_resolution",
                            "options.rendering_resolution_tip",
                        ))
                        .changed()
                    {
                        meta.resolution_dpi = dpi;
                    }
                    ui.label("dpi");
                });
            },
        );

        ui.end_row();
    });
    ui.checkbox(&mut meta.fill_open_curves, tr("options.fill_open_curves"))
        .rich_tip(crate::ui::tips::pair(
            "options.fill_open_curves",
            "options.fill_open_curves_tip",
        ));
    let mut inflate = !meta.no_auto_inflate;
    if ui
        .checkbox(&mut inflate, tr("options.auto_inflate_bitmaps"))
        .rich_tip(crate::ui::tips::pair(
            "options.auto_inflate_bitmaps",
            "options.auto_inflate_bitmaps_tip",
        ))
        .changed()
    {
        meta.no_auto_inflate = !inflate;
    }
    if meta != app.doc().metadata {
        app.run(Command::SetMetadata { metadata: meta });
    }
    ui.separator();
    // Ctrl+D places duplicates this far from the original.
    grid("dup").show(ui, |ui| {
        row_label(ui, &tr("options.duplicate_offset"));
        let u = app.units;
        let (mut dx, mut dy) = (
            u.world_from_mm(app.duplicate_offset.x),
            u.world_from_mm(app.duplicate_offset.y),
        );
        ui.horizontal(|ui| {
            let a = ui
                .add(
                    crate::ui::field::NumField::new(&mut dx)
                        .speed(0.1)
                        .suffix(format!(" {}", u.short())),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.duplicate_offset_x",
                    "options.duplicate_offset_x_tip",
                ));
            let b = ui
                .add(
                    crate::ui::field::NumField::new(&mut dy)
                        .speed(0.1)
                        .suffix(format!(" {}", u.short())),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.duplicate_offset_y",
                    "options.duplicate_offset_y_tip",
                ));
            if a.changed() || b.changed() {
                app.duplicate_offset =
                    tracedraw_core::geometry::Vec2::new(u.world_to_mm(dx), u.world_to_mm(dy));
            }
        });
        ui.end_row();
    });
}

fn layout_page(app: &mut App, ui: &mut Ui) {
    let n = app.doc().pages.len();
    ui.label(trf("options.pages_count", &[("n", &n.to_string())]));
    ui.checkbox(&mut app.page_sorter, tr("menu.view.page_sorter"))
        .rich_tip(crate::ui::tips::keyed("menu.view.page_sorter"));
    if ui
        .button(tr("menu.layout.switch_orientation"))
        .rich_tip(crate::ui::tips::pair(
            "menu.layout.switch_orientation",
            "menu.layout.switch_orientation_tip",
        ))
        .clicked()
    {
        let s = app.page_size();
        let page = app.page;
        let size = Size::new(s.height, s.width);
        app.resize_pages_about_centre(&[page], size, "Switch Page Orientation");
        app.fit_pending = true;
    }
    page_spacing_row(app, ui);
    facing_pages_row(app, ui);
    page_margins_row(app, ui);
    ui.separator();
    ui.strong(tr("options.master_layers"));
    type MasterRow = (
        tracedraw_core::LayerId,
        String,
        tracedraw_core::MasterScope,
        bool,
    );
    let masters: Vec<MasterRow> = app
        .doc()
        .master
        .iter()
        .map(|l| (l.id, l.name.clone(), l.scope, l.in_front))
        .collect();
    for (id, name, scope, front) in masters {
        ui.horizontal(|ui| {
            ui.label(&name);
            // Drawn over the page's own layers or behind them (#1132).
            let mut on = front;
            if ui
                .checkbox(&mut on, tr("docker.in_front"))
                .rich_tip(tr("docker.master_in_front"))
                .clicked()
            {
                app.run(Command::SetLayerInFront {
                    layer: id,
                    in_front: on,
                });
            }
            for (s, k) in [
                (tracedraw_core::MasterScope::All, "options.scope_all"),
                (tracedraw_core::MasterScope::Odd, "options.scope_odd"),
                (tracedraw_core::MasterScope::Even, "options.scope_even"),
            ] {
                if ui
                    .selectable_label(scope == s, tr(k))
                    .rich_tip_with(|| format!("{}\n{}", tr(k), tr(&format!("{k}_tip"))))
                    .clicked()
                {
                    app.run(Command::SetLayerScope {
                        layer: id,
                        scope: s,
                    });
                }
            }
        });
    }
    ui.horizontal(|ui| {
        for (s, k) in [
            (tracedraw_core::MasterScope::All, "options.new_master_all"),
            (tracedraw_core::MasterScope::Odd, "options.new_master_odd"),
            (tracedraw_core::MasterScope::Even, "options.new_master_even"),
        ] {
            if ui
                .button(tr(k))
                .rich_tip_with(|| format!("{}\n{}", tr(k), tr(&format!("{k}_tip"))))
                .clicked()
            {
                crate::ui::objects_docker::new_master_layer(app, s);
            }
        }
    });
    // Which kinds of master layer are drawn in front of the page's
    // layers, now and when made (#1132, #1477).
    crate::ui::objects_docker::master_front_choices(app, ui);
}

/// Document Setup > Layout: Facing pages and the side the first page
/// starts on (#1972, #1660), one undo step each.
fn facing_pages_row(app: &mut App, ui: &mut Ui) {
    use tracedraw_core::spreads::PageSide;
    let (mut on, mut start) = {
        let m = &app.doc().metadata;
        (m.facing_pages, m.facing_start)
    };
    let r = ui
        .checkbox(&mut on, tr("options.facing_pages"))
        .rich_tip(crate::ui::tips::pair(
            "options.facing_pages",
            "options.facing_pages_tip",
        ));
    let mut changed = r.changed();
    ui.add_enabled_ui(on, |ui| {
        grid("doc_facing_start").show(ui, |ui| {
            row_label(ui, &tr("options.facing_start"));
            ui.horizontal(|ui| {
                for (side, key) in [
                    (PageSide::Right, "options.facing_start_right"),
                    (PageSide::Left, "options.facing_start_left"),
                ] {
                    if ui
                        .radio_value(&mut start, side, tr(key))
                        .rich_tip(crate::ui::tips::pair(
                            "options.facing_start",
                            "options.facing_start_tip",
                        ))
                        .changed()
                    {
                        changed = true;
                    }
                }
            });
            ui.end_row();
        });
    });
    if changed {
        app.set_facing_pages(on, start);
    }
}

/// Document Setup > Layout: Margins, the page margins for book layouts
/// (#1660): top, bottom, inside (at the spine with facing pages, else
/// on the left) and outside, in the document's units, one undo step a
/// change. Shown on the pages as a dashed frame.
fn page_margins_row(app: &mut App, ui: &mut Ui) {
    use tracedraw_core::document::{PageMargins, MAX_PAGE_MARGIN};
    let u = app.units;
    let current = app.doc().metadata.margins;
    let mut on = current.is_some();
    let mut changed = ui
        .checkbox(&mut on, tr("options.page_margins"))
        .rich_tip(crate::ui::tips::pair(
            "options.page_margins",
            "options.page_margins_tip",
        ))
        .changed();
    // Ticked: 12.7 mm all round to start with.
    let mut m = current.unwrap_or(PageMargins::uniform(12.7));
    ui.add_enabled_ui(on, |ui| {
        grid("doc_page_margins").show(ui, |ui| {
            for (key, v) in [
                ("options.margin_top", &mut m.top),
                ("options.margin_bottom", &mut m.bottom),
                ("options.margin_inside", &mut m.inside),
                ("options.margin_outside", &mut m.outside),
            ] {
                row_label(ui, &tr(key));
                let mut shown = u.from_mm(*v);
                if ui
                    .add_sized(
                        [100.0, 22.0],
                        crate::ui::field::NumField::new(&mut shown)
                            .range(0.0..=u.from_mm(MAX_PAGE_MARGIN))
                            .speed(0.1)
                            .suffix(format!(" {}", u.short())),
                    )
                    .rich_tip(crate::ui::tips::pair(key, "options.page_margins_tip"))
                    .changed()
                {
                    *v = u.to_mm(shown);
                    changed = true;
                }
                ui.end_row();
            }
        });
    });
    if changed {
        app.set_page_margins(on.then_some(m));
    }
}

/// Document Setup > Layout: the space between the pages of the
/// Multipage View, in the document's units (a document property; Save as
/// Default keeps it for new drawings).
fn page_spacing_row(app: &mut App, ui: &mut Ui) {
    let u = app.units;
    grid("doc_page_spacing").show(ui, |ui| {
        row_label(ui, &tr("options.page_spacing"));
        let mut v = u.from_mm(app.page_spacing());
        let r = ui
            .add_sized(
                [100.0, 22.0],
                crate::ui::field::NumField::new(&mut v)
                    .range(0.0..=u.from_mm(tracedraw_core::document::MAX_PAGE_SPACING))
                    .speed(0.1)
                    .suffix(format!(" {}", u.short())),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.page_spacing",
                "options.page_spacing_tip",
            ));
        if r.changed() {
            app.set_page_spacing(u.to_mm(v));
        }
        ui.end_row();
    });
}

fn background_page(app: &mut App, ui: &mut Ui) {
    let page = app.page;
    let current = app.doc().page(page).ok().and_then(|p| p.background.clone());
    let mut kind = match &current {
        None => 0,
        Some(Fill::Solid(_)) => 1,
        Some(_) => 2,
    };
    ui.horizontal(|ui| {
        ui.radio_value(&mut kind, 0, tr("options.no_background"))
            .rich_tip(crate::ui::tips::pair(
                "options.no_background",
                "options.no_background_tip",
            ));
        ui.radio_value(&mut kind, 1, tr("options.solid"))
            .rich_tip(crate::ui::tips::pair("options.solid", "options.solid_tip"));
        ui.radio_value(&mut kind, 2, tr("options.bitmap"))
            .rich_tip(crate::ui::tips::pair(
                "options.bitmap",
                "options.bitmap_tip",
            ));
    });
    match kind {
        0 => {
            if current.is_some() {
                app.run(Command::SetPageBackground {
                    page,
                    background: None,
                });
            }
        }
        1 => {
            let mut c = match &current {
                Some(Fill::Solid(c)) => *c,
                _ => Color::WHITE,
            };
            let changed = crate::ui::color_picker::color_button(ui, &mut c);
            if changed || !matches!(current, Some(Fill::Solid(_))) {
                app.run(Command::SetPageBackground {
                    page,
                    background: Some(Fill::Solid(c)),
                });
            }
        }
        _ => {
            if ui
                .button(tr("options.choose_bitmap"))
                .rich_tip(crate::ui::tips::pair(
                    "options.choose_bitmap",
                    "options.choose_bitmap_tip",
                ))
                .clicked()
            {
                crate::files::Dialog::new()
                    .add_filter(
                        "Images",
                        &["png", "jpg", "jpeg", "bmp", "gif", "webp", "tif", "tiff"],
                    )
                    .pick_file(app, move |app, p| app.set_page_background_image(page, &p));
            }
        }
    }
}

fn bleed_page(app: &mut App, ui: &mut Ui) {
    let mut md = app.doc().metadata.clone();
    grid("bleed").show(ui, |ui| {
        row_label(ui, &tr("options.bleed"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.bleed", "options.bleed_tip"),
            |ui| {
                let mut b = app.units.from_mm(md.bleed);
                if ui
                    .add_sized(
                        [100.0, 22.0],
                        crate::ui::field::NumField::new(&mut b)
                            .speed(0.1)
                            .max_decimals(3)
                            .suffix(format!(" {}", app.units.short())),
                    )
                    .changed()
                {
                    md.bleed = app.units.to_mm(b).max(0.0);
                    app.run(Command::SetMetadata {
                        metadata: md.clone(),
                    });
                    app.show_bleed |= md.bleed > 0.0;
                };
            },
        );

        ui.end_row();
        row_label(ui, &tr("options.margin"));
        crate::ui::tips::tip_over(
            ui,
            crate::ui::tips::pair("options.margin", "options.margin_tip"),
            |ui| {
                let mut m = app.units.from_mm(md.margin);
                if ui
                    .add_sized(
                        [100.0, 22.0],
                        crate::ui::field::NumField::new(&mut m)
                            .speed(0.1)
                            .max_decimals(3)
                            .suffix(format!(" {}", app.units.short())),
                    )
                    .changed()
                {
                    md.margin = app.units.to_mm(m).max(0.0);
                    app.run(Command::SetMetadata {
                        metadata: md.clone(),
                    });
                    app.show_margin |= md.margin > 0.0;
                };
            },
        );
        ui.end_row();
    });
    ui.checkbox(&mut app.show_bleed, tr("options.show_bleed"))
        .rich_tip(crate::ui::tips::pair(
            "options.show_bleed",
            "options.show_bleed_tip",
        ));
    ui.checkbox(&mut app.show_margin, tr("options.show_margin"))
        .rich_tip(crate::ui::tips::pair(
            "options.show_margin",
            "options.show_margin_tip",
        ));
}

#[cfg(test)]
mod tests {
    use super::*;

    /// #1415: the splash, hardware acceleration and AI agent options are
    /// shown on the desktop and hidden on Android and in the browser,
    /// where they do nothing; the pages and the agent link ask first.
    #[test]
    fn desktop_only_options_are_hidden_on_android_and_the_web() {
        use crate::files::Platform;
        for o in DesktopOnly::ALL {
            assert!(o.shown_on(Platform::Desktop), "{o:?}");
            assert!(!o.shown_on(Platform::Android), "{o:?}");
            assert!(!o.shown_on(Platform::Web), "{o:?}");
            assert_eq!(o.shown(), Platform::current() == Platform::Desktop);
        }
        let page = include_str!("options.rs");
        for gate in [
            "if DesktopOnly::Splash.shown() {",
            "if DesktopOnly::HardwareAcceleration.shown() {",
            "if DesktopOnly::Agents.shown() {",
        ] {
            assert!(page.contains(gate), "{gate}");
        }
        assert!(include_str!("../mcp_link.rs")
            .contains("&& crate::ui::options::DesktopOnly::Agents.shown();"));
    }

    /// On the desktop the General page still shows the splash and the
    /// hardware acceleration options.
    #[test]
    fn the_desktop_keeps_the_splash_and_hardware_options() {
        let mut app = App::headless();
        let ctx = crate::theme::ui_context();
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| general_page(&mut app, ui));
        out.textures_delta.clear();
        let mut texts = Vec::new();
        for c in &out.shapes {
            if let egui::Shape::Text(t) = &c.shape {
                texts.push(t.galley.text().to_string());
            }
        }
        for key in ["options.show_splash", "options.hardware_acceleration"] {
            let label = tr(key);
            assert!(texts.contains(&label), "{label:?} in {texts:?}");
        }
    }

    /// On Linux the General page offers the desktop's title bar, on by
    /// default (#2486), and its box turns it off for the native Wayland
    /// window (#2070).
    #[cfg(target_os = "linux")]
    #[test]
    fn linux_offers_the_desktops_title_bar() {
        let mut app = App::headless();
        assert!(app.settings.system_title_bar);
        let ctx = crate::theme::ui_context();
        let label = tr("options.system_title_bar");
        let mut at = None;
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| general_page(&mut app, ui));
        out.textures_delta.clear();
        for c in &out.shapes {
            if let egui::Shape::Text(t) = &c.shape {
                if t.galley.text() == label {
                    at = Some(t.visual_bounding_rect().center());
                }
            }
        }
        let at = at.unwrap_or_else(|| panic!("{label:?} is not on the General page"));
        for pressed in [true, false] {
            let input = egui::RawInput {
                events: vec![
                    egui::Event::PointerMoved(at),
                    egui::Event::PointerButton {
                        pos: at,
                        button: egui::PointerButton::Primary,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
                ..Default::default()
            };
            let mut out = ctx.run_ui(input, |ui| general_page(&mut app, ui));
            out.textures_delta.clear();
        }
        assert!(!app.settings.system_title_bar);
    }

    /// #1148: every command can take a shortcut. A bar button that runs
    /// a menu command shows that command's keys; rows the menus show only
    /// at times (Finish Editing Contents, Vertical Text) are listed too.
    #[test]
    fn bar_buttons_and_rows_shown_at_times_take_shortcuts() {
        let mut app = App::headless();
        let ctx = egui::Context::default();
        let mut entries = Vec::new();
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
            entries = crate::ui::menus::commands(&mut app, ui.ctx());
        });
        out.textures_delta.clear();
        app.shortcut_editor.entries = entries;
        for key in [
            "menu.object.clip_frame_finish",
            "menu.object.clip_frame_edit",
            "menu.text.vertical_text",
            // The clip bar's Fit Contents choices (#1299).
            "menu.object.clip_frame_fit_center",
            "menu.object.clip_frame_fit_proportional",
            "menu.object.clip_frame_fill_proportional",
            "menu.object.clip_frame_stretch",
        ] {
            assert!(
                app.shortcut_editor.entries.iter().any(|e| e.key == key),
                "{key} is not listed"
            );
        }
        // Each button's menu command is one the menus have.
        for id in crate::ui::bar_items::all_buttons() {
            if let Some(key) = crate::ui::bar_items::menu_command(id) {
                assert!(
                    app.shortcut_editor.entries.iter().any(|e| e.key == key),
                    "{id}: {key} is not a menu command"
                );
            }
        }
        let buttons = command_items(&app, Some(BUTTONS), "");
        let zoom_in = buttons
            .iter()
            .find(|c| c.id == "zoom_in")
            .cloned()
            .expect("zoom in button");
        let target = keys_target(&app, zoom_in);
        assert_eq!(target.id, "menu.view.zoom_in");
        assert!(!crate::ui::bar_items::is_button(&target.id));
        // A key set through the button runs the menu command.
        set_menu_shortcut(&mut app, &target.id, "Alt+Shift+Z");
        assert!(current_keys(&app, &target).contains(&"Alt+Shift+Z".to_string()));
        assert!(app
            .settings
            .shortcuts
            .iter()
            .any(|(k, v)| k == "menu.view.zoom_in" && v == "Alt+Shift+Z"));
        // A button the menus lack stays without keys.
        let levels = buttons
            .iter()
            .find(|c| c.id == "zoom_levels")
            .cloned()
            .expect("zoom levels");
        assert_eq!(keys_target(&app, levels).id, "zoom_levels");
    }

    #[test]
    fn command_list_filters_by_menu_toolbox_and_text() {
        let mut app = App::headless();
        let ctx = egui::Context::default();
        let mut entries = Vec::new();
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
            entries = crate::ui::menus::commands(&mut app, ui.ctx());
        });
        out.textures_delta.clear();
        app.shortcut_editor.entries = entries;
        let all = command_items(&app, None, "");
        let file = command_items(&app, Some("menu.file"), "");
        let tools = command_items(&app, Some(TOOLBOX), "");
        assert!(file
            .iter()
            .any(|c| c.id == "menu.file.open" && c.built_in == "Ctrl+O"));
        assert!(file.iter().all(|c| c.tool.is_none()));
        assert_eq!(tools.len(), crate::tools::Tool::ALL.len());
        let buttons = command_items(&app, Some(BUTTONS), "");
        assert_eq!(
            all.len(),
            app.shortcut_editor.entries.len() + tools.len() + buttons.len()
        );
        let found = command_items(&app, None, "open");
        assert!(!found.is_empty() && found.len() < all.len());
        // Table's commands come under Text, where their submenu sits;
        // there is no Table category.
        let text = command_items(&app, Some("menu.text"), "");
        assert!(text.iter().any(|c| c.id == "menu.table.create_new_table"));
        assert!(text.iter().any(|c| c.id == "menu.text.grammar"));
        assert!(command_items(&app, Some("menu.table"), "").is_empty());
        // Listed in alphabetical order (#3212).
        for category in [None, Some("menu.file"), Some("menu.text"), Some(TOOLBOX)] {
            let list = listed_commands(&app, category, "");
            assert_eq!(list.len(), command_items(&app, category, "").len());
            let names: Vec<String> = list.iter().map(|c| c.name.to_lowercase()).collect();
            assert!(names.windows(2).all(|w| w[0] <= w[1]), "{names:?}");
        }
        // A user's key shows beside the built-in one (#822).
        let open = file
            .iter()
            .find(|c| c.id == "menu.file.open")
            .cloned()
            .expect("open");
        set_menu_shortcut(&mut app, "menu.file.open", "Ctrl+Shift+O");
        assert_eq!(current_keys(&app, &open), ["Ctrl+O", "Ctrl+Shift+O"]);
    }

    /// No two commands share a built-in shortcut in one context: every
    /// menu command's, every tool's and every panel's default keys are
    /// their own (#1779). The
    /// documented splits are E, Align Centers Horizontally with a
    /// selection and the Roughen tool without one (`shortcuts.md`, Align
    /// keys and tool keys) (#1595), the clip frame's Edit Contents
    /// and Finish Editing, never offered together: one key goes in and
    /// out (#1273), and Shift+L, Shift+B and Shift+C, node commands with
    /// the Shape tool and nodes chosen and Distribute keys otherwise
    /// (`shortcuts.md`, Distribute keys) (#2147).
    #[test]
    fn no_two_default_commands_share_a_shortcut() {
        let app = app_with_commands();
        let shared = shared_default_shortcuts(&app);
        assert!(
            shared.is_empty(),
            "shared shortcuts:\n{}",
            shared.join("\n")
        );
    }

    /// The built-in keys two commands share, past the documented split.
    fn shared_default_shortcuts(app: &App) -> Vec<String> {
        let mut holders: std::collections::BTreeMap<String, Vec<String>> = Default::default();
        for c in command_items(app, None, "") {
            if c.built_in.is_empty() {
                continue;
            }
            let (m, k) = crate::shortcuts::parse(&c.built_in)
                .unwrap_or_else(|| panic!("{}: {} is no shortcut", c.id, c.built_in));
            holders
                .entry(crate::shortcuts::format(m, k))
                .or_default()
                .push(c.id.clone());
        }
        // The panels' keys too (Window > Panels): the panel takes its key,
        // so a menu command showing it never ran (Spell Check showed the
        // Fonts panel's Ctrl+F12, #1779). A menu row that opens the panel
        // itself is the panel.
        use crate::app::DockerTab;
        let opens_panel = |id: &str, tab: DockerTab| {
            [
                ("menu.object.properties", DockerTab::Properties),
                ("menu.text.text_docker", DockerTab::Text),
                ("menu.text.glyphs", DockerTab::Glyphs),
                ("menu.edit.find_and_replace", DockerTab::FindReplace),
                ("menu.edit.step_and_repeat", DockerTab::StepAndRepeat),
                ("menu.object.tf_position", DockerTab::Transformations),
                ("menu.object.symbol_manager", DockerTab::Symbols),
                ("menu.effects.envelope", DockerTab::Envelope),
                ("menu.effects.contour", DockerTab::Contour),
                ("menu.effects.lens", DockerTab::Lens),
            ]
            .contains(&(id, tab))
        };
        for tab in DockerTab::ALL {
            let keys = tab.shortcut();
            if keys.is_empty() {
                continue;
            }
            let (m, k) = crate::shortcuts::parse(keys)
                .unwrap_or_else(|| panic!("{tab:?}: {keys} is no shortcut"));
            let ids = holders.entry(crate::shortcuts::format(m, k)).or_default();
            ids.retain(|id| !opens_panel(id, tab));
            ids.push(format!("panel {tab:?}"));
        }
        // Shift+L, Shift+B and Shift+C: a node command with the Shape
        // tool and nodes chosen, Distribute otherwise (#2147).
        let node_or_distribute = |keys: &str, ids: &[String]| {
            [
                (
                    "Shift+B",
                    "menu.object.distribute_bottom",
                    "menu.object.node_break",
                ),
                (
                    "Shift+C",
                    "menu.object.distribute_centers_v",
                    "menu.object.node_cusp",
                ),
                (
                    "Shift+L",
                    "menu.object.distribute_left",
                    "menu.object.node_to_line",
                ),
            ]
            .iter()
            .any(|(k, distribute, node)| keys == *k && ids == [*distribute, *node])
        };
        let documented_split = |keys: &str, ids: &[String]| {
            (keys == "E" && ids == ["menu.object.align_centers_h", "roughen"])
                || node_or_distribute(keys, ids)
                || (keys == crate::ui::menus::CLIP_EDIT_KEY
                    && ids
                        == [
                            "menu.object.clip_frame_finish",
                            "menu.object.clip_frame_edit",
                        ])
        };
        holders
            .iter()
            .filter(|(keys, ids)| ids.len() > 1 && !documented_split(keys, ids))
            .map(|(keys, ids)| format!("{keys}: {}", ids.join(", ")))
            .collect()
    }

    /// The built-in keys of every menu command, tool and panel, and the
    /// Ctrl keys the canvas (`pressed(Key::X, cmd)` in `interaction.rs`)
    /// and the text being typed (`Key::X if ctrl` in `text_editing.rs`)
    /// check themselves, each as the build shows it
    /// (`shortcuts::mac_shown`): (holder, keys).
    fn default_keys_shown(app: &App) -> Vec<(String, String)> {
        use crate::shortcuts::mac_shown;
        let mut out: Vec<(String, String)> = command_items(app, None, "")
            .into_iter()
            .filter(|c| !c.built_in.is_empty())
            .map(|c| (c.id, c.built_in))
            .collect();
        for tab in crate::app::DockerTab::ALL {
            if !tab.shortcut().is_empty() {
                out.push((format!("panel {tab:?}"), mac_shown(tab.shortcut().into())));
            }
        }
        let ident = |k: &str| {
            let k: String = k
                .chars()
                .take_while(|c| c.is_ascii_alphanumeric())
                .collect();
            k.strip_prefix("Num").map(str::to_string).unwrap_or(k)
        };
        for part in include_str!("../interaction.rs")
            .split("pressed(Key::")
            .skip(1)
        {
            let Some((k, rest)) = part.split_once(',') else {
                continue;
            };
            let Some((m, _)) = rest.split_once(')') else {
                continue;
            };
            if !(m.contains("cmd") || m.contains("COMMAND")) {
                continue;
            }
            let mut text = "Ctrl+".to_string();
            if m.contains("ALT") {
                text.push_str("Alt+");
            }
            if m.contains("SHIFT") {
                text.push_str("Shift+");
            }
            text.push_str(&ident(k.trim()));
            out.push(("canvas".into(), mac_shown(text)));
        }
        for part in include_str!("../text_editing.rs").split("Key::").skip(1) {
            let Some((head, _)) = part.split_once("=>") else {
                continue;
            };
            let Some((k, cond)) = head.split_once(" if ") else {
                continue;
            };
            if !cond.trim_start().starts_with("ctrl") || k.contains(char::is_whitespace) {
                continue;
            }
            let text = if cond.contains("!shift") || !cond.contains("shift") {
                format!("Ctrl+{}", ident(k))
            } else {
                format!("Ctrl+Shift+{}", ident(k))
            };
            out.push(("typing".into(), mac_shown(text)));
        }
        out
    }

    /// #1409: in the macOS desktop app no built-in key is a Command key
    /// macOS keeps for itself (Quit, Log Out, Hide, Minimize, the
    /// application switcher, Spotlight, Force Quit, the screenshots): the
    /// commands that have one built in (Convert to Curves' Command+Q)
    /// take the key of `shortcuts::MAC_KEYS` there, and the menus and
    /// the Commands page show it. File > Exit alone shows Command+Q, the
    /// system's own Quit. Each alternative is bound to nothing else, and
    /// still no two commands share a key there.
    #[test]
    fn no_default_shortcut_is_a_macos_system_key() {
        use crate::shortcuts::{mac_system_key, same, MAC_KEYS, MAC_QUIT};
        crate::shortcuts::set_mac_keys_for_test(false);
        let other = default_keys_shown(&app_with_commands());
        assert!(other
            .iter()
            .any(|(id, k)| id == "menu.object.convert_to_curves" && k == "Ctrl+Q"));
        crate::shortcuts::set_mac_keys_for_test(true);
        let app = app_with_commands();
        let mac = default_keys_shown(&app);
        let taken: Vec<String> = mac
            .iter()
            .filter(|(id, k)| mac_system_key(k) && !(id == "menu.file.exit" && k == MAC_QUIT))
            .map(|(id, k)| format!("{k}: {id}"))
            .collect();
        assert!(taken.is_empty(), "keys macOS keeps:\n{}", taken.join("\n"));
        for (id, k) in [
            ("menu.object.convert_to_curves", "Alt+Shift+C"),
            ("menu.object.convert_outline_to_object", "Alt+Shift+Q"),
            ("menu.table.merge_cells", "Ctrl+Shift+M"),
            ("menu.file.exit", "Ctrl+Q"),
            ("canvas", "Ctrl+Shift+Space"),
            ("typing", "Ctrl+Shift+H"),
        ] {
            assert!(mac.iter().any(|(i, s)| i == id && s == k), "{id}: {k}");
        }
        // The menus and context menus show the same keys there.
        crate::ui::menus::invoke::set_bindings(&[]);
        assert_eq!(
            crate::ui::menus::invoke::shown_shortcut("menu.object.convert_to_curves", "Ctrl+Q"),
            "Alt+Shift+C"
        );
        assert_eq!(
            crate::ui::menus::invoke::shown_shortcut("menu.file.exit", "Alt+F4"),
            "Ctrl+Q"
        );
        // An alternative is no key of the other systems' either.
        for (k, alt) in MAC_KEYS {
            assert!(!mac_system_key(alt), "{alt}");
            assert!(
                !other.iter().any(|(_, o)| same(o, alt)),
                "{alt} (for {k}) is used"
            );
        }
        // No two commands share a key in the macOS app.
        assert_eq!(shared_default_shortcuts(&app), Vec::<String>::new());
        // A Command key macOS keeps cannot be given as a shortcut there.
        assert!(!crate::shortcuts::allowed(
            egui::Modifiers::COMMAND,
            egui::Key::H
        ));
        crate::shortcuts::set_mac_keys_for_test(false);
        assert!(crate::shortcuts::allowed(
            egui::Modifiers::COMMAND,
            egui::Key::H
        ));
    }

    /// The Node editing table (#3243): a key set there holds only with
    /// the Shape tool, over the main one, and takes nothing from the
    /// main table; it is kept with the workspace's shortcuts.
    #[test]
    fn a_node_editing_key_holds_only_with_the_shape_tool() {
        use egui::{Key, Modifiers};
        let mut app = app_with_commands();
        // Ctrl+D given to the Ellipse tool in the Node editing table, as
        // the page sets it.
        app.shortcut_editor.node_table = true;
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
        set_menu_shortcut(&mut app, "ellipse", "Ctrl+D");
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
        app.shortcut_editor.node_table = false;
        assert_eq!(
            app.settings.node_shortcuts,
            vec![("ellipse".to_string(), "Ctrl+D".to_string())]
        );
        assert!(app.settings.shortcuts.is_empty());
        let ctx = crate::theme::ui_context();
        app.show_welcome = false;
        let id = app
            .new_shape(tracedraw_core::document::ShapeKind::Rect {
                rect: tracedraw_core::geometry::Rect::new(10.0, 10.0, 40.0, 40.0),
                radius: 0.0,
                corners: None,
            })
            .expect("rect");
        let count = |app: &App| {
            app.doc().pages[0]
                .layers
                .iter()
                .map(|l| l.shapes.len())
                .sum::<usize>()
        };
        // With the Pick tool Ctrl+D duplicates, as it does built in.
        app.select(vec![id]);
        let before = count(&app);
        frame(&ctx, &mut app, vec![key(Key::D, Modifiers::COMMAND)]);
        assert_eq!(count(&app), before + 1);
        assert_eq!(app.tool, crate::tools::Tool::Pick);
        // With the Shape tool it picks the Ellipse tool, and copies nothing.
        frame(
            &ctx,
            &mut app,
            vec![egui::Event::Key {
                key: Key::D,
                physical_key: None,
                pressed: false,
                repeat: false,
                modifiers: Modifiers::COMMAND,
            }],
        );
        app.choose_tool(crate::tools::Tool::Shape);
        app.select(vec![id]);
        let before = count(&app);
        frame(&ctx, &mut app, vec![key(Key::D, Modifiers::COMMAND)]);
        assert_eq!(app.tool, crate::tools::Tool::Ellipse);
        assert_eq!(count(&app), before);
        // The table goes with the workspace's shortcuts.
        let file = app.export_workspace(Default::default());
        let mut to = App::headless();
        to.import_workspace(&file, Default::default());
        assert_eq!(to.settings.node_shortcuts, app.settings.node_shortcuts);
        // Delete in the table leaves no empty key behind.
        let ellipse = command_items(&app, None, "")
            .into_iter()
            .find(|c| c.id == "ellipse")
            .expect("ellipse");
        app.shortcut_editor.node_table = true;
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
        assert_eq!(current_keys(&app, &ellipse), ["Ctrl+D"]);
        remove_shortcut(&mut app, &ellipse);
        assert!(current_keys(&app, &ellipse).is_empty());
        std::mem::swap(&mut app.settings.shortcuts, &mut app.settings.node_shortcuts);
        assert!(app.settings.node_shortcuts.is_empty());
    }

    /// A shortcut given to a command is taken from the command or tool
    /// that had it built in: that one is left without keys (an empty
    /// shortcut, as Delete leaves it) and the key runs the new command
    /// alone, a tool's too (#1595).
    #[test]
    fn a_shortcut_given_to_a_command_is_taken_from_its_built_in_holder() {
        use egui::{Key, Modifiers};
        let mut app = app_with_commands();
        let item = |app: &App, id: &str| {
            command_items(app, None, "")
                .into_iter()
                .find(|c| c.id == id)
                .unwrap_or_else(|| panic!("{id}"))
        };
        // Zoom's Z given to the Rectangle tool.
        assert_eq!(current_keys(&app, &item(&app, "zoom")), ["Z"]);
        set_menu_shortcut(&mut app, "rectangle", "Z");
        assert!(current_keys(&app, &item(&app, "zoom")).is_empty());
        assert!(app
            .settings
            .shortcuts
            .contains(&("zoom".to_string(), String::new())));
        assert_eq!(current_keys(&app, &item(&app, "rectangle")), ["F6", "Z"]);
        let note = app.shortcut_editor.note.clone().unwrap_or_default();
        assert!(note.contains(&crate::tools::Tool::Zoom.name()), "{note}");
        // Duplicate's Ctrl+D given to the Ellipse tool.
        set_menu_shortcut(&mut app, "ellipse", "Ctrl+D");
        assert!(current_keys(&app, &item(&app, "menu.edit.duplicate")).is_empty());
        // The keys run their new commands alone: Z picks the rectangle,
        // not the zoom, and Ctrl+D picks the ellipse without a copy.
        let ctx = crate::theme::ui_context();
        app.show_welcome = false;
        let id = app
            .new_shape(tracedraw_core::document::ShapeKind::Rect {
                rect: tracedraw_core::geometry::Rect::new(10.0, 10.0, 40.0, 40.0),
                radius: 0.0,
                corners: None,
            })
            .expect("rect");
        app.select(vec![id]);
        let count = |app: &App| {
            app.doc().pages[0]
                .layers
                .iter()
                .map(|l| l.shapes.len())
                .sum::<usize>()
        };
        let before = count(&app);
        frame(&ctx, &mut app, vec![key(Key::Z, Modifiers::NONE)]);
        assert_eq!(app.tool, crate::tools::Tool::Rectangle);
        app.select(vec![id]);
        frame(&ctx, &mut app, vec![key(Key::D, Modifiers::COMMAND)]);
        frame(&ctx, &mut app, vec![]);
        assert_eq!(app.tool, crate::tools::Tool::Ellipse);
        assert_eq!(count(&app), before, "no copy");
        // Reset gives the zoom its key back.
        reset_category_shortcuts(&mut app, TOOLBOX);
        assert_eq!(current_keys(&app, &item(&app, "zoom")), ["Z"]);
    }

    /// The app with the menu commands collected, as the Commands page has.
    fn app_with_commands() -> App {
        let mut app = App::headless();
        let ctx = egui::Context::default();
        let mut entries = Vec::new();
        let mut out = ctx.run_ui(egui::RawInput::default(), |ui| {
            entries = crate::ui::menus::commands(&mut app, ui.ctx());
        });
        out.textures_delta.clear();
        app.shortcut_editor.entries = entries;
        app
    }

    #[test]
    fn a_built_in_shortcut_can_be_removed() {
        let mut app = app_with_commands();
        let file = command_items(&app, Some("menu.file"), "");
        let open = file
            .iter()
            .find(|c| c.id == "menu.file.open")
            .cloned()
            .expect("open");
        assert_eq!(current_keys(&app, &open), vec!["Ctrl+O".to_string()]);
        // Delete on a built-in shortcut: an empty one overrides it.
        remove_shortcut(&mut app, &open);
        assert!(current_keys(&app, &open).is_empty());
        assert!(app
            .settings
            .shortcuts
            .contains(&("menu.file.open".to_string(), String::new())));
        // A user's own key on a command with none built in just goes.
        let tool = command_items(&app, Some(TOOLBOX), "")
            .into_iter()
            .find(|c| c.built_in.is_empty())
            .expect("a tool without a built-in key");
        set_menu_shortcut(&mut app, &tool.id, "Alt+Shift+K");
        assert_eq!(current_keys(&app, &tool), vec!["Alt+Shift+K".to_string()]);
        remove_shortcut(&mut app, &tool);
        assert!(current_keys(&app, &tool).is_empty());
        assert!(!app.settings.shortcuts.iter().any(|(k, _)| k == &tool.id));
    }

    /// A button taken off a bar is listed under Toolbar buttons and goes
    /// back on when dragged there; every built-in button has a name
    /// (#836).
    #[test]
    fn a_removed_toolbar_button_can_be_put_back() {
        use crate::ui::bar_items::{apply_drop, items, ItemBar, ItemDrag};
        let mut app = app_with_commands();
        let zoom = items(&app, ItemBar::Zoom);
        let i = zoom
            .iter()
            .position(|x| x == "zoom_page")
            .expect("on the bar");
        // Dragged off the bar.
        apply_drop(
            &mut app,
            &ItemDrag {
                item: "zoom_page".into(),
                from: Some((ItemBar::Zoom, i)),
            },
            None,
        );
        assert!(!items(&app, ItemBar::Zoom).contains(&"zoom_page".to_string()));
        let buttons = command_items(&app, Some(BUTTONS), "");
        assert!(buttons.iter().all(|c| c.name != c.id), "every button named");
        let page = buttons
            .iter()
            .find(|c| c.id == "zoom_page")
            .expect("listed");
        assert_eq!(page.name, tr("toolbar.zoom_to_page"));
        assert!(!command_items(&app, None, &page.name.to_lowercase()).is_empty());
        // Dragged from the list back onto the bar.
        apply_drop(
            &mut app,
            &ItemDrag {
                item: page.id.clone(),
                from: None,
            },
            Some((ItemBar::Zoom, i)),
        );
        assert_eq!(items(&app, ItemBar::Zoom), zoom);
    }

    #[test]
    fn reset_to_defaults_touches_the_category_shown_only() {
        let mut app = app_with_commands();
        set_menu_shortcut(&mut app, "menu.file.open", "Ctrl+Shift+O");
        set_menu_shortcut(&mut app, "rectangle", "Alt+R");
        reset_category_shortcuts(&mut app, TOOLBOX);
        // The tool's keys went, the menu command's stayed.
        assert_eq!(
            app.settings.shortcuts,
            vec![
                ("menu.file.open".to_string(), "Ctrl+O".to_string()),
                ("menu.file.open".to_string(), "Ctrl+Shift+O".to_string())
            ]
        );
        reset_category_shortcuts(&mut app, "menu.file");
        assert!(app.settings.shortcuts.is_empty());
    }

    #[test]
    fn customization_pages_center_dialogs_and_reset_bars() {
        use OptionsPage::*;
        assert_eq!(
            OptionsSet::Customization.pages(),
            &[Appearance, CommandBars, Commands, ColorPalette]
        );
        let mut app = App::headless();
        assert!(app.settings.center_dialogs);
        // Dialogs follow the setting given for the frame.
        let ctx = egui::Context::default();
        assert!(crate::ui::chrome::center_dialogs(&ctx));
        crate::ui::chrome::set_center_dialogs(&ctx, false);
        assert!(!crate::ui::chrome::center_dialogs(&ctx));
        // Reset brings back the bars of a new installation.
        app.show_toolbox = false;
        app.show_zoom_toolbar = true;
        app.settings.palette.show_palette = false;
        app.settings.bars.locked = true;
        app.reset_command_bars();
        assert!(app.show_toolbox && !app.show_zoom_toolbar);
        assert!(app.settings.palette.show_palette && !app.settings.bars.locked);
    }

    #[test]
    fn every_page_belongs_to_one_dialog() {
        let sets = [
            OptionsSet::App,
            OptionsSet::Customization,
            OptionsSet::Tools,
            OptionsSet::Global,
            OptionsSet::Workspaces,
            OptionsSet::Ai,
            OptionsSet::Document,
        ];
        let mut seen = Vec::new();
        for s in sets {
            for p in s.pages() {
                assert!(!seen.contains(p), "{p:?} twice");
                assert_eq!(p.set(), s);
                seen.push(*p);
            }
        }
        assert_eq!(OptionsPage::Rulers.set(), OptionsSet::Document);
        assert_eq!(OptionsPage::General.set(), OptionsSet::App);
    }

    #[test]
    fn cancel_puts_settings_and_document_back() {
        let mut app = App::headless();
        let snap = OptionsSnapshot::take(&app);
        app.settings.undo_levels = 3;
        app.show_grid = !app.show_grid;
        let mut meta = app.doc().metadata.clone();
        meta.fill_open_curves = true;
        app.run(Command::SetMetadata { metadata: meta });
        snap.restore(&mut app);
        assert_eq!(app.settings.undo_levels, 150);
        assert!(!app.doc().metadata.fill_open_curves);
    }

    /// Save as Default keeps the drawing's guidelines for new drawings,
    /// and what it saved stays when the dialog is then cancelled (#3522).
    #[test]
    fn save_as_default_keeps_guidelines_and_survives_cancel() {
        use tracedraw_core::document::Guide;
        let mut app = App::headless();
        app.options_snapshot = Some(OptionsSnapshot::take(&app));
        app.choose_master_guides(false);
        app.add_guide(Guide::vertical(3.0));
        app.add_guide(Guide::horizontal(3.0));
        app.choose_master_guides(true);
        app.add_guide(Guide::vertical(87.0));
        save_as_default(&mut app);
        // Cancel: the snapshot goes back, the saved defaults stay.
        if let Some(s) = app.options_snapshot.take() {
            s.restore(&mut app);
        }
        let d = &app.settings.document_defaults;
        assert_eq!(d.page_guidelines.len(), 2, "{d:?}");
        assert_eq!(d.master_guidelines.len(), 1);
        // A new drawing starts with them.
        app.new_document();
        assert_eq!(app.doc().pages[0].guides.len(), 2);
        assert_eq!(app.doc().master_guides.len(), 1);
        // Saved settings read back with them; older settings without them
        // read as none.
        let json = serde_json::to_string(&app.settings.document_defaults).unwrap();
        let back: crate::settings::DocumentDefaults = serde_json::from_str(&json).unwrap();
        assert_eq!(
            back.page_guidelines,
            app.settings.document_defaults.page_guidelines
        );
        let old: crate::settings::DocumentDefaults = serde_json::from_str("{}").unwrap();
        assert!(old.page_guidelines.is_empty() && old.master_guidelines.is_empty());
    }

    /// The Smart Drawing, Dimension, Connector and Mesh Fill pages edit
    /// the defaults new objects take; Cancel puts those back too.
    #[test]
    fn cancel_puts_the_new_tool_pages_back() {
        let mut app = App::headless();
        let snap = OptionsSnapshot::take(&app);
        let before = (
            app.recognize,
            app.dimension_style.clone(),
            app.connector_radius,
            app.mesh_rows,
            app.mesh_cols,
        );
        app.recognize.recognition = 5;
        app.dimension_style.precision = 4;
        app.dimension_style.suffix = " ok".into();
        app.connector_radius = 9.0;
        app.mesh_rows = 7;
        app.mesh_cols = 8;
        snap.restore(&mut app);
        assert_eq!(
            (
                app.recognize,
                app.dimension_style.clone(),
                app.connector_radius,
                app.mesh_rows,
                app.mesh_cols,
            ),
            before
        );
    }

    #[test]
    fn every_text_tab_draws() {
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        app.options_page = OptionsPage::Text;
        let before = app.settings.autocorrect.clone();
        for tab in 0..TEXT_TABS.len() {
            app.options_text_tab = tab;
            for _ in 0..2 {
                let input = egui::RawInput {
                    screen_rect: Some(egui::Rect::from_min_size(
                        egui::Pos2::ZERO,
                        egui::vec2(1600.0, 1000.0),
                    )),
                    ..Default::default()
                };
                let mut out = ctx.run_ui(input, |ui| {
                    let mut close = false;
                    options_dialog(&mut app, ui.ctx(), &mut close);
                    assert!(!close, "tab {tab} closed the dialog");
                });
                out.textures_delta.clear();
            }
        }
        assert_eq!(
            app.settings.autocorrect, before,
            "drawing changed a setting"
        );
        assert_eq!(app.settings.recent_font_count, 5);
    }

    /// Options > Text > Paragraph Text shows Default tab spacing, 12.7 mm
    /// unless set; it is saved with the other settings (older settings
    /// files without it give 12.7 mm) and given to the text engine when
    /// the settings are applied (#1852).
    #[test]
    fn the_default_tab_spacing_is_a_saved_setting() {
        let app = App::headless();
        assert_eq!(app.settings.default_tab_mm, 12.7);
        let mut s = app.settings.clone();
        s.default_tab_mm = 8.0;
        let json = serde_json::to_string(&s).expect("saved");
        let back: crate::settings::Settings = serde_json::from_str(&json).expect("read");
        assert_eq!(back.default_tab_mm, 8.0);
        let mut v: serde_json::Value = serde_json::from_str(&json).expect("json");
        v.as_object_mut().expect("object").remove("default_tab_mm");
        let old: crate::settings::Settings = serde_json::from_value(v).expect("old file");
        assert_eq!(old.default_tab_mm, 12.7);
        // Its row on the Paragraph Text tab.
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        app.options_page = OptionsPage::Text;
        app.options_text_tab = 1;
        let label = tr("options.default_tab_spacing");
        let mut seen = false;
        for _ in 0..2 {
            let input = egui::RawInput {
                screen_rect: Some(egui::Rect::from_min_size(
                    egui::Pos2::ZERO,
                    egui::vec2(1600.0, 1000.0),
                )),
                ..Default::default()
            };
            let mut out = ctx.run_ui(input, |ui| {
                let mut close = false;
                options_dialog(&mut app, ui.ctx(), &mut close);
            });
            out.textures_delta.clear();
            seen = out.shapes.iter().any(|c| {
                fn has(s: &egui::Shape, t: &str) -> bool {
                    match s {
                        egui::Shape::Text(x) => x.galley.text() == t,
                        egui::Shape::Vec(v) => v.iter().any(|s| has(s, t)),
                        _ => false,
                    }
                }
                has(&c.shape, &label)
            });
        }
        assert!(seen, "the setting's row is drawn");
        // Applied with the settings (at its default, so that tests laying
        // out text at the same time see the spacing they expect).
        app.apply_runtime_settings();
        assert_eq!(tracedraw_core::default_tab_step(), 12.7);
    }

    /// Text > Proofing > Autocorrect opens the Autocorrect tab.
    #[test]
    fn the_autocorrect_command_opens_its_tab() {
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        let mut ran = false;
        let input = egui::RawInput::default();
        let mut out = ctx.run_ui(input, |ui| {
            ran = crate::ui::menus::run_command(&mut app, ui.ctx(), "menu.text.autocorrect");
        });
        out.textures_delta.clear();
        assert!(ran);
        assert!(matches!(app.dialog, crate::ui::dialogs::Dialog::Options));
        assert_eq!(app.options_page, OptionsPage::Text);
        assert_eq!(app.options_text_tab, AUTOCORRECT_TAB);
    }

    /// Customization > Color Palette sets the default palette's layout as
    /// its own menu does: Rows on a floating palette gives its window that
    /// many lines (before, only the docked rows were set, and a floating
    /// palette stayed as it was), and Position docks or floats it (#1983).
    #[test]
    fn the_color_palette_page_sets_the_palette_layout() {
        use crate::ui::bars::{Bar, Dock};
        use crate::ui::palette::{lines_of, Row};
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        app.options_page = OptionsPage::ColorPalette;
        crate::ui::palette_bars::set_dock(&mut app, Row::Main, Dock::Floating, None);
        assert_eq!(lines_of(&app, Row::Main), 1);
        let clock = std::cell::Cell::new(0.0);
        // One frame of the dialog with `events`; each text drawn and where.
        let mut frame = |app: &mut App, events: Vec<egui::Event>| {
            clock.set(clock.get() + 0.1);
            let input = egui::RawInput {
                screen_rect: Some(egui::Rect::from_min_size(
                    egui::Pos2::ZERO,
                    egui::vec2(1600.0, 1000.0),
                )),
                events,
                time: Some(clock.get()),
                ..Default::default()
            };
            let mut out = ctx.run_ui(input, |ui| {
                let mut close = false;
                options_dialog(app, ui.ctx(), &mut close);
            });
            out.textures_delta.clear();
            fn walk(s: &egui::Shape, texts: &mut Vec<(String, egui::Rect)>) {
                match s {
                    egui::Shape::Text(t) => texts.push((
                        t.galley.text().to_string(),
                        t.galley.rect.translate(t.pos.to_vec2()),
                    )),
                    egui::Shape::Vec(v) => v.iter().for_each(|s| walk(s, texts)),
                    _ => {}
                }
            }
            let mut texts = Vec::new();
            out.shapes.iter().for_each(|c| walk(&c.shape, &mut texts));
            texts
        };
        let click = |p: egui::Pos2| {
            vec![
                egui::Event::PointerMoved(p),
                egui::Event::PointerButton {
                    pos: p,
                    button: egui::PointerButton::Primary,
                    pressed: true,
                    modifiers: egui::Modifiers::NONE,
                },
                egui::Event::PointerButton {
                    pos: p,
                    button: egui::PointerButton::Primary,
                    pressed: false,
                    modifiers: egui::Modifiers::NONE,
                },
            ]
        };
        // The value shown on the row of `label`, right of it.
        let value_of = |texts: &[(String, egui::Rect)], label: &str, value: &str| {
            let (_, l) = texts
                .iter()
                .find(|(t, _)| t == label)
                .unwrap_or_else(|| panic!("no {label} row"));
            texts
                .iter()
                .find(|(t, r)| {
                    t == value && r.left() > l.right() && (r.center().y - l.center().y).abs() < 6.0
                })
                .map(|(_, r)| r.center())
                .unwrap_or_else(|| panic!("no {value} on the {label} row"))
        };
        // A choice in the open list: the one away from the row.
        let choice = |texts: &[(String, egui::Rect)], value: &str, row: egui::Pos2| {
            texts
                .iter()
                .filter(|(t, r)| t == value && (r.center().y - row.y).abs() > 6.0)
                .map(|(_, r)| r.center())
                .next()
                .unwrap_or_else(|| panic!("no {value} in the list"))
        };
        frame(&mut app, Vec::new());
        let texts = frame(&mut app, Vec::new());
        let rows = tr("options.palette_rows");
        let at = value_of(&texts, &rows, "1");
        frame(&mut app, click(at));
        let texts = frame(&mut app, Vec::new());
        let three = choice(&texts, "3", at);
        frame(&mut app, click(three));
        frame(&mut app, Vec::new());
        assert_eq!(
            app.settings.bars.dock(Bar::Palette),
            Dock::Floating,
            "still floating"
        );
        assert_eq!(lines_of(&app, Row::Main), 3, "the floating palette's lines");
        // Position: docked at the left.
        let texts = frame(&mut app, Vec::new());
        let position = tr("options.palette_position");
        let at = value_of(&texts, &position, &tr("palette.float"));
        frame(&mut app, click(at));
        let texts = frame(&mut app, Vec::new());
        let left = choice(&texts, &tr("bars.left"), at);
        frame(&mut app, click(left));
        frame(&mut app, Vec::new());
        assert_eq!(app.settings.bars.dock(Bar::Palette), Dock::Left);
        // Locked toolbars keep it where it is.
        app.settings.bars.locked = true;
        let texts = frame(&mut app, Vec::new());
        let at = value_of(&texts, &position, &tr("bars.left"));
        frame(&mut app, click(at));
        let texts = frame(&mut app, Vec::new());
        assert!(
            !texts
                .iter()
                .any(|(t, r)| t == &tr("bars.right") && (r.center().y - at.y).abs() > 6.0),
            "no list while locked"
        );
    }

    #[test]
    fn every_page_draws() {
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        for set in [
            OptionsSet::App,
            OptionsSet::Customization,
            OptionsSet::Tools,
            OptionsSet::Global,
            OptionsSet::Workspaces,
            OptionsSet::Ai,
            OptionsSet::Document,
        ] {
            for p in set.pages() {
                app.options_page = *p;
                let input = egui::RawInput {
                    screen_rect: Some(egui::Rect::from_min_size(
                        egui::Pos2::ZERO,
                        egui::vec2(1600.0, 1000.0),
                    )),
                    ..Default::default()
                };
                let mut out = ctx.run_ui(input, |ui| {
                    let mut close = false;
                    options_dialog(&mut app, ui.ctx(), &mut close);
                    assert!(!close, "{p:?} closed by itself");
                });
                out.textures_delta.clear();
            }
        }
        // Drawing a page never changes what it shows (fields clamp the
        // values they hold to their ranges).
        assert_eq!(app.star_sharpness, 0.5);
    }

    /// #2199: the window stays where it is from one page to the next
    /// and from frame to frame (its first frame aside, which sizes it),
    /// on a large screen and on one smaller than the dialog; and no page
    /// is wider than its panel (the Edit page's slider row was, by 32
    /// points, which made the window wider while it showed).
    #[test]
    fn the_window_keeps_its_place_from_page_to_page() {
        for screen in [egui::vec2(1600.0, 1000.0), egui::vec2(1280.0, 680.0)] {
            let ctx = crate::theme::ui_context();
            let mut app = App::headless();
            let mut first: Option<(OptionsPage, egui::Rect)> = None;
            let mut frames = 0;
            let mut wide: Vec<String> = Vec::new();
            for set in OptionsSet::ALL {
                for p in set.pages() {
                    app.options_page = *p;
                    for _ in 0..3 {
                        let input = egui::RawInput {
                            screen_rect: Some(egui::Rect::from_min_size(egui::Pos2::ZERO, screen)),
                            ..Default::default()
                        };
                        let mut out = ctx.run_ui(input, |ui| {
                            let mut close = false;
                            options_dialog(&mut app, ui.ctx(), &mut close);
                        });
                        out.textures_delta.clear();
                        frames += 1;
                        if frames == 1 {
                            continue;
                        }
                        let rect = ctx
                            .memory(|m| m.area_rect(egui::Id::new("options_dialog")))
                            .expect("the dialog is drawn");
                        let (at, was) = *first.get_or_insert((*p, rect));
                        assert!(
                            (rect.min - was.min).length() < 0.01
                                && (rect.max - was.max).length() < 0.01,
                            "{p:?} at {rect:?}, {at:?} at {was:?} (screen {screen:?})"
                        );
                        let over: f32 = ctx
                            .data(|d| d.get_temp(page_overflow_id()))
                            .expect("a page is drawn");
                        if over >= 0.5 && !wide.contains(&format!("{p:?} by {over}")) {
                            wide.push(format!("{p:?} by {over}"));
                        }
                    }
                }
            }
            assert!(wide.is_empty(), "wider than the panel: {wide:?}");
        }
    }

    /// A frame of the whole window with `events` as its input.
    fn frame(ctx: &Context, app: &mut App, events: Vec<egui::Event>) {
        let input = egui::RawInput {
            screen_rect: Some(egui::Rect::from_min_size(
                egui::Pos2::ZERO,
                egui::vec2(1600.0, 1000.0),
            )),
            events,
            ..Default::default()
        };
        let mut out = ctx.run_ui(input, |ui| crate::ui::root(app, ui));
        out.textures_delta.clear();
    }

    fn key(key: egui::Key, modifiers: egui::Modifiers) -> egui::Event {
        egui::Event::Key {
            key,
            physical_key: None,
            pressed: true,
            repeat: false,
            modifiers,
        }
    }

    #[test]
    fn commands_take_the_keys_pressed_as_their_shortcut() {
        use crate::ui::dialogs::Dialog;
        use egui::{Key, Modifiers};
        let ctx = crate::theme::ui_context();
        let mut app = App::headless();
        app.show_welcome = false;
        app.dialog = Dialog::Options;
        app.options_page = OptionsPage::Commands;
        frame(&ctx, &mut app, vec![]);
        assert!(app
            .shortcut_editor
            .entries
            .iter()
            .any(|e| e.key == "menu.file.export"));
        // Export waits for its keys; Ctrl+D, Duplicate's, is pressed.
        app.shortcut_editor.capture = Some("menu.file.export".into());
        frame(
            &ctx,
            &mut app,
            vec![key(Key::ControlLeft, Modifiers::COMMAND)],
        );
        assert!(app.shortcut_editor.capture.is_some(), "Ctrl alone waits");
        frame(&ctx, &mut app, vec![key(Key::D, Modifiers::COMMAND)]);
        // The new key joins the built-in one: a command may have several
        // (#822).
        let export_keys = |app: &App| {
            crate::shortcuts::keys_for(&app.settings.shortcuts, "menu.file.export", None)
        };
        assert_eq!(export_keys(&app), ["Ctrl+E", "Ctrl+D"]);
        assert!(app.shortcut_editor.capture.is_none());
        let note = app.shortcut_editor.note.clone().unwrap_or_default();
        assert!(note.contains(&tr("menu.edit.duplicate")), "{note}");
        // Keys that edit text or close dialogs are not shortcuts alone.
        app.shortcut_editor.capture = Some("menu.file.import".into());
        frame(&ctx, &mut app, vec![key(Key::Enter, Modifiers::NONE)]);
        assert!(user_shortcut(&app, "menu.file.import").is_none());
        // Esc stops waiting and leaves the options open.
        frame(&ctx, &mut app, vec![key(Key::Escape, Modifiers::NONE)]);
        assert!(app.shortcut_editor.capture.is_none());
        assert!(matches!(app.dialog, Dialog::Options));
        // Keys of the user's move to the command given them last.
        set_menu_shortcut(&mut app, "menu.file.import", "ctrl+d");
        assert_eq!(export_keys(&app), ["Ctrl+E"]);
        assert!(app
            .shortcut_editor
            .note
            .as_deref()
            .is_some_and(|n| n.contains(&tr("menu.file.export").replace("...", ""))));
        // Another page, or no options, and nothing waits any more.
        app.shortcut_editor.capture = Some("menu.file.export".into());
        app.options_page = OptionsPage::General;
        frame(&ctx, &mut app, vec![]);
        assert!(app.shortcut_editor.capture.is_none());
        app.options_page = OptionsPage::Commands;
        app.shortcut_editor.capture = Some("menu.file.export".into());
        app.dialog = Dialog::None;
        frame(&ctx, &mut app, vec![key(Key::F7, Modifiers::COMMAND)]);
        assert!(app.shortcut_editor.capture.is_none());
        assert_eq!(export_keys(&app), ["Ctrl+E"]);
    }

    /// A tool takes a second key without losing its first; either picks
    /// it, and each is deleted on its own (#822).
    #[test]
    fn a_tool_keeps_several_shortcuts() {
        let mut app = app_with_commands();
        let rect = command_items(&app, Some(TOOLBOX), "")
            .into_iter()
            .find(|c| c.id == "rectangle")
            .expect("rectangle tool");
        let built_in = rect.built_in.clone();
        assert!(!built_in.is_empty());
        set_menu_shortcut(&mut app, "rectangle", "Alt+R");
        set_menu_shortcut(&mut app, "rectangle", "Alt+Shift+R");
        assert_eq!(
            current_keys(&app, &rect),
            [built_in.clone(), "Alt+R".into(), "Alt+Shift+R".into()]
        );
        remove_key(&mut app, &rect, "Alt+R");
        assert_eq!(
            current_keys(&app, &rect),
            [built_in.clone(), "Alt+Shift+R".into()]
        );
        remove_key(&mut app, &rect, &built_in);
        assert_eq!(current_keys(&app, &rect), ["Alt+Shift+R".to_string()]);
        remove_key(&mut app, &rect, "Alt+Shift+R");
        assert!(
            current_keys(&app, &rect).is_empty(),
            "the built-in stays deleted"
        );
    }
}
