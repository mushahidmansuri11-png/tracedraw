//! Rulers, grids and guidelines: the Rulers, Grid and Guidelines pages of
//! Document Setup and the Guidelines docker. Every document change goes
//! through a command (SetMetadata for the settings, the guideline commands
//! for guidelines).

use crate::app::{App, Units};
use crate::guides::GuidePreset;
use crate::i18n::tr;
use crate::theme::Tokens;
use crate::ui::tips::RichTip;
use egui::Ui;
use tracedraw_core::{
    document::{GridDisplay, Guide, GuideLine, GuideStyle, Metadata},
    geometry::Point,
    Color, Command,
};

/// What the Guidelines docker's form edits.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum GuideKind {
    #[default]
    Horizontal,
    Vertical,
    Angled,
}

impl GuideKind {
    pub const ALL: [GuideKind; 3] = [
        GuideKind::Horizontal,
        GuideKind::Vertical,
        GuideKind::Angled,
    ];

    pub fn key(self) -> &'static str {
        match self {
            GuideKind::Horizontal => "options.horizontal",
            GuideKind::Vertical => "options.vertical",
            GuideKind::Angled => "options.angled",
        }
    }

    pub fn of(line: &GuideLine) -> GuideKind {
        match line {
            GuideLine::Horizontal { .. } => GuideKind::Horizontal,
            GuideLine::Vertical { .. } => GuideKind::Vertical,
            GuideLine::Angled { .. } => GuideKind::Angled,
        }
    }
}

/// The Guidelines docker's entry fields, counted from the ruler origin
/// (mm) and in degrees.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct GuideForm {
    pub kind: GuideKind,
    pub x: f64,
    pub y: f64,
    pub angle: f64,
}

impl GuideForm {
    /// The guideline the form describes, in page coordinates.
    pub fn line(&self, app: &App) -> GuideLine {
        let p = app.from_ruler(Point::new(self.x, self.y));
        match self.kind {
            GuideKind::Horizontal => GuideLine::Horizontal { y: p.y },
            GuideKind::Vertical => GuideLine::Vertical { x: p.x },
            GuideKind::Angled => GuideLine::Angled {
                x: p.x,
                y: p.y,
                angle: self.angle,
            },
        }
    }

    /// Fill the form from a guideline.
    pub fn load(&mut self, app: &App, line: &GuideLine) {
        self.kind = GuideKind::of(line);
        let (o, _) = line.point_and_direction();
        let r = app.to_ruler(o);
        match line {
            GuideLine::Horizontal { .. } => self.y = r.y,
            GuideLine::Vertical { .. } => self.x = r.x,
            GuideLine::Angled { angle, .. } => {
                self.x = r.x;
                self.y = r.y;
                self.angle = *angle;
            }
        }
    }
}

/// The presets of Document Setup > Guidelines > Presets.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NamedPreset {
    OneInchMargins,
    BleedArea,
    PageBorders,
    PrintableArea,
    ThreeColumnNewsletter,
    BasicGrid,
    UpperLeftGrid,
    /// The mathematical layout grids (`layout_grids` below).
    RuleOfThirds,
    GoldenRatio,
    GoldenSubdivision,
    CentreDiagonals,
    VanDeGraaf,
    Isometric,
}

impl NamedPreset {
    pub const ALL: [NamedPreset; 13] = [
        NamedPreset::OneInchMargins,
        NamedPreset::BleedArea,
        NamedPreset::PageBorders,
        NamedPreset::PrintableArea,
        NamedPreset::ThreeColumnNewsletter,
        NamedPreset::BasicGrid,
        NamedPreset::UpperLeftGrid,
        NamedPreset::RuleOfThirds,
        NamedPreset::GoldenRatio,
        NamedPreset::GoldenSubdivision,
        NamedPreset::CentreDiagonals,
        NamedPreset::VanDeGraaf,
        NamedPreset::Isometric,
    ];

    fn key(self) -> &'static str {
        match self {
            NamedPreset::OneInchMargins => "guides.preset_one_inch_margins",
            NamedPreset::BleedArea => "guides.preset_bleed_area",
            NamedPreset::PageBorders => "guides.preset_page_borders",
            NamedPreset::PrintableArea => "guides.preset_printable_area",
            NamedPreset::ThreeColumnNewsletter => "guides.preset_three_columns",
            NamedPreset::BasicGrid => "guides.preset_basic_grid",
            NamedPreset::UpperLeftGrid => "guides.preset_upper_left_grid",
            NamedPreset::RuleOfThirds => "guides.preset_rule_of_thirds",
            NamedPreset::GoldenRatio => "guides.preset_golden_ratio",
            NamedPreset::GoldenSubdivision => "guides.preset_golden_subdivision",
            NamedPreset::CentreDiagonals => "guides.preset_centre_diagonals",
            NamedPreset::VanDeGraaf => "guides.preset_van_de_graaf",
            NamedPreset::Isometric => "guides.preset_isometric",
        }
    }

    /// The guideline sets this preset adds, for a page of `size` with
    /// `bleed` around it (mm).
    pub fn presets(self, size: tracedraw_core::geometry::Size, bleed: f64) -> Vec<GuidePreset> {
        let inch = 25.4;
        match self {
            NamedPreset::OneInchMargins => vec![GuidePreset::Margins {
                top: inch,
                bottom: inch,
                left: inch,
                right: inch,
            }],
            NamedPreset::BleedArea => vec![GuidePreset::Margins {
                top: -bleed,
                bottom: -bleed,
                left: -bleed,
                right: -bleed,
            }],
            NamedPreset::PageBorders => vec![GuidePreset::Margins {
                top: 0.0,
                bottom: 0.0,
                left: 0.0,
                right: 0.0,
            }],
            NamedPreset::PrintableArea => vec![GuidePreset::Margins {
                top: 5.0,
                bottom: 5.0,
                left: 5.0,
                right: 5.0,
            }],
            NamedPreset::ThreeColumnNewsletter => vec![
                GuidePreset::Margins {
                    top: inch,
                    bottom: inch,
                    left: inch,
                    right: inch,
                },
                GuidePreset::Columns {
                    count: 3,
                    gutter: inch / 4.0,
                },
            ],
            NamedPreset::BasicGrid => vec![GuidePreset::Grid {
                rows: (size.height / inch).floor().max(1.0) as u32,
                columns: (size.width / inch).floor().max(1.0) as u32,
            }],
            NamedPreset::UpperLeftGrid => vec![GuidePreset::Grid {
                rows: 4,
                columns: 4,
            }],
            // The mathematical grids are drawn by `layout_grids`.
            NamedPreset::RuleOfThirds
            | NamedPreset::GoldenRatio
            | NamedPreset::GoldenSubdivision
            | NamedPreset::CentreDiagonals
            | NamedPreset::VanDeGraaf
            | NamedPreset::Isometric => Vec::new(),
        }
    }
}

/// One over the golden ratio, 0.618...
const INV_PHI: f64 = 0.618_033_988_749_894_9;

/// Vertical and horizontal guidelines at these fractions of the page.
fn at_fractions(size: tracedraw_core::geometry::Size, fractions: &[f64]) -> Vec<GuideLine> {
    let mut out = Vec::new();
    for f in fractions {
        out.push(GuideLine::Vertical { x: size.width * f });
        out.push(GuideLine::Horizontal { y: size.height * f });
    }
    out
}

/// The two diagonals of a page, as angled guidelines.
fn page_diagonals(size: tracedraw_core::geometry::Size) -> Vec<GuideLine> {
    let a = size.height.atan2(size.width).to_degrees();
    vec![
        GuideLine::Angled {
            x: 0.0,
            y: 0.0,
            angle: a,
        },
        GuideLine::Angled {
            x: 0.0,
            y: size.height,
            angle: -a,
        },
    ]
}

/// The page cut again and again by the golden ratio: each step cuts off,
/// from the longer side of what is left, the part 0.618 of it long, from
/// the left, the top, the right and the bottom in turn, as a golden spiral
/// is drawn; seven cuts, none under 5 mm.
fn golden_subdivision(size: tracedraw_core::geometry::Size) -> Vec<GuideLine> {
    let (mut x0, mut y0, mut w, mut h) = (0.0, 0.0, size.width, size.height);
    let mut out = Vec::new();
    for step in 0..7 {
        let long_side = if w >= h { w } else { h };
        let cut = long_side * INV_PHI;
        if w.min(h) < 5.0 || long_side - cut < 5.0 {
            break;
        }
        if w >= h {
            // Cut the width: from the left on even turns, else the right.
            if step % 4 == 0 {
                x0 += cut;
                out.push(GuideLine::Vertical { x: x0 });
            } else {
                out.push(GuideLine::Vertical { x: x0 + w - cut });
            }
            w -= cut;
        } else {
            // Cut the height: from the top on odd turns, else the bottom.
            if step % 4 == 1 {
                out.push(GuideLine::Horizontal { y: y0 + h - cut });
            } else {
                y0 += cut;
                out.push(GuideLine::Horizontal { y: y0 });
            }
            h -= cut;
        }
    }
    out
}

/// Isometric guidelines: verticals and lines at 30 and 150 degrees, `step`
/// apart (measured square to the lines), across the page.
fn isometric(size: tracedraw_core::geometry::Size, step: f64) -> Vec<GuideLine> {
    let tan = 30f64.to_radians().tan();
    let along = step / 30f64.to_radians().cos();
    let mut out = Vec::new();
    let mut x = 0.0;
    while x <= size.width + 1e-9 && out.len() < 200 {
        out.push(GuideLine::Vertical { x });
        x += step;
    }
    // Lines at 30 degrees through (0, c): they cross the page when c is
    // in [-w tan, h]; at 150 degrees when c is in [0, h + w tan].
    let mut c = -size.width * tan;
    while c <= size.height + 1e-9 && out.len() < 200 {
        out.push(GuideLine::Angled {
            x: 0.0,
            y: c,
            angle: 30.0,
        });
        c += along;
    }
    let mut c = 0.0;
    while c <= size.height + size.width * tan + 1e-9 && out.len() < 200 {
        out.push(GuideLine::Angled {
            x: 0.0,
            y: c,
            angle: 150.0,
        });
        c += along;
    }
    out
}

/// The guidelines of the mathematical layout grids for a page of `size`:
/// the rule of thirds, the golden ratio (0.382 and 0.618 of each side),
/// the golden subdivision, the centre lines with the page's diagonals,
/// the Van de Graaf canon (margins of 1/9 of the width and the height on
/// the inner and top sides and 2/9 on the outer and bottom, with the
/// page's diagonals) and an isometric grid 20 mm apart.
pub fn layout_grids(preset: NamedPreset, size: tracedraw_core::geometry::Size) -> Vec<GuideLine> {
    match preset {
        NamedPreset::RuleOfThirds => at_fractions(size, &[1.0 / 3.0, 2.0 / 3.0]),
        NamedPreset::GoldenRatio => at_fractions(size, &[1.0 - INV_PHI, INV_PHI]),
        NamedPreset::GoldenSubdivision => golden_subdivision(size),
        NamedPreset::CentreDiagonals => {
            let mut out = at_fractions(size, &[0.5]);
            out.extend(page_diagonals(size));
            out
        }
        NamedPreset::VanDeGraaf => {
            let (w, h) = (size.width, size.height);
            let mut out = vec![
                GuideLine::Vertical { x: w / 9.0 },
                GuideLine::Vertical { x: w - 2.0 * w / 9.0 },
                GuideLine::Horizontal { y: h - h / 9.0 },
                GuideLine::Horizontal { y: 2.0 * h / 9.0 },
            ];
            out.extend(page_diagonals(size));
            out
        }
        NamedPreset::Isometric => isometric(size, 20.0),
        _ => Vec::new(),
    }
}

/// Lines of a named preset for a page; columns are inset by the margins
/// of the newsletter preset, the upper-left grid covers the page's
/// upper-left quarter.
pub fn preset_lines(
    preset: NamedPreset,
    size: tracedraw_core::geometry::Size,
    bleed: f64,
) -> Vec<GuideLine> {
    let inch = 25.4;
    match preset {
        NamedPreset::ThreeColumnNewsletter => {
            let mut out = GuidePreset::Margins {
                top: inch,
                bottom: inch,
                left: inch,
                right: inch,
            }
            .lines(size);
            let inner = tracedraw_core::geometry::Size::new(
                (size.width - 2.0 * inch).max(0.0),
                size.height,
            );
            for l in (GuidePreset::Columns {
                count: 3,
                gutter: inch / 4.0,
            })
            .lines(inner)
            {
                if let GuideLine::Vertical { x } = l {
                    out.push(GuideLine::Vertical { x: x + inch });
                }
            }
            out
        }
        NamedPreset::UpperLeftGrid => {
            let quarter = tracedraw_core::geometry::Size::new(size.width / 2.0, size.height / 2.0);
            GuidePreset::Grid {
                rows: 4,
                columns: 4,
            }
            .lines(quarter)
            .into_iter()
            .map(|l| match l {
                GuideLine::Horizontal { y } => GuideLine::Horizontal {
                    y: y + size.height / 2.0,
                },
                other => other,
            })
            .collect()
        }
        NamedPreset::RuleOfThirds
        | NamedPreset::GoldenRatio
        | NamedPreset::GoldenSubdivision
        | NamedPreset::CentreDiagonals
        | NamedPreset::VanDeGraaf
        | NamedPreset::Isometric => layout_grids(preset, size),
        other => other
            .presets(size, bleed)
            .into_iter()
            .flat_map(|p| p.lines(size))
            .collect(),
    }
}

/// State of the Guidelines page's preset section.
#[derive(Debug, Clone, PartialEq)]
pub struct PresetForm {
    pub user_defined: bool,
    pub named: Vec<NamedPreset>,
    pub margins: bool,
    pub margin_top: f64,
    pub margin_bottom: f64,
    pub margin_left: f64,
    pub margin_right: f64,
    pub columns: bool,
    pub column_count: u32,
    pub column_gutter: f64,
    pub grid: bool,
    pub grid_rows: u32,
    pub grid_columns: u32,
}

impl Default for PresetForm {
    fn default() -> Self {
        PresetForm {
            user_defined: false,
            named: Vec::new(),
            margins: true,
            margin_top: 12.7,
            margin_bottom: 12.7,
            margin_left: 12.7,
            margin_right: 12.7,
            columns: false,
            column_count: 2,
            column_gutter: 6.35,
            grid: false,
            grid_rows: 4,
            grid_columns: 4,
        }
    }
}

fn set_metadata(app: &mut App, metadata: Metadata) {
    if metadata != app.doc().metadata {
        app.run(Command::SetMetadata { metadata });
    }
}

/// A row label right-aligned in the first grid column.
fn row_label(ui: &mut Ui, key: &str) {
    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
        ui.label(tr(key));
    });
}

/// A distance field in the ruler unit through the drawing scale (a
/// position, an offset, a spacing); returns the new value in mm when it
/// changed.
fn distance_field(ui: &mut Ui, tip: &str, units: Units, mm: f64, speed: f64) -> Option<f64> {
    unit_field(ui, tip, units, units.world_mm(), mm, speed, false)
}

/// A distance field that takes the focus when `focus` is set, its value
/// selected (the Guidelines panel, #2883).
fn distance_field_focused(
    ui: &mut Ui,
    tip: &str,
    units: Units,
    mm: f64,
    speed: f64,
    focus: bool,
) -> Option<f64> {
    unit_field(ui, tip, units, units.world_mm(), mm, speed, focus)
}

/// A distance field in the ruler unit as printed (page margins, columns,
/// the baseline grid), not through the drawing scale.
fn paper_field(ui: &mut Ui, tip: &str, units: Units, mm: f64, speed: f64) -> Option<f64> {
    unit_field(ui, tip, units, units.mm(), mm, speed, false)
}

fn unit_field(
    ui: &mut Ui,
    tip: &str,
    units: Units,
    unit_mm: f64,
    mm: f64,
    speed: f64,
    focus: bool,
) -> Option<f64> {
    let unit_mm = if unit_mm.is_finite() && unit_mm > 0.0 {
        unit_mm
    } else {
        1.0
    };
    let mut v = mm / unit_mm;
    let r = ui
        .add_sized(
            [110.0, 20.0],
            crate::ui::field::NumField::new(&mut v)
                .speed(speed)
                .max_decimals(4)
                .suffix(format!(" {}", units.short()))
                .focus(focus),
        )
        .rich_tip(crate::ui::tips::pair(tip, &format!("{tip}_tip")));
    r.changed().then_some(v * unit_mm)
}

fn units_combo(ui: &mut Ui, id: &str, units: &mut Units) -> bool {
    let mut changed = false;
    crate::ui::keynav::ComboBox::from_id_salt(id)
        .selected_text(units.label())
        .width(160.0)
        .show_ui(ui, |ui| {
            for u in Units::ALL {
                if ui.selectable_label(*units == u, u.label()).clicked() {
                    *units = u;
                    changed = true;
                }
            }
        });
    changed
}

/// A colour button; returns the new colour when it changed.
fn color_button(ui: &mut Ui, tip: &str, c: Color) -> Option<Color> {
    let [r, g, b] = c.to_rgb8();
    let mut rgb = [r, g, b];
    ui.color_edit_button_srgb(&mut rgb)
        .rich_tip(crate::ui::tips::pair(tip, &format!("{tip}_tip")))
        .changed()
        .then(|| Color::rgb8(rgb[0], rgb[1], rgb[2]))
}

fn section(ui: &mut Ui, key: &str) {
    ui.add_space(6.0);
    ui.label(tr(key));
    ui.separator();
}

/// Document Setup > Rulers.
pub fn rulers_page(app: &mut App, ui: &mut Ui) {
    let mut meta = app.doc().metadata.clone();
    let units = app.units;
    section(ui, "options.units_section");
    egui::Grid::new("rulers_units")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.units");
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.units", "options.units_tip"),
                |ui| {
                    let mut u = app.units;
                    if units_combo(ui, "ruler_units", &mut u) {
                        app.units = u;
                    };
                },
            );

            ui.end_row();
        });
    section(ui, "options.drawing_scale");
    drawing_scale_fields(app, ui, &mut meta);
    section(ui, "options.origin");
    egui::Grid::new("rulers_origin")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.horizontal_origin");
            if let Some(v) = distance_field(
                ui,
                "options.horizontal_origin",
                units,
                meta.rulers.origin_x,
                0.1,
            ) {
                meta.rulers.origin_x = v;
            }
            ui.end_row();
            row_label(ui, "options.vertical_origin");
            if let Some(v) = distance_field(
                ui,
                "options.vertical_origin",
                units,
                meta.rulers.origin_y,
                0.1,
            ) {
                meta.rulers.origin_y = v;
            }
            ui.end_row();
        });
    section(ui, "options.tick_divisions");
    ui.horizontal(|ui| {
        ui.add_space(16.0);
        let mut n = meta.rulers.tick_divisions;
        if ui
            .add_sized(
                [70.0, 20.0],
                crate::ui::field::NumField::new(&mut n).range(1..=100),
            )
            .rich_tip(crate::ui::tips::pair(
                "options.tick_divisions",
                "options.tick_divisions_tip",
            ))
            .changed()
        {
            meta.rulers.tick_divisions = n;
        }
        ui.label(tr("options.per_tick"));
    });
    section(ui, "options.nudge_section");
    egui::Grid::new("rulers_nudge")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.nudge_label");
            if let Some(v) = distance_field(ui, "options.nudge_label", units, app.nudge_mm, 0.01) {
                if v > 0.0 {
                    app.nudge_mm = v;
                }
            }
            ui.end_row();
            row_label(ui, "options.super_nudge");
            if let Some(v) = distance_field(
                ui,
                "options.super_nudge",
                units,
                app.settings.super_nudge_mm,
                0.01,
            ) {
                if v > 0.0 {
                    app.settings.super_nudge_mm = v;
                }
            }
            ui.end_row();
            row_label(ui, "options.micro_nudge");
            if let Some(v) = distance_field(
                ui,
                "options.micro_nudge",
                units,
                app.settings.micro_nudge_mm,
                0.001,
            ) {
                if v > 0.0 {
                    app.settings.micro_nudge_mm = v;
                }
            }
            ui.end_row();
        });
    ui.add_space(8.0);
    ui.checkbox(&mut app.show_rulers, tr("options.show_rulers"))
        .rich_tip(crate::ui::tips::pair(
            "options.show_rulers",
            "options.show_rulers_tip",
        ));
    if ui
        .button(tr("options.reset_origin"))
        .rich_tip(crate::ui::tips::pair(
            "options.reset_origin",
            "options.reset_origin_tip",
        ))
        .clicked()
    {
        meta.rulers.origin_x = 0.0;
        meta.rulers.origin_y = 0.0;
    }
    set_metadata(app, meta);
}

/// Document Setup > Rulers > Drawing scale: the typical scales, then the
/// page distance and the world distance it stands for, each with its unit.
/// The world unit becomes the ruler unit.
fn drawing_scale_fields(app: &mut App, ui: &mut Ui, meta: &mut Metadata) {
    use crate::drawing_scale as ds;
    let r = &mut meta.rulers;
    let current = ds::matching_preset(r);
    let (page_unit, world_unit) = ds::units_of(r);
    let mut new_units = None;
    egui::Grid::new("drawing_scale")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.typical_scales");
            let shown = current
                .map(|p| p.label.to_string())
                .unwrap_or_else(|| tr("options.scale_custom"));
            let mut pick = None;
            crate::ui::keynav::ComboBox::from_id_salt("typical_scales")
                .selected_text(shown)
                .width(160.0)
                .height(320.0)
                .show_ui(ui, |ui| {
                    for p in ds::PRESETS.iter() {
                        let on = current.is_some_and(|c| c.label == p.label);
                        if ui.selectable_label(on, p.label).clicked() {
                            pick = Some(*p);
                        }
                    }
                })
                .response
                .rich_tip(crate::ui::tips::pair(
                    "options.typical_scales",
                    "options.typical_scales_tip",
                ));
            if let Some(p) = pick {
                new_units = ds::apply_preset(r, &p);
            }
            ui.end_row();
            row_label(ui, "options.page_distance");
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.page_distance", "options.page_distance_tip"),
                |ui| {
                    ui.horizontal(|ui| {
                        let world = world_unit.from_mm(r.scale_world);
                        let mut v = page_unit.from_mm(r.scale_page);
                        if ui
                            .add_sized(
                                [90.0, 20.0],
                                crate::ui::field::NumField::new(&mut v)
                                    .speed(0.1)
                                    .max_decimals(4)
                                    .range(0.0001..=1_000_000.0),
                            )
                            .changed()
                        {
                            ds::set(r, v, page_unit, world, world_unit);
                        }
                        let mut u = page_unit;
                        if units_combo(ui, "scale_page_unit", &mut u) {
                            ds::set(r, u.from_mm(r.scale_page), u, world, world_unit);
                        }
                    });
                },
            );

            ui.end_row();
            row_label(ui, "options.world_distance");
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.world_distance", "options.world_distance_tip"),
                |ui| {
                    ui.horizontal(|ui| {
                        let page = page_unit.from_mm(r.scale_page);
                        let mut v = world_unit.from_mm(r.scale_world);
                        if ui
                            .add_sized(
                                [90.0, 20.0],
                                crate::ui::field::NumField::new(&mut v)
                                    .speed(0.1)
                                    .max_decimals(4)
                                    .range(0.0001..=1_000_000_000.0),
                            )
                            .changed()
                        {
                            ds::set(r, page, page_unit, v, world_unit);
                        }
                        let mut u = world_unit;
                        if units_combo(ui, "scale_world_unit", &mut u) {
                            ds::set(r, page, page_unit, u.from_mm(r.scale_world), u);
                            new_units = Some(u);
                        }
                    });
                },
            );

            ui.end_row();
        });
    ui.label(
        egui::RichText::new(tr("options.scale_note"))
            .color(crate::theme::Tokens::text_dim())
            .size(11.0),
    );
    if let Some(u) = new_units {
        app.units = u;
    }
}

/// Document Setup > Grid.
pub fn grid_page(app: &mut App, ui: &mut Ui) {
    let mut meta = app.doc().metadata.clone();
    let units = app.units;
    section(ui, "options.document_grid");
    ui.horizontal(|ui| {
        ui.checkbox(&mut app.show_grid, tr("options.show_grid"))
            .rich_tip(crate::ui::tips::pair(
                "options.show_grid",
                "options.show_grid_tip",
            ));
        ui.add_space(24.0);
        ui.checkbox(&mut app.snap.grid, tr("options.snap_to_grid"))
            .rich_tip(crate::ui::tips::pair(
                "options.snap_to_grid",
                "options.snap_to_grid_tip",
            ));
    });
    egui::Grid::new("grid_spacing")
        .num_columns(3)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            for (key, value, salt, tip) in [
                (
                    "options.horizontal",
                    &mut meta.grid.spacing_x,
                    "gx",
                    "options.grid_horizontal",
                ),
                (
                    "options.vertical",
                    &mut meta.grid.spacing_y,
                    "gy",
                    "options.grid_vertical",
                ),
            ] {
                row_label(ui, key);
                if app.grid_frequency {
                    // Lines per unit.
                    let mut f = units.world_mm() / value.max(1e-9);
                    if ui
                        .add_sized(
                            [110.0, 20.0],
                            crate::ui::field::NumField::new(&mut f)
                                .speed(0.05)
                                .max_decimals(4)
                                .range(0.0001..=10_000.0),
                        )
                        .rich_tip(crate::ui::tips::pair(tip, &format!("{tip}_tip")))
                        .changed()
                        && f > 0.0
                    {
                        *value = units.world_mm() / f;
                    }
                } else if let Some(v) = distance_field(ui, tip, units, *value, 0.1) {
                    if v > 0.0 {
                        *value = v;
                    }
                }
                let spacing = crate::i18n::trf("options.grid_spacing_of", &[("u", &units.label())]);
                let frequency =
                    crate::i18n::trf("options.grid_frequency_of", &[("u", &units.label())]);
                crate::ui::keynav::ComboBox::from_id_salt(salt)
                    .selected_text(if app.grid_frequency {
                        frequency.clone()
                    } else {
                        spacing.clone()
                    })
                    .width(170.0)
                    .show_ui(ui, |ui| {
                        ui.selectable_value(&mut app.grid_frequency, false, spacing);
                        ui.selectable_value(&mut app.grid_frequency, true, frequency);
                    })
                    .response
                    .rich_tip(crate::ui::tips::pair(
                        "options.grid_measure",
                        "options.grid_measure_tip",
                    ));
                ui.end_row();
            }
            row_label(ui, "options.show_grid_as");
            ui.horizontal(|ui| {
                ui.radio_value(
                    &mut meta.grid.display,
                    GridDisplay::Lines,
                    tr("options.grid_lines"),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.grid_lines",
                    "options.grid_lines_tip",
                ));
                ui.radio_value(
                    &mut meta.grid.display,
                    GridDisplay::Dots,
                    tr("options.grid_dots"),
                )
                .rich_tip(crate::ui::tips::pair(
                    "options.grid_dots",
                    "options.grid_dots_tip",
                ));
            });
            ui.end_row();
        });

    section(ui, "options.baseline_grid");
    ui.horizontal(|ui| {
        ui.checkbox(&mut app.show_baseline_grid, tr("options.show_grid"))
            .rich_tip(crate::ui::tips::pair(
                "options.show_grid",
                "options.show_grid_tip",
            ));
        ui.add_space(24.0);
        ui.checkbox(&mut app.snap.baseline_grid, tr("options.snap_to_grid"))
            .rich_tip(crate::ui::tips::pair(
                "options.snap_to_grid",
                "options.snap_to_grid_tip",
            ));
    });
    egui::Grid::new("baseline_grid")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.baseline_spacing");
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.baseline_spacing", "options.baseline_spacing_tip"),
                |ui| {
                    // Spacing in points, as text leading is.
                    let mut pt = meta.grid.baseline_spacing * 72.0 / 25.4;
                    if ui
                        .add_sized(
                            [110.0, 20.0],
                            crate::ui::field::NumField::new(&mut pt)
                                .speed(0.1)
                                .max_decimals(2)
                                .range(0.1..=1000.0)
                                .suffix(" pt"),
                        )
                        .changed()
                    {
                        meta.grid.baseline_spacing = pt * 25.4 / 72.0;
                    };
                },
            );

            ui.end_row();
            row_label(ui, "options.baseline_start");
            if let Some(v) = paper_field(
                ui,
                "options.baseline_start",
                units,
                meta.grid.baseline_start,
                0.1,
            ) {
                meta.grid.baseline_start = v.max(0.0);
            }
            ui.end_row();
            row_label(ui, "options.line_color");
            if let Some(c) = color_button(ui, "options.line_color", meta.grid.baseline_color) {
                meta.grid.baseline_color = c;
            }
            ui.end_row();
        });

    section(ui, "options.pixel_grid");
    ui.spacing_mut().slider_width = 150.0;
    egui::Grid::new("pixel_grid")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.color");
            if let Some(c) = color_button(ui, "options.color", meta.grid.pixel_color) {
                meta.grid.pixel_color = c;
            }
            ui.end_row();
            row_label(ui, "options.opacity");
            crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("options.opacity", "options.opacity_tip"),
                |ui| {
                    let mut o = meta.grid.pixel_opacity * 100.0;
                    if ui
                        .add(crate::ui::Slider::new(&mut o, 0.0..=100.0).suffix(" %"))
                        .changed()
                    {
                        meta.grid.pixel_opacity = (o / 100.0).clamp(0.0, 1.0);
                    };
                },
            );

            ui.end_row();
        });
    ui.checkbox(&mut app.show_pixel_grid, tr("options.pixel_grid_800"))
        .rich_tip(crate::ui::tips::pair(
            "options.pixel_grid_800",
            "options.pixel_grid_800_tip",
        ));
    ui.checkbox(&mut app.snap.pixels, tr("options.snap_to_pixels"))
        .rich_tip(crate::ui::tips::pair(
            "options.snap_to_pixels",
            "options.snap_to_pixels_tip",
        ));
    set_metadata(app, meta);
}

/// Document Setup > Guidelines: visibility, snapping, default colours,
/// presets, and every guideline of the page.
pub fn guidelines_page(app: &mut App, ui: &mut Ui) {
    let mut meta = app.doc().metadata.clone();
    ui.horizontal(|ui| {
        ui.checkbox(&mut app.show_guides, tr("options.show_guidelines"))
            .rich_tip(crate::ui::tips::pair(
                "options.show_guidelines",
                "options.show_guidelines_tip",
            ));
        ui.add_space(24.0);
        ui.checkbox(&mut app.snap.guides, tr("options.snap_to_guidelines"))
            .rich_tip(crate::ui::tips::pair(
                "options.snap_to_guidelines",
                "options.snap_to_guidelines_tip",
            ));
    });
    egui::Grid::new("guide_colors")
        .num_columns(2)
        .spacing([8.0, 6.0])
        .show(ui, |ui| {
            row_label(ui, "options.default_guide_color");
            if let Some(c) = color_button(ui, "options.default_guide_color", meta.guides.color) {
                meta.guides.color = c;
            }
            ui.end_row();
            row_label(ui, "options.default_preset_guide_color");
            if let Some(c) = color_button(
                ui,
                "options.default_preset_guide_color",
                meta.guides.preset_color,
            ) {
                meta.guides.preset_color = c;
            }
            ui.end_row();
        });
    set_metadata(app, meta);

    section(ui, "options.guide_presets");
    let mut form = std::mem::take(&mut app.guide_presets);
    ui.horizontal(|ui| {
        ui.radio_value(&mut form.user_defined, false, tr("guides.presets"))
            .rich_tip(crate::ui::tips::pair(
                "guides.presets",
                "guides.presets_tip",
            ));
        ui.radio_value(&mut form.user_defined, true, tr("guides.user_defined"))
            .rich_tip(crate::ui::tips::pair(
                "guides.user_defined",
                "guides.user_defined_tip",
            ));
    });
    let units = app.units;
    if form.user_defined {
        ui.checkbox(&mut form.margins, tr("guides.margins"))
            .rich_tip(crate::ui::tips::pair(
                "guides.margins",
                "guides.margins_tip",
            ));
        ui.add_enabled_ui(form.margins, |ui| {
            egui::Grid::new("preset_margins")
                .num_columns(4)
                .spacing([8.0, 4.0])
                .show(ui, |ui| {
                    row_label(ui, "guides.top");
                    if let Some(v) = paper_field(ui, "guides.top", units, form.margin_top, 0.1) {
                        form.margin_top = v;
                    }
                    row_label(ui, "guides.left");
                    if let Some(v) = paper_field(ui, "guides.left", units, form.margin_left, 0.1) {
                        form.margin_left = v;
                    }
                    ui.end_row();
                    row_label(ui, "guides.bottom");
                    if let Some(v) =
                        paper_field(ui, "guides.bottom", units, form.margin_bottom, 0.1)
                    {
                        form.margin_bottom = v;
                    }
                    row_label(ui, "guides.right");
                    if let Some(v) = paper_field(ui, "guides.right", units, form.margin_right, 0.1)
                    {
                        form.margin_right = v;
                    }
                    ui.end_row();
                });
        });
        ui.checkbox(&mut form.columns, tr("guides.columns"))
            .rich_tip(crate::ui::tips::pair(
                "guides.columns",
                "guides.columns_tip",
            ));
        ui.add_enabled_ui(form.columns, |ui| {
            egui::Grid::new("preset_columns")
                .num_columns(2)
                .spacing([8.0, 4.0])
                .show(ui, |ui| {
                    row_label(ui, "guides.number_of_columns");
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair(
                            "guides.number_of_columns",
                            "guides.number_of_columns_tip",
                        ),
                        |ui| {
                            ui.add_sized(
                                [70.0, 20.0],
                                crate::ui::field::NumField::new(&mut form.column_count)
                                    .range(1..=100),
                            );
                        },
                    );

                    ui.end_row();
                    row_label(ui, "guides.distance_between");
                    if let Some(v) = paper_field(
                        ui,
                        "guides.distance_between",
                        units,
                        form.column_gutter,
                        0.1,
                    ) {
                        form.column_gutter = v.max(0.0);
                    }
                    ui.end_row();
                });
        });
        ui.checkbox(&mut form.grid, tr("guides.grid"))
            .rich_tip(crate::ui::tips::pair("guides.grid", "guides.grid_tip"));
        ui.add_enabled_ui(form.grid, |ui| {
            egui::Grid::new("preset_grid")
                .num_columns(2)
                .spacing([8.0, 4.0])
                .show(ui, |ui| {
                    row_label(ui, "guides.rows");
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair("guides.rows", "guides.rows_tip"),
                        |ui| {
                            ui.add_sized(
                                [70.0, 20.0],
                                crate::ui::field::NumField::new(&mut form.grid_rows).range(1..=200),
                            );
                        },
                    );

                    ui.end_row();
                    row_label(ui, "guides.columns_count");
                    crate::ui::tips::tip_over(
                        ui,
                        crate::ui::tips::pair("guides.columns_count", "guides.columns_count_tip"),
                        |ui| {
                            ui.add_sized(
                                [70.0, 20.0],
                                crate::ui::field::NumField::new(&mut form.grid_columns)
                                    .range(1..=200),
                            );
                        },
                    );

                    ui.end_row();
                });
        });
    } else {
        for p in NamedPreset::ALL {
            let mut on = form.named.contains(&p);
            if ui
                .checkbox(&mut on, tr(p.key()))
                .rich_tip_with(|| format!("{}\n{}", tr(p.key()), tr(&format!("{}_tip", p.key()))))
                .changed()
            {
                if on {
                    form.named.push(p);
                } else {
                    form.named.retain(|q| *q != p);
                }
            }
        }
    }
    if ui
        .button(tr("guides.apply_presets"))
        .rich_tip(crate::ui::tips::pair(
            "guides.apply_presets",
            "guides.apply_presets_tip",
        ))
        .clicked()
    {
        apply_presets(app, &form);
    }
    app.guide_presets = form;

    section(ui, "options.guidelines_list");
    guide_list(app, ui, None, 220.0);
}

/// Add the guidelines a preset form describes, in the preset colour.
pub fn apply_presets(app: &mut App, form: &PresetForm) {
    let size = app.page_size();
    let bleed = app.doc().metadata.bleed.max(0.0);
    let color = app.doc().metadata.guides.preset_color;
    let mut lines: Vec<GuideLine> = Vec::new();
    if form.user_defined {
        if form.margins {
            lines.extend(
                GuidePreset::Margins {
                    top: form.margin_top,
                    bottom: form.margin_bottom,
                    left: form.margin_left,
                    right: form.margin_right,
                }
                .lines(size),
            );
        }
        if form.columns {
            // Columns between the margins when margins are on.
            let (l, r) = if form.margins {
                (form.margin_left, form.margin_right)
            } else {
                (0.0, 0.0)
            };
            let inner =
                tracedraw_core::geometry::Size::new((size.width - l - r).max(0.0), size.height);
            for line in (GuidePreset::Columns {
                count: form.column_count,
                gutter: form.column_gutter,
            })
            .lines(inner)
            {
                if let GuideLine::Vertical { x } = line {
                    lines.push(GuideLine::Vertical { x: x + l });
                }
            }
        }
        if form.grid {
            lines.extend(
                GuidePreset::Grid {
                    rows: form.grid_rows,
                    columns: form.grid_columns,
                }
                .lines(size),
            );
        }
    } else {
        for p in &form.named {
            lines.extend(preset_lines(*p, size, bleed));
        }
    }
    let mut guides = app.page_guides();
    for line in lines {
        if !guides.iter().any(|g| g.line == line) {
            let mut g = Guide::from(line);
            g.color = Some(color);
            guides.push(g);
        }
    }
    app.set_guides(guides, "Add Guideline");
}

/// Text for a guideline in the lists: its position from the ruler origin
/// (and angle).
pub(crate) fn guide_text(app: &App, g: &Guide) -> String {
    let u = app.units;
    let (o, _) = g.line.point_and_direction();
    let r = app.to_ruler(o);
    let fmt = |v: f64| format!("{:.3} {}", u.world_from_mm(v), u.short());
    match g.line {
        GuideLine::Horizontal { .. } => fmt(r.y),
        GuideLine::Vertical { .. } => fmt(r.x),
        GuideLine::Angled { angle, .. } => format!("{}, {}, {:.1}°", fmt(r.x), fmt(r.y), angle),
    }
}

/// A selectable list of the page's guidelines (only those of `kind` when
/// given). Clicking selects the guideline on the page too.
fn guide_list(app: &mut App, ui: &mut Ui, kind: Option<GuideKind>, height: f32) {
    let guides = app.page_guides();
    let frame = egui::Frame::new()
        .fill(crate::theme::Tokens::field())
        .stroke(egui::Stroke::new(1.0, Tokens::control_border()))
        .inner_margin(egui::Margin::same(2));
    frame.show(ui, |ui| {
        egui::ScrollArea::vertical()
            .id_salt(("guide_list", kind.map(|k| k as u8)))
            .max_height(height)
            .min_scrolled_height(height)
            .auto_shrink([false, false])
            .show(ui, |ui| {
                ui.set_min_width(ui.available_width());
                let shown: Vec<usize> = guides
                    .iter()
                    .enumerate()
                    .filter(|(_, g)| kind.is_none_or(|k| k == GuideKind::of(&g.line)))
                    .map(|(i, _)| i)
                    .collect();
                for (i, g) in guides.iter().enumerate() {
                    if kind.is_some_and(|k| k != GuideKind::of(&g.line)) {
                        continue;
                    }
                    let selected = app.selected_guides.contains(&i);
                    let mut text = guide_text(app, g);
                    if kind.is_none() {
                        text = format!("{}  {}", tr(GuideKind::of(&g.line).key()), text);
                    }
                    if g.locked {
                        text.push_str(&format!("  ({})", tr("guides.locked")));
                    }
                    let r = ui.selectable_label(selected, text);
                    if r.clicked() {
                        let (ctrl, shift) =
                            ui.input(|i| (i.modifiers.command, i.modifiers.shift));
                        // Shift+click: every guideline listed from the one
                        // clicked last to this one (#2883).
                        let range = shift
                            .then(|| shift_range(&shown, &app.selected_guides, i, ctrl))
                            .flatten();
                        if let Some(sel) = range {
                            app.selected_guides = sel;
                        } else if ctrl {
                            if selected {
                                app.selected_guides.retain(|j| *j != i);
                            } else {
                                app.selected_guides.push(i);
                            }
                        } else {
                            app.selected_guides = vec![i];
                        }
                        app.guide_rotate = None;
                        let mut form = app.guide_form;
                        form.load(app, &g.line);
                        app.guide_form = form;
                    }
                }
            });
    });
}

/// The guidelines a Shift+click on `clicked` selects in a list showing
/// `shown` (#2883): those listed from the anchor (the one selected last)
/// to it, added to `selected` with Ctrl; the anchor stays last, for the
/// next Shift+click. `None` without an anchor in the list.
fn shift_range(shown: &[usize], selected: &[usize], clicked: usize, ctrl: bool) -> Option<Vec<usize>> {
    let a = selected.last().and_then(|a| shown.iter().position(|j| j == a))?;
    let h = shown.iter().position(|j| *j == clicked)?;
    let (lo, hi) = (a.min(h), a.max(h));
    let anchor = shown[a];
    let mut sel: Vec<usize> = if ctrl { selected.to_vec() } else { Vec::new() };
    for j in &shown[lo..=hi] {
        if !sel.contains(j) {
            sel.push(*j);
        }
    }
    sel.retain(|j| *j != anchor);
    sel.push(anchor);
    Some(sel)
}

/// Window > Panels > Guidelines: show and snap toggles, the guideline type, position fields,
/// Add and Modify, the list, delete and lock, colour and style.
pub fn guidelines_docker(app: &mut App, ui: &mut Ui) {
    ui.horizontal(|ui| {
        ui.toggle_value(&mut app.show_guides, tr("guides.show"))
            .rich_tip(tr("guides.show_tip"));
        ui.toggle_value(&mut app.snap.guides, tr("guides.snap"))
            .rich_tip(tr("guides.snap_tip"));
    });
    ui.add_space(4.0);
    app.sync_guide_form();
    let mut form = app.guide_form;
    // A value typed in x, y or angle moves the one selected guideline
    // as it is entered (Enter or leaving the field); Modify stays for
    // a change of type.
    let mut moved = false;
    ui.horizontal(|ui| {
        ui.label(tr("guides.type"));
        crate::ui::keynav::ComboBox::from_id_salt("guide_type")
            .selected_text(tr(form.kind.key()))
            .width(140.0)
            .show_ui(ui, |ui| {
                for k in GuideKind::ALL {
                    ui.selectable_value(&mut form.kind, k, tr(k.key()));
                }
            })
            .response
            .rich_tip(crate::ui::tips::pair("guides.type", "guides.type_desc"));
    });
    let units = app.units;
    // After a double click on a guideline its position field takes the
    // focus, the value selected, ready to be typed over (#2883): y for a
    // horizontal guideline, x for the others.
    let focus = std::mem::take(&mut app.guide_focus_field);
    let enter = ui.input(|i| i.key_pressed(egui::Key::Enter));
    egui::Grid::new("guide_form")
        .num_columns(2)
        .spacing([6.0, 4.0])
        .show(ui, |ui| {
            if form.kind != GuideKind::Horizontal {
                row_label(ui, "guides.x");
                let x = crate::ui::tips::tip_over(
                    ui,
                    crate::ui::tips::pair("toolbar.object_x", "guides.x_desc"),
                    |ui| distance_field_focused(ui, "guides.x", units, form.x, 0.1, focus),
                );
                if let Some(v) = x {
                    form.x = v;
                    moved = true;
                }
                ui.end_row();
            }
            if form.kind != GuideKind::Vertical {
                row_label(ui, "guides.y");
                let y = crate::ui::tips::tip_over(
                    ui,
                    crate::ui::tips::pair("toolbar.object_y", "guides.y_desc"),
                    |ui| {
                        let focus = focus && form.kind == GuideKind::Horizontal;
                        distance_field_focused(ui, "guides.y", units, form.y, 0.1, focus)
                    },
                );
                if let Some(v) = y {
                    form.y = v;
                    moved = true;
                }
                ui.end_row();
            }
            if form.kind == GuideKind::Angled {
                row_label(ui, "guides.angle");
                if ui
                    .add_sized(
                        [110.0, 20.0],
                        crate::ui::field::NumField::new(&mut form.angle)
                            .speed(1.0)
                            .max_decimals(2)
                            .suffix("°"),
                    )
                    .rich_tip(crate::ui::tips::pair("guides.angle", "guides.angle_desc"))
                    .changed()
                {
                    moved = true;
                }
                ui.end_row();
            }
        });
    app.guide_form = form;
    // Alt+A adds and Alt+M modifies from the keyboard, the hands kept off
    // the mouse (#2883).
    let (alt_add, alt_modify) = ui.input_mut(|i| {
        (
            i.consume_key(egui::Modifiers::ALT, egui::Key::A),
            i.consume_key(egui::Modifiers::ALT, egui::Key::M),
        )
    });
    let mut add = alt_add;
    if moved {
        let line = form.line(app);
        // Enter in a field with no guideline selected adds one there.
        if app.selected_guides.is_empty() {
            add |= enter;
        } else {
            app.move_guide_from_form(line);
        }
    }
    ui.horizontal(|ui| {
        if ui
            .button(tr("guides.add"))
            .rich_tip(crate::ui::tips::pair("guides.add", "guides.add_desc"))
            .clicked()
        {
            add = true;
        }
        if add {
            let line = form.line(app);
            app.add_guide_from_form(line);
        }
        let single = match app.selected_guides.as_slice() {
            [i] => Some(*i),
            _ => None,
        };
        if ui
            .add_enabled(single.is_some(), egui::Button::new(tr("guides.modify")))
            .rich_tip(crate::ui::tips::pair("guides.modify", "guides.modify_desc"))
            .rich_disabled_tip(crate::ui::tips::pair("guides.modify", "guides.modify_desc"))
            .clicked()
            || (alt_modify && single.is_some())
        {
            if let Some(i) = single {
                if let Some(g) = app.page_guides().get(i).copied() {
                    if g.locked {
                        app.status = tr("status.guideline_locked");
                    } else {
                        let line = form.line(app);
                        app.replace_guide(i, g.with_line(line), "Move Guideline");
                    }
                }
            }
        }
    });
    ui.add_space(4.0);
    guide_list(app, ui, Some(form.kind), 160.0);
    ui.add_space(4.0);
    let any = !app.selected_guides.is_empty();
    ui.horizontal(|ui| {
        if ui
            .add_enabled(any, egui::Button::new(tr("guides.delete")))
            .rich_tip(crate::ui::tips::pair("guides.delete", "guides.delete_desc"))
            .rich_disabled_tip(crate::ui::tips::pair("guides.delete", "guides.delete_desc"))
            .clicked()
            && !app.delete_selected_guides()
        {
            app.status = tr("status.guideline_locked");
        }
        // Copies of the selected guidelines, moved by the duplicate offset.
        if ui
            .add_enabled(any, egui::Button::new(tr("guides.duplicate")))
            .rich_tip(tr("guides.duplicate_tip"))
            .clicked()
        {
            app.duplicate_selected_guides();
        }
        // Every guideline of the type shown, one undo step.
        let of_kind = app
            .page_guides()
            .iter()
            .any(|g| GuideKind::of(&g.line) == form.kind);
        if ui
            .add_enabled(of_kind, egui::Button::new(tr("guides.clear")))
            .rich_tip(tr("guides.clear_tip"))
            .clicked()
        {
            app.clear_guides_of_kind(form.kind);
        }
        let guides = app.page_guides();
        let all_locked = any
            && app
                .selected_guides
                .iter()
                .all(|i| guides.get(*i).is_some_and(|g| g.locked));
        let label = if all_locked {
            tr("guides.unlock")
        } else {
            tr("guides.lock")
        };
        let lock_tip = crate::ui::tips::pair("guides.lock_tip", "guides.lock_desc");
        if ui
            .add_enabled(any, egui::Button::new(label))
            .rich_tip(&lock_tip)
            .rich_disabled_tip(&lock_tip)
            .clicked()
        {
            let sel = app.selected_guides.clone();
            app.set_guides_locked(&sel, !all_locked);
        }
    });
    // Colour and style of the selected guidelines (or the default colour
    // when none is selected).
    let guides = app.page_guides();
    let first = app
        .selected_guides
        .first()
        .and_then(|i| guides.get(*i))
        .copied();
    egui::Grid::new("guide_look")
        .num_columns(2)
        .spacing([6.0, 4.0])
        .show(ui, |ui| {
            row_label(ui, "guides.color");
            let current = first
                .map(|g| app.guide_color(&g))
                .unwrap_or(app.doc().metadata.guides.color);
            let picked = crate::ui::tips::tip_over(
                ui,
                crate::ui::tips::pair("guides.color", "guides.color_desc"),
                |ui| color_button(ui, "guides.color", current),
            );
            if let Some(c) = picked {
                if any {
                    app.edit_selected_guides("Guideline Color", |g| g.color = Some(c));
                } else {
                    let mut meta = app.doc().metadata.clone();
                    meta.guides.color = c;
                    set_metadata(app, meta);
                }
            }
            ui.end_row();
            row_label(ui, "guides.style");
            let style = first.map(|g| g.style).unwrap_or_default();
            ui.add_enabled_ui(any, |ui| {
                crate::ui::keynav::ComboBox::from_id_salt("guide_style")
                    .selected_text(tr(style_key(style)))
                    .width(120.0)
                    .show_ui(ui, |ui| {
                        for s in GuideStyle::ALL {
                            if ui.selectable_label(s == style, tr(style_key(s))).clicked() {
                                app.edit_selected_guides("Guideline Style", |g| g.style = s);
                            }
                        }
                    })
                    .response
                    .rich_tip(crate::ui::tips::pair("guides.style", "guides.style_desc"))
                    .rich_disabled_tip(crate::ui::tips::pair("guides.style", "guides.style_desc"));
            });
            ui.end_row();
        });
}

fn style_key(s: GuideStyle) -> &'static str {
    match s {
        GuideStyle::Solid => "guides.style_solid",
        GuideStyle::Dashed => "guides.style_dashed",
        GuideStyle::Dotted => "guides.style_dotted",
        GuideStyle::DashDot => "guides.style_dash_dot",
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tracedraw_core::geometry::Size;

    #[test]
    fn the_form_counts_from_the_ruler_origin() {
        let mut app = App::headless();
        app.set_ruler_origin(Point::new(10.0, 20.0));
        let form = GuideForm {
            kind: GuideKind::Horizontal,
            x: 0.0,
            y: 5.0,
            angle: 0.0,
        };
        assert_eq!(form.line(&app), GuideLine::Horizontal { y: 25.0 });
        let mut back = GuideForm::default();
        back.load(&app, &GuideLine::Vertical { x: 13.0 });
        assert_eq!(back.kind, GuideKind::Vertical);
        assert!((back.x - 3.0).abs() < 1e-9);
    }

    /// Shift+click in the guideline list (#2883).
    #[test]
    fn shift_click_selects_the_guidelines_listed_between() {
        // The list shows guidelines 1, 3, 4, 6 (the others of another type).
        let shown = [1, 3, 4, 6];
        assert_eq!(shift_range(&shown, &[3], 6, false), Some(vec![4, 6, 3]));
        assert_eq!(shift_range(&shown, &[6], 1, false), Some(vec![1, 3, 4, 6]));
        // Ctrl keeps the others selected.
        assert_eq!(shift_range(&shown, &[0, 4], 6, true), Some(vec![0, 6, 4]));
        // No anchor in the list: nothing to range from.
        assert_eq!(shift_range(&shown, &[], 4, false), None);
        assert_eq!(shift_range(&shown, &[2], 4, false), None);
    }

    /// The mathematical grids: thirds and golden lines at their
    /// fractions, the diagonals at the page's angle, the Van de Graaf
    /// margins, the golden subdivision's cuts inside the page and the
    /// isometric lines at 30 and 150 degrees.
    #[test]
    fn the_mathematical_layout_grids_make_their_lines() {
        let size = Size::new(210.0, 297.0);
        let thirds = preset_lines(NamedPreset::RuleOfThirds, size, 0.0);
        assert_eq!(thirds.len(), 4);
        assert!(thirds.contains(&GuideLine::Vertical { x: 70.0 }));
        assert!(thirds.contains(&GuideLine::Horizontal { y: 198.0 }));
        let gold = preset_lines(NamedPreset::GoldenRatio, size, 0.0);
        assert_eq!(gold.len(), 4);
        assert!(gold.iter().any(|l| matches!(l, GuideLine::Vertical { x } if (x - 210.0 * 0.381_966).abs() < 0.01)));
        assert!(gold.iter().any(|l| matches!(l, GuideLine::Horizontal { y } if (y - 297.0 * 0.618_034).abs() < 0.01)));
        let centre = preset_lines(NamedPreset::CentreDiagonals, size, 0.0);
        assert_eq!(centre.len(), 4);
        let a = (297.0f64).atan2(210.0).to_degrees();
        assert!(centre.contains(&GuideLine::Angled { x: 0.0, y: 0.0, angle: a }));
        assert!(centre.contains(&GuideLine::Angled { x: 0.0, y: 297.0, angle: -a }));
        let vdg = preset_lines(NamedPreset::VanDeGraaf, size, 0.0);
        assert!(vdg.contains(&GuideLine::Vertical { x: 210.0 / 9.0 }));
        assert!(vdg.contains(&GuideLine::Horizontal { y: 2.0 * 297.0 / 9.0 }));
        let sub = preset_lines(NamedPreset::GoldenSubdivision, size, 0.0);
        assert!(sub.len() >= 4);
        assert!(sub.iter().all(|l| match l {
            GuideLine::Vertical { x } => *x > 0.0 && *x < 210.0,
            GuideLine::Horizontal { y } => *y > 0.0 && *y < 297.0,
            GuideLine::Angled { .. } => false,
        }));
        let iso = preset_lines(NamedPreset::Isometric, size, 0.0);
        assert!(iso.len() > 20 && iso.len() <= 200);
        assert!(iso.iter().all(|l| match l {
            GuideLine::Vertical { .. } => true,
            GuideLine::Angled { angle, .. } => *angle == 30.0 || *angle == 150.0,
            GuideLine::Horizontal { .. } => false,
        }));
        // A page too small for a cut makes none and no line is NaN.
        let tiny = preset_lines(NamedPreset::GoldenSubdivision, Size::new(4.0, 4.0), 0.0);
        assert!(tiny.is_empty());
    }

    #[test]
    fn named_presets_add_their_lines() {
        let size = Size::new(210.0, 297.0);
        let margins = preset_lines(NamedPreset::OneInchMargins, size, 0.0);
        assert_eq!(margins.len(), 4);
        assert!(margins.contains(&GuideLine::Vertical { x: 210.0 - 25.4 }));
        let bleed = preset_lines(NamedPreset::BleedArea, size, 3.0);
        assert!(bleed.contains(&GuideLine::Vertical { x: -3.0 }));
        assert!(bleed.contains(&GuideLine::Horizontal { y: 300.0 }));
        let news = preset_lines(NamedPreset::ThreeColumnNewsletter, size, 0.0);
        // Four margins and four column edges between them.
        assert_eq!(news.len(), 8);
        let upper = preset_lines(NamedPreset::UpperLeftGrid, size, 0.0);
        assert!(upper.iter().all(|l| match l {
            GuideLine::Vertical { x } => *x <= 105.0 + 1e-9,
            GuideLine::Horizontal { y } => *y >= 148.5 - 1e-9,
            _ => false,
        }));
    }

    #[test]
    fn user_defined_columns_sit_between_the_margins() {
        let mut app = App::headless();
        let size = app.page_size();
        let form = PresetForm {
            user_defined: true,
            margins: true,
            margin_left: 10.0,
            margin_right: 10.0,
            columns: true,
            column_count: 2,
            column_gutter: 10.0,
            ..PresetForm::default()
        };
        apply_presets(&mut app, &form);
        let xs: Vec<f64> = app
            .page_guides()
            .iter()
            .filter_map(|g| match g.line {
                GuideLine::Vertical { x } => Some(x),
                _ => None,
            })
            .collect();
        let mid = size.width / 2.0;
        assert!(xs.iter().any(|x| (x - (mid - 5.0)).abs() < 1e-9), "{xs:?}");
        assert!(xs.iter().any(|x| (x - (mid + 5.0)).abs() < 1e-9), "{xs:?}");
        // Applying twice adds nothing new.
        let n = app.page_guides().len();
        apply_presets(&mut app, &form);
        assert_eq!(app.page_guides().len(), n);
    }
}
